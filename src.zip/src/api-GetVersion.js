function getVersion(id,url){
   

    return fetch(url+'ControlVersiones?id='+id)
    .then(response=> response.json())  
    .then((responseJson) => {
      return responseJson;
    })
    .catch((error) => {
      
    });
    }
    

export {getVersion}