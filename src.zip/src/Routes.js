import React, { Component } from "react";
import { Router, Stack, Scene, StyleSheet } from "react-native-router-flux";

import Login from "./components/login/Login";
import Home from "./components/Home/Home";

import AperturaClienteHome from "./components/AperturaCliente/AperturaClienteHome";
import AperturaClienteEntrega from "./components/AperturaCliente/AperturaClienteEntrega";
import DetalleClienteHome from "./components/AperturaCliente/DetalleClienteHome";
import VerficiacionEmbarqueHome from "./components/VerificacionEmbarque/VerficiacionEmbarqueHome";
import DetalleEmbarque from "./components/VerificacionEmbarque/DetalleEmbarque";
import EntregaPedido from "./components/AperturaCliente/EntregaPedido";
import RecuperacionCajas from "./components/RecuperacionCajas/RecuperacionCajasHome";
import EntregaCajas from "./components/RecuperacionCajas/EntregaCajas";
import RecuperacionFoliosHome from "./components/RecuperacionFolios/RecuperacionFoliosHome";
import RecuperacionFolios from "./components/RecuperacionFolios/RecuperacionFolios";
import Utilerias from "./components/Utilidades/VistaUtilerias";
import InicioRuta from "./components/InicioRutaFin/InicioRutaHome";
import FinRuta from "./components/InicioRutaFin/FinRutaHome";

export default class Routes extends Component {
  render() {
    return (
      <Router>
        <Stack key="root" hideNavBar>
          <Scene key="login" component={Login} title="Login" initial={true} />
          <Scene key="home" component={Home} title="home" />
          <Scene
            key="aperturaClienteHome"
            component={AperturaClienteHome}
            title="AperturaClienteHome"
          />
          <Scene
            key="aperturaClienteEntrega"
            component={AperturaClienteEntrega}
            title="AperturaClienteEntrega"
          />
          <Scene
            key="detalleClienteHome"
            component={DetalleClienteHome}
            title="DetalleClienteHome"
          />
          <Scene
            key="verficiacionEmbarqueHome"
            component={VerficiacionEmbarqueHome}
            title="VerficiacionEmbarqueHome"
          />
          <Scene
            key="detalleEmbarque"
            component={DetalleEmbarque}
            title="DetalleEmbarque"
          />
          <Scene
            key="entregaPedido"
            component={EntregaPedido}
            title="EntregaPedido"
          />
          <Scene
            key="recuperacionCajas"
            component={RecuperacionCajas}
            title="recuperacionCajas"
          />
          <Scene
            key="entregaCajas"
            component={EntregaCajas}
            title="EntregaCajas"
          />
          <Scene
            key="recuperacionFoliosHome"
            component={RecuperacionFoliosHome}
            title="recuperacionFoliosHome"
          />
          <Scene
            key="recuperacionFolios"
            component={RecuperacionFolios}
            title="recuperacionFolios"
          />
          <Scene key="utilerias" component={Utilerias} title="utilerias" />
          <Scene key="inicioRuta" component={InicioRuta} title="inicioRuta" />
          <Scene key="finRuta" component={FinRuta} title="finRuta" />
        </Stack>
      </Router>
    );
  }
}
