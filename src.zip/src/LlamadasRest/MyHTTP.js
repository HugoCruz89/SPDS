import { GetUrl } from "../components/Utilidades/UrlUtility";

// metodo post generico
async function postGenerico(controler, body) {
  const url = await GetUrl();
  const datos = await fetch(url + controler, {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    body: body,
  })
    .then((response) => {
      return response.json();
    })
    .catch((error) => {});

  const lista = await datos;
  if (lista !== undefined) {
    return lista;
  }
}
export { postGenerico };

///metodo para obtener la version de la app
async function getVersionCurrent() {
  let url = await GetUrl();

  return fetch(url + "ControlVersiones?id=1")
    .then((response) => {
      return response.json();
    })
    .catch((error) => {});
}
export { getVersionCurrent };

///llamada de login
async function getDatosLogin(usuario, contrasena) {
  //agrego un nuevo parametro solo para poder identifcar la version anterior a la 1.4.5
  let url = await GetUrl();
  // let telefono = await AsyncStorage.getItem(NUMPhone_STG);
  let telefono = "+525567908187";
  let aux = "";

  return fetch(
    url +
      "Seguridad?id=" +
      usuario +
      "&password=" +
      contrasena +
      "&telefono=" +
      "+525567908187" +
      "&aux=" +
      aux +
      "&aux2=" +
      aux
  )
    .then((response) => {
      return response.json();
    })
    .catch((error) => {});
}
export { getDatosLogin };

////
//Funcion que trae los datos del gts en inicio y fin de ruta
////
async function getGTS(IdOperador, bandera, fechaApertura) {
  let url = await GetUrl();
  return fetch(
    url +
      "InicioFinRuta?idOperador=" +
      IdOperador +
      "&bandera=" +
      bandera +
      "&fechaApertura=" +
      fechaApertura
  )
    .then((response) => {
      return response.json();
    })
    .catch((error) => {});
}
export { getGTS };

///
//Obtenego el resumen de ruta
//
async function getResumenRuta(idOperador, fechaApertura, idRuta) {
  let url = await GetUrl();
  return fetch(
    url + "ResumenRuta?idOperador=" + idOperador + "&idRuta=" + idRuta
  )
    .then((response) => {
      return response.json();
    })
    .catch((error) => {});
}

export { getResumenRuta };

//obtengo los pedidos
async function getPedidos(IdOperador, fechaApertura, idRuta) {
  let url = await GetUrl();
  return fetch(
    url +
      "Pedidos?id=" +
      IdOperador +
      "&fechaApertura=" +
      fechaApertura +
      "&idRuta=" +
      idRuta
  )
    .then((response) => response.json())
    .then((data) => data)
    .then((datos) =>
      datos.map((data) => {
        return {
          idCliente: data.IdCliente,
          nombreCliente: data.NombreCliente,
          telefonoCliente: data.Telefono,
          domicilio: data.Domicilio,
          pedidos: data.PedidosXOperador,
          pedidosConDetalle: data.PedidosConDetalleXOperador,
          pedidosSinFinalizar: data.PedidosSinFinalizar,
          fechaCarga: data.FechaCarga,
          pedidosNoEntregados: data.PedidosNoEntregados,
        };
      })
    )
    .catch((error) => {});
}
export { getPedidos };

async function getDetalleEmbarque(IdOperador, idRuta) {
  let url = await GetUrl();
  return fetch(url + "DetalleEmbarque?id=" + IdOperador + "&idRuta=" + idRuta)
    .then((response) => response.json())
    .then((data) => data)
    .then((datos) =>
      datos.map((data) => {
        return {
          idCliente: data.IdCliente,
          nombreCliente: data.NombreCliente,
          domicilio: data.Domicilio,
          pedidos: data.PedidosXOperador,
          totlaCSEmbarcadas: data.TotlaCSEmbarcadas,
          totalKGEmbarcados: data.TotalKGEmbarcados,
        };
      })
    )
    .catch((error) => {});
}
export { getDetalleEmbarque };

//obtengo el embarque
async function getEmbarque(IdOperador, idRuta) {
  let url = await GetUrl();
  return fetch(url + "Embarque?id=" + IdOperador + "&idRuta=" + idRuta)
    .then((response) => response.json())
    .then((data) => data)
    .then((datos) => {
      return datos;
    })
    .catch((error) => {});
}
export { getEmbarque };

async function getClientesCajas(IdRuta, IdPlanta) {
  let url = await GetUrl();
  return fetch(url + "CajasTapas?idRuta=" + IdRuta + "&idPlanta=" + IdPlanta)
    .then((response) => response.json())
    .then((responseJson) => {
      return responseJson;
    })
    .catch((error) => {});
}

export { getClientesCajas };

async function getClientesConFolio(Cliente, IdPlanta, filtro) {
  let url = await GetUrl();
  return fetch(
    url +
      "FoliosRecuperados?Cliente=" +
      Cliente +
      "&idPlanta=" +
      IdPlanta +
      "&filtro=" +
      filtro
  )
    .then((response) => response.json())
    .then((responseJson) => {
      return responseJson;
    })
    .catch((error) => {});
}
export { getClientesConFolio };

async function getMotivosDevolucion() {
  let url = await GetUrl();
  return fetch(url + "MotivosDevolucion/")
    .then((response) => response.json())
    .then((responseJson) => {
      return responseJson;
    })
    .catch((error) => {});
}

export { getMotivosDevolucion };

async function getPedido(IdPedido, IdFactura) {
  let url = await GetUrl();
  return fetch(
    url + "BitacoraPedido?idPedido=" + IdPedido + "&idFactura=" + IdFactura
  )
    .then((response) => response.json())
    .then((responseJson) => {
      return responseJson;
    })
    .catch((error) => {});
}

export { getPedido };

async function DeleteImagenes(IdPedido, IdFactura, IsFolio, IsAdjunto) {
  let url = await GetUrl();
  return fetch(
    url +
      "BitacoraPedido?IdPedido=" +
      IdPedido +
      "&IdFactura=" +
      IdFactura +
      "&IsFolio=" +
      IsFolio +
      "&IsAdjunto=" +
      IsAdjunto
  )
    .then((response) => response.json())
    .then((responseJson) => {
      return responseJson;
    })
    .catch((error) => {});
}

export { DeleteImagenes };

async function DeleteImagenesFoliosRecuperados(
  IdPedido,
  IdFactura,
  IsFolio,
  IsAdjunto
) {
  let url = await GetUrl();
  return fetch(
    url +
      "FoliosRecuperados?IdPedido=" +
      IdPedido +
      "&IdFactura=" +
      IdFactura +
      "&IsFolio=" +
      IsFolio +
      "&IsAdjunto=" +
      IsAdjunto
  )
    .then((response) => response.json())
    .then((responseJson) => {
      return responseJson;
    })
    .catch((error) => {});
}

export { DeleteImagenesFoliosRecuperados };

async function getDatosPedidoXCliente(idOperador, idCliente, idRuta) {
  let url = await GetUrl();
  return fetch(
    url +
      "GetPedidosXCliente?idOperador=" +
      idOperador +
      "&idCliente=" +
      idCliente +
      "&idRuta=" +
      idRuta
  )
    .then((response) => response.json())
    .then((datos) =>
      datos.map((data) => {
        return {
          pedidosConDetalle: data.PedidosConDetalleXOperador,
          telefono: data.Telefono,
          idCliente: data.IdCliente,
        };
      })
    )
    .catch((error) => {});
}
export { getDatosPedidoXCliente };

async function getRegexXCliente(idCliente) {
  let url = await GetUrl();
  return fetch(url + "Regex?idCliente=" + idCliente)
    .then((response) => response.json())
    .then((responseJson) => {
      return responseJson;
    })
    .catch((error) => {});
}
export { getRegexXCliente };
