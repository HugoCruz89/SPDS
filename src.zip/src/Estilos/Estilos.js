/* estilos APP */ 
import {StyleSheet,Dimensions,Platform} from 'react-native'   
import {responsiveHeight, responsiveFontSize } from 'react-native-responsive-dimensions';                                       
const {width, heigth} = Dimensions.get('window')


const EstiloLogin= StyleSheet.create({
    container:{
        flex:1,  
        height: heigth,
        width: width,
      },          
      backgroundImage:{
           flex: 1,
           alignSelf:'stretch',
           width: width,
           justifyContent:  'center',
           alignItems:  'center',
           height: heigth,
           opacity: .3,
        },      
      logo:{
        bottom: '10%',
        width: 200,
        height: 118,           
      },
      logo2:{
        bottom: '10%',
        width: 170,
        height: 140,     
      },          
      logoContainer:{
        position: 'absolute',
        alignItems:  'center' ,
        width: '100%',
        height: '100%',
        top: '20%',	
      },          
      logoContainer2:{
        position: 'absolute',
        alignItems:  'center' ,
        width: '100%',
        height: '100%',
        top: '40%'	
      },          
      title:{
          backgroundColor: 'transparent',
          color: 'white',
          marginTop: 10,
          fontSize: 50
      }
})

const EstiloFinRuta= StyleSheet.create({
  container:
  {    
   backgroundColor: 'white',
   alignItems: 'center',
   justifyContent: 'center'
 },
 firstHeaderContainer:
 {
   backgroundColor: '#ccc',  
 },
 titulo1:
 {
   backgroundColor: 'transparent',
   color: 'black',
   fontSize: Platform.OS === 'ios' ? responsiveFontSize(2): responsiveFontSize(2.2),
 },
 titulo2:
 {
   backgroundColor: 'transparent',
   color: '#434346',
   fontSize: Platform.OS === 'ios' ? responsiveFontSize(2): responsiveFontSize(1.7),
 },
 textoContainerTitulo:
 {
   position: 'absolute',
   alignItems:  'center' ,
   width: '100%',
   height: '100%',
   top: '2.5%',    
 },
 containerPrincipal:
 {
   flex: 2,
   backgroundColor: '#fcfcff',
 },
 modalContent:
 {
   backgroundColor: 'transparent',
   padding: 20,
   height: responsiveHeight(70),
 },  
 input:
 {
   marginBottom: 15,
   height: 35,
   borderWidth: 1,
   borderRadius: 5,
   width: '70%',
   backgroundColor: '#ffffff',
   borderColor: '#ddd',
   borderBottomWidth: 0,
   shadowColor: '#000',
   shadowOffset: {width: 0, height: 2},
   shadowOpacity: 0.8,
   shadowRadius: 2,
   elevation: 3,
   padding: 0,
   paddingLeft: 7,  
 },
 inputKgTemperatura:
 {
   marginBottom: 15,
   height: 35,   
   borderWidth: 1,
   borderRadius: 5,    
   backgroundColor: '#ffffff',
   width: '65%',
   borderColor: '#ddd',
   borderBottomWidth: 0,
   shadowColor: '#000',
   shadowOffset: {width: 0, height: 2},
   shadowOpacity: 0.8,
   shadowRadius: 2,
   elevation: 3,
   padding: 0,
   paddingLeft: 7,
 },
 inputCajasTapas:
 {
   marginBottom: 15,
   height: 35,   
   borderWidth: 1,
   borderRadius: 5,
   backgroundColor: '#ffffff',
   width: '50%',
   borderColor: '#ddd',
   borderBottomWidth: 0,
   shadowColor: '#000',
   shadowOffset: {width: 0, height: 2},
   shadowOpacity: 0.8,
   shadowRadius: 2,
   elevation: 3,
   padding: 0,
   paddingLeft: 7,
 },
 icono:{
   marginBottom: '3%'
 },
 button:{
   backgroundColor: '#3483D8',
   paddingTop: 15,
   paddingBottom: 15,
   marginTop: 5,
   borderRadius: 5,
   top: '3%',
   marginBottom: '3%',
   borderColor: '#ddd',
   borderBottomWidth: 0,
   shadowColor: '#000',
   shadowOffset: {width: 0, height: 2},
   shadowOpacity: 0.8,
   shadowRadius: 2,
   elevation: 3,
 },
 button2:{
 backgroundColor: '#0BA803',
 paddingTop: 15,
 paddingBottom: 15,
 marginTop: 5,
 borderRadius: 5,
 top: '3%',
 marginBottom: '3%',
 borderColor: '#ddd',
 borderBottomWidth: 0,
 shadowColor: '#000',
 shadowOffset: {width: 0, height: 2},
 shadowOpacity: 0.8,
 shadowRadius: 2,
 elevation: 3,
 },
 buttonText:{
   textAlign:  'center',
   color:'#fff',      
 },
containerInpput:{
   position: 'absolute',  
   width: '95%',
   height: '80%',
   top: '8%',
   marginLeft: '2.5%',
   backgroundColor: '#ffffff',
   borderRadius: 25,
    borderColor: '#ddd',
 borderBottomWidth: 0,
 shadowColor: '#000',
 shadowOffset: {width: 0, height: 2},
 shadowOpacity: 0.8,
 shadowRadius: 2,
 elevation: 3, 
 },

})

export {EstiloLogin,EstiloFinRuta}