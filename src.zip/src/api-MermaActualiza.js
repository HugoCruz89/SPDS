function getDatosMerma(idPedido, idFactura, url) {
  return fetch(url + "Merma?idPedido=" + idPedido + "&idFactura=" + idFactura)
    .then((response) => response.json())
    .then((datos) =>
      datos.map((data) => {
        return {
          listaDetalle: data.listaDetalle,
        };
      })
    )
    .catch((error) => {});
}

export { getDatosMerma };
