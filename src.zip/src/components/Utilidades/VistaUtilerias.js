import React, { Component } from "react";
import {
  StyleSheet,
  View,
  Text,
  Platform,
  TextInput,
  TouchableHighlight,
  Picker,
  ScrollView
} from "react-native";
import Icon from "react-native-vector-icons/FontAwesome";
import { Actions } from "react-native-router-flux";
import HeaderContenido from "../Home/HeaderContenido";
import { responsiveFontSize } from "react-native-responsive-dimensions";
import { GetUrl } from "../Utilidades/UrlUtility";
import AsyncStorage from "@react-native-community/async-storage";
import SmartPicker from "react-native-smart-picker";
const URi_STG = "url";
const VisibleToastDev = "bandera";
export default class VistaUtilerias extends Component {
  constructor(props) {
    super(props);
    this.SetUrl();
    this.state = {
      url: ""
      
    };
  }

  async SetUrl() {
    let url = await GetUrl();  
    this.setState({ url });
  }

  home() {
    Actions.login();
  }
  
  onChangeUrl(url) {
   
    this.setState({ url });
  }

  async GrabarDatos() {
    const urlNueva = this.state.url;
    let bandera = "false";
    await AsyncStorage.setItem(URi_STG, urlNueva);

    if(urlNueva === 'https://Boxtires.pilgrims.com.mx:8200/ServiceWebSPDS/api/'){
       bandera = "false";
    }else{
       bandera = "true";
    }
    await AsyncStorage.setItem(VisibleToastDev, bandera);
    Actions.login();
  }

  render() {
    const save = <Icon name="save" size={20} color="white" />;
    return (
      <View style={{ flex: 1 }}>
        <HeaderContenido home={this.home.bind(this)} />
        <View style={styles.containerPrincipal}>
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              width: "100%",
              marginTop: 15
            }}
          >
            <Text style={styles.titulo2}>URL: </Text>
            <TextInput
              returnKeyType="next"
              value={this.state.url}
              //  placeholder="Folio"
              underlineColorAndroid="transparent"
              placeholderTextColor="rgba(10,10,10,0.5)"
              style={styles.input}
              onChangeText={url => this.onChangeUrl(url)}
            />
          </View>
          <View style={{ flex: 1, margin: 14, color: "withe" }}>
                <ScrollView style={styles.container}>
                  <SmartPicker    
                    androidPickerStyle={styles.container}                
                    selectedValue={this.state.selected}
                    label="Selecciona el servidor"
                    onValueChange={url => this.onChangeUrl(url)}
                  >
                   <Picker.Item label="" key="" value="" />
                   <Picker.Item label='Desarrollo' value='https://www.appspruebas.tech:8080/ServiceWebSPDS/api/' />
                   <Picker.Item label='Producción' value='https://Boxtires.pilgrims.com.mx:8200/ServiceWebSPDS/api/' />
                  </SmartPicker>
                </ScrollView>
          </View>
          <View
            style={{
              marginTop:-350,   
              width: "100%",            
            }}
          >
            <Text style={styles.titulo2}>url del servidor </Text>
            <Text style={styles.titulo2}>{this.state.url} </Text>
           
          </View>
          <View style={{ top: "1%" }}>
            <TouchableHighlight
              style={styles.button2}
              onPress={() => this.GrabarDatos()}
            >
              <Text style={styles.buttonText}>{save} Guardar Servidor</Text>
            </TouchableHighlight>
          </View>
        </View>
      </View>
    );
  }
}
const styles = StyleSheet.create({

  containerPicker:{
    
  },
  containerPrincipal: {
    flex: 2,
    backgroundColor: "#09467F"
  },

  titulo2: {
    marginTop: 5,
    marginLeft: 5,
    backgroundColor: "transparent",
    color: "white",
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(2) : responsiveFontSize(1.7)
  },
  input: {
    marginRight: 5,
    marginBottom: 15,
    height: 35,
    borderWidth: 1,
    borderRadius: 5,
    width: "85%",
    backgroundColor: "#ffffff",
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,

    padding: 0,
    paddingLeft: 7
  },
  button2: {
    backgroundColor: "#0BA803",
    paddingTop: 15,
    paddingBottom: 15,
    marginTop: 5,
    borderRadius: 5,
    top: "3%",
    marginBottom: "3%",

    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3
  },
  buttonText: {
    textAlign: "center",
    color: "#fff"
  },
  buttonText: {
    textAlign: "center",
    color: "#fff"
  },
  container: {
    //textAlign:  'center',
    color: "white"
  },
});
