//funcion para obtener la fecha completa
import { ToastAndroid } from "react-native";
import AsyncStorage from "@react-native-community/async-storage";

const style = {
  backgroundColor: "rgba(0,0,0,0.6)",
  marginBottom: 70
};
const VisibleToastDev = "bandera";
const URi_STG = "url";

// funcion que regresa la url
async function GetUrl() {
  let url = await AsyncStorage.getItem(URi_STG);
  let IsDesarrollador = await AsyncStorage.getItem(VisibleToastDev);
  if (IsDesarrollador === "true") {
    ToastAndroid.show("Eres Desarrollador !", ToastAndroid.SHORT);
  }
  return url;
}
export { GetUrl };


// funcion para setear la url pro
async function SetUrlPro() {
  //descomentar esta linea y refrescar para eliminar la url y poder setear
  //la nueva, despues comentar para que tome la nueva url
  //  await AsyncStorage.removeItem(URi_STG)  //<--Esta Linea
  let url = await AsyncStorage.getItem(URi_STG);
  if (
    url == "https://Boxtires.pilgrims.com.mx:8200/ServiceWebSPDS/api/" ||
    // url == "https://www.appspruebas.tech:8080/ServiceWebSPDS/api/" ||
    url == null
  ) {
    const urlNueva = "https://Boxtires.pilgrims.com.mx:8200/ServiceWebSPDS/api/";
    // const urlNueva = "https://www.appspruebas.tech:8080/ServiceWebSPDS/api/";
    await AsyncStorage.setItem(URi_STG, urlNueva);
    await AsyncStorage.setItem(VisibleToastDev, "false");
  }
}
export { SetUrlPro };
