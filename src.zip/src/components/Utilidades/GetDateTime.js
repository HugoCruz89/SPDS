//funcion para obtener la fecha completa
function GetDateTime(){
    const date = new Date().getDate(); //Current Date
    const month = new Date().getMonth() + 1; //Current Month
    const year = new Date().getFullYear(); //Current Year
    const hours = new Date().getHours(); //Current Hours
    const min = new Date().getMinutes(); //Current Minutes
    const sec = new Date().getSeconds(); //Current Seconds 
    const dateTime = year + '-' + month + '-' + date + ' ' + hours + ':' + min + ':' + sec
    return dateTime;
}
export {GetDateTime}