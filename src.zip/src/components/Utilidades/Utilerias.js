import DeviceInfo from "react-native-device-info";
import AsyncStorage from "@react-native-community/async-storage";
import { Actions } from "react-native-router-flux";
import { postGenerico } from "../../LlamadasRest/MyHTTP";
const RNFS = require("react-native-fs");
const RFC_STG = "RFC";
const NOMBRE_STG = "nombre";
const PATERNO_STG = "apPat";
const MATERNO_STG = "apMat";
const ID_STG = "numeroSocio";
const ROL_STG = "rol";
const RUTA_STG = "ruta";
const TELEFONO_STG = "telefono";
const PLANTA_STG = "planta";
const IDPLANTA_STG = "idplanta";
const VEHICULO_STG = "vehiculo";
const FECHAAPERTURA_STG = "fechaApertura";

async function GuardarImei(imei) {
  const body = {
    imei: imei,
  };
  const controller = "ControlVersiones";
  await postGenerico(controller, JSON.stringify(body)).then((data) => {
    return data;
  });
}
export { GuardarImei };

async function ValidarNumeroIMEI() {
  DeviceInfo.getPhoneNumber().then((phoneNumber) => {
    if (phoneNumber === undefined || phoneNumber === "unknown") {
      const id = showToast(
        "Debes autorizar el permiso solicitado para que el dispositivo se conecte a la aplicación"
      );
    } else {
      const thenProm = GuardarImei(phoneNumber).then((valor) => {
        return valor;
      });
    }
  });
}
export { ValidarNumeroIMEI };

async function almacenaDatos(datos) {
  try {
    await AsyncStorage.setItem(RFC_STG, datos.RFC);
    await AsyncStorage.setItem(NOMBRE_STG, datos.Nombre);
    await AsyncStorage.setItem(PATERNO_STG, datos.ApellPaterno);
    await AsyncStorage.setItem(MATERNO_STG, datos.ApellMaterno);
    await AsyncStorage.setItem(ID_STG, datos.IdGeneral);
    await AsyncStorage.setItem(ROL_STG, datos.Rol);
    await AsyncStorage.setItem(RUTA_STG, datos.Ruta);
    await AsyncStorage.setItem(TELEFONO_STG, datos.TelefonoPlanta);
    await AsyncStorage.setItem(PLANTA_STG, datos.NombrePlanta);
    await AsyncStorage.setItem(IDPLANTA_STG, datos.IdPlanta);
    await AsyncStorage.setItem(VEHICULO_STG, datos.vehiculo);
    await AsyncStorage.setItem(FECHAAPERTURA_STG, datos.FechaAperturaRuta);
  } catch (error) {}
  Actions.home();
}
export { almacenaDatos };

//obtengo datos, si ya estoy logueado es transparente el login
async function IsLogining() {
  let rfc = await AsyncStorage.getItem(RFC_STG);
  if (rfc != undefined || rfc != null || rfc == "null") {
    Actions.home();
  } else return false;
}
export { IsLogining };

async function BorraImagenes(Array) {
  Array.forEach((item) => {
    const path2 =
      "/storage/emulated/0/Android/data/com.spds1/files/" + item.Path;

    return (
      RNFS.unlink(path2)
        .then((data) => {})
        // `unlink` will throw an error, if the item to unlink does not exist
        .catch((err) => {})
    );
  });
}
export { BorraImagenes };
