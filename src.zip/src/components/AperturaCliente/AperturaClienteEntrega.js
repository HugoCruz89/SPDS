import React, { Component } from "react";
import { StyleSheet, View } from "react-native";
import ListView from "deprecated-react-native-listview";
import { Actions } from "react-native-router-flux";
import HeaderContenido from "../Home/HeaderDetallePedido";
import ItemsApi from "../AperturaCliente/ItemsPedidosConDetalle";

export default class AperturaClienteEntrega extends Component {
  constructor(props) {
    super(props);
    const ds1 = new ListView.DataSource({
      rowHasChanged: (r1, r2) => r1 !== r2,
    });
    this.state = {
      motivoDevolucion: "",
      dataSourceDetalle: ds1,
      pedidos: "",
      datos: [],
      datosDetallePedido1: [],
      telefonoCliente: "",
      idCliente: "",
    };
  }

  componentWillMount() {
    const detallePedido = this.props.PedidosConDetalle;
    const telefonoCliente = this.props.telefono;
    const idCliente = this.props.idCliente;

    this.setState({
      datosDetallePedido1: detallePedido,
      telefonoCliente: telefonoCliente,
      idCliente: idCliente,
    });
  }
  componentWillReceiveProps(newProps) {
    if (newProps.datosDetallePedido1 !== this.props.datosDetallePedido1) {
      this.upDateDataSource(newProps.datosDetallePedido);
    }
  }

  upDateDataSource = (data) => {
    this.setState({
      datosDetallePedido1: data,
    });
  };

  home() {
    Actions.aperturaClienteHome();
  }

  render() {
    const datosDetallePedido = this.state.datosDetallePedido1;

    return (
      <View style={{ flex: 1 }}>
        <HeaderContenido home={this.home.bind(this)} />

        <View style={styles.containerPrincipal}>
          <ItemsApi
            datos={datosDetallePedido}
            telefonoCliente={this.state.telefonoCliente}
            idCliente={this.state.idCliente}
          />
        </View>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  containerPrincipal: {
    flex: 2,
    backgroundColor: "#fcfcff",
  },
});
