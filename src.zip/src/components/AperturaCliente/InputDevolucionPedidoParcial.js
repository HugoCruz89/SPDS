import React, { Component } from "react";
import {
  Text,
  View,
  StyleSheet,
  TouchableHighlight,
  Picker,
  ScrollView,
  Platform,
} from "react-native";
import { responsiveFontSize } from "react-native-responsive-dimensions";
import Modal from "react-native-modal";
import Icon from "react-native-vector-icons/FontAwesome";
import SmartPicker from "react-native-smart-picker";
import { getMotivosDevolucion } from "../../LlamadasRest/MyHTTP";

export default class InputDevolucionPedidoParcial extends Component {
  constructor(props) {
    super(props);

    this.state = {
      catalogo: [],
      url: "",
    };
  }

  async getUrl() {
    getMotivosDevolucion()
      .then((data) => {
        this.setState({
          catalogo: data,
        });
      })
      .catch((mensaje) => {});
  }

  componentDidMount() {
    this.getUrl();
  }

  render() {
    const itemsInPicker = this.state.catalogo.map((data) => {
      return (
        <Picker.Item label={data.descripcion} key={data.id} value={data.id} />
      );
    });
    const cancelarPedido = (
      <Icon name="remove" size={25} color="white" marginRight="5%" />
    );

    return (
      <View style={styles.container}>
        <Modal
          style={styles.modalTop}
          isVisible={this.props.isVisible2}
          animationIn={"slideInRight"}
          animationOut={"slideOutLeft"}
          backdropColor={"black"}
          backdropOpacity={0.3}
        >
          <View style={styles.modalContent}>
            <TouchableHighlight
              style={{ width: "35%" }}
              onPress={this.props.onCloseModal2}
            >
              <Icon name="chevron-left" size={20} color="white" />
            </TouchableHighlight>
            <ScrollView style={styles.container}>
              <View style={{ flex: 1, marginTop: 20, color: "withe" }}>
                <Text style={styles.titulo1}>Devolución Parcial</Text>
                <ScrollView style={styles.container}>
                  <SmartPicker
                    selectedValue={this.props.title2}
                    label="Selecciona el motivo de devolución"
                    onValueChange={(title2) =>
                      this.props.onChangeTitle2(title2)
                    }
                  >
                    <Picker.Item label="" key="" value="" />
                    {itemsInPicker}
                  </SmartPicker>
                </ScrollView>
              </View>
            </ScrollView>
            <TouchableHighlight
              style={styles.button}
              onPress={this.props.devolverPed}
            >
              <Text style={styles.buttonText}>
                {cancelarPedido} Devolver Producto
              </Text>
            </TouchableHighlight>
          </View>
        </Modal>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  titulo1: {
    textAlign: "center",
    backgroundColor: "transparent",
    color: "white",
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(2) : responsiveFontSize(2.0),
    marginBottom: "3%",
  },
  modalTop: {
    justifyContent: "flex-start",
    marginTop: 50,
  },
  modalContent: {
    backgroundColor: "#3483D8",
    padding: 20,
    borderRadius: 5,
  },
  input: {
    marginBottom: 5,
    height: 40,
    borderColor: "#ccc",
    borderWidth: 1,
    borderRadius: 3,
    color: "white",
  },
  button: {
    backgroundColor: "red",
    paddingTop: 15,
    paddingBottom: 15,
    marginTop: 5,
    borderRadius: 6,
  },
  buttonText: {
    textAlign: "center",
    color: "white",
  },
  container: {
    color: "transparent",
  },
});
