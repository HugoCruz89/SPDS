import React, { Component } from "react";
import { StyleSheet, View, Alert, Platform } from "react-native";
import { Actions } from "react-native-router-flux";
import HeaderContenido from "../Home/HeaderContenido";
import { getPedidos } from "../../LlamadasRest/MyHTTP";
import ItemsApi from "../AperturaCliente/ItemPedidosApi";
import { showLoading, hideLoading } from "react-native-notifyer";
import { responsiveFontSize } from "react-native-responsive-dimensions";
import AsyncStorage from "@react-native-community/async-storage";
const ID_STG = "numeroSocio";
const FECHAAPERTURA_STG = "fechaApertura";
const RUTA_STG = "ruta";
export default class AperturaClienteHome extends Component {
  constructor(props) {
    super(props);
    this.getDatos();
    this.state = {
      datos: [],
    };
  }

  finalizarRuta = () => {
    Actions.home();
  };

  async getDatos() {
    showLoading();
    let idOperador = await AsyncStorage.getItem(ID_STG);
    let fechaApertura = await AsyncStorage.getItem(FECHAAPERTURA_STG);
    let idRuta = await AsyncStorage.getItem(RUTA_STG);
    getPedidos(idOperador, fechaApertura, idRuta)
      .then((data) => {
        if (data == null) {
          Alert.alert(
            "¡Aviso!",
            "Debes de iniciar ruta para poder acceder a los clientes ",
            [{ text: "OK", onPress: this.finalizarRuta }],
            { cancelable: false }
          );
        } else {
          this.setState({ datos: data });
        }
      })
      .then((data) => hideLoading())
      .catch((error) => hideLoading());
  }

  home() {
    Actions.home();
  }

  render() {
    const datos = this.state.datos;
    return (
      <View style={{ flex: 1 }}>
        <HeaderContenido home={this.home.bind(this)} />

        <View style={styles.containerPrincipal}>
          <ItemsApi datos={datos} />
        </View>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  containerPrincipal: {
    flex: 2,
    backgroundColor: "#fcfcff",
  },
  titulo1: {
    marginTop: "10%",
    textAlign: "center",
    backgroundColor: "transparent",
    color: "black",
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(2) : responsiveFontSize(3.0),
  },
});
