import React, { Component } from "react";
import {
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  Alert,
  RefreshControl,
  Platform,
} from "react-native";
import AsyncStorage from "@react-native-community/async-storage";
import ListView from "deprecated-react-native-listview";
import { Actions } from "react-native-router-flux";
import Icon from "react-native-vector-icons/Ionicons";
import { getPedidos } from "../../LlamadasRest/MyHTTP";
import { showLoading, hideLoading } from "react-native-notifyer";
import { responsiveFontSize } from "react-native-responsive-dimensions";
const ID_STG = "numeroSocio";
const URi_STG = "url";
const RUTA_STG = "ruta";
const IDPLANTA_STG = "idplanta";
const FECHAAPERTURA_STG = "fechaApertura";

export default class ItemsPedidosApi extends Component {
  constructor(props) {
    super(props);
    this.getDatos();
    const ds = new ListView.DataSource({
      rowHasChanged: (r1, r2) => r1 !== r2,
    });

    this.state = {
      dataSourcePedidos: ds,
      rfc: "",
      refreshing: false,
      url: "",
      idCliente: "",
      fechaCarga: "",
      idPlanta: "",
      idRuta: "",
    };
  }

  async getDatos() {
    let rfc = await AsyncStorage.getItem(ID_STG);
    let url = await AsyncStorage.getItem(URi_STG);
    let ruta = await AsyncStorage.getItem(RUTA_STG);
    let planta = await AsyncStorage.getItem(IDPLANTA_STG);
    let fechaApertura = await AsyncStorage.getItem(FECHAAPERTURA_STG);
    this.setState({
      rfc: rfc,
      url: url,
      idPlanta: planta,
      idRuta: ruta,
      fechaCarga: fechaApertura,
    });
  }

  _onRefresh() {
    this.setState({ refreshing: true });
    getPedidos(this.state.rfc, this.state.fechaCarga, this.state.idRuta).then(
      (data) =>
        this.setState({
          dataSourcePedidos: this.state.dataSourcePedidos.cloneWithRows(data),
          refreshing: false,
        })
    );
  }

  componentDidMount() {
    this.upDateDataSource(this.props.datos);
  }

  UNSAFE_componentWillReceiveProps(newProps) {
    if (newProps.datos !== this.props.datos) {
      this.upDateDataSource(newProps.datos);
    }
  }
  upDateDataSource = (data) => {
    this.setState({
      dataSourcePedidos: this.state.dataSourcePedidos.cloneWithRows(data),
    });
  };

  PedidoNoEntregadoValidado = () => {
    showLoading();
    const idCliente = this.state.idCliente;
    const fechaCarga = this.state.fechaCarga;
    const idPlanta = this.state.idPlanta;
    const idRuta = this.state.idRuta;
    const url = this.state.url;
    fetch(url + "PedidoNoEntregados/", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        IdCliente: idCliente,
        FechaCarga: fechaCarga,
        IdRuta: idRuta,
        IdPlanta: idPlanta,
      }),
    })
      .then(function (response) {
        if (response.ok) {
          hideLoading();
        } else {
          hideLoading();
          Alert.alert(
            "¡Algo salio mal!",
            "Intenta nuevamente, error:" + response._bodyInit,
            [
              {
                text: "Cancelar",
                onPress: () => {},
              },
              { text: "OK", onPress: () => {} },
            ],
            { cancelable: false }
          );
          const error = new Error(response.statusText);
          error.response = response;
          throw error;
        }
      })
      .then(() => this._onRefresh())
      .catch((error) => {});
  };

  PedidoNoEntregado(idCliente, fechaCarga) {
    this.setState({
      idCliente: idCliente,
      fechaCarga: fechaCarga,
    });
    Alert.alert(
      "¡Los pedidos de este cliente no seran entregados!",
      "Este proceso ya no podrá revertirse, y no podras consultar o hacer entrega de este cliente",
      [
        { text: "Cancelar", onPress: () => {}},
        { text: "OK", onPress: this.PedidoNoEntregadoValidado },
      ],
      { cancelable: false }
    );
  }

  MostrarDetallePedidos(pedidos) {
    Actions.detalleClienteHome({ pedidos });
  }

  llammaVistaAperturaClienteEntrega(PedidosConDetalle, telefono, idCliente) {
    Actions.aperturaClienteEntrega({ PedidosConDetalle, telefono, idCliente });
  }
  render() {
    const aperturaCliente = (
      <Icon name="ios-clipboard" size={35} color="#3483D8" marginRight="5%" />
    );

    const pedidoNoEntregado = (
      <Icon name="ios-filing" size={30} color="#3483D8" />
    );

    return (
      <View style={{ flex: 1 }}>
        <ListView
          refreshControl={
            <RefreshControl
              refreshing={this.state.refreshing}
              onRefresh={this._onRefresh.bind(this)}
            />
          }
          style={styles.list}
          enableEmptySections
          dataSource={this.state.dataSourcePedidos}
          renderRow={({ ...datos }) => {
            return (
              <View style={styles.row}>
                <View style={styles.containerPrincipal}>
                  <View style={styles.containerDatos}>
                    <View
                      style={{
                        flexDirection: "column",
                        alignItems: "flex-start",
                        width: "90%",
                      }}
                    >
                      <Text style={styles.titulo2}>
                        {datos.nombreCliente} id:{datos.idCliente}
                      </Text>
                      <Text style={styles.Informacion}>{datos.domicilio}</Text>
                      {datos.pedidosSinFinalizar == 0 ? (
                        <Text style={styles.Informacion1}>
                          Cliente Atendido
                        </Text>
                      ) : null}
                      {datos.pedidosNoEntregados > 0 ? (
                        <Text style={styles.Informacion1}>
                          Pedido NO Entregado
                        </Text>
                      ) : null}
                      {datos.pedidosNoEntregados > 0 ||
                      datos.pedidosSinFinalizar == 0 ? null : (
                        <View
                          style={{
                            flexDirection: "row",
                            top: "3%",
                            justifyContent: "space-between",
                            width: "60%",
                          }}
                        >
                          <TouchableOpacity
                            style={{ width: 40, top: "-5%" }}
                            onPress={() =>
                              this.PedidoNoEntregado(
                                datos.idCliente,
                                datos.fechaCarga
                              )
                            }
                          >
                            {pedidoNoEntregado}
                          </TouchableOpacity>
                          <Text style={styles.titulo3}>Conservar Pedido</Text>
                        </View>
                      )}
                    </View>
                    <View
                      style={{
                        flexDirection: "column",
                        alignItems: "center",
                        marginLeft: "4%",
                      }}
                    >
                      {datos.pedidosNoEntregados > 0 ? null : (
                        <TouchableOpacity
                          onPress={() =>
                            this.llammaVistaAperturaClienteEntrega(
                              datos.pedidosConDetalle,
                              datos.telefonoCliente,
                              datos.idCliente
                            )
                          }
                        >
                          <View style={styles.containerIconos}>
                            {aperturaCliente}
                          </View>
                          <View style={styles.containerTextDeIconos}>
                            <Text style={styles.InformacionIcono}>
                              Entrega{"\n"}Producto
                            </Text>
                          </View>
                        </TouchableOpacity>
                      )}
                    </View>
                  </View>
                </View>
              </View>
            );
          }}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  containerTextDeIconos: {
    left: "15%",
  },
  containerIconos: {
    flexDirection: "column",
    alignItems: "center",
    backgroundColor: "#fcfcff",
    borderRadius: 50,
    width: 60,
    height: 60,
    padding: 10,

    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
  },

  containerDatos: {
    flexDirection: "row",
    justifyContent: "space-between",
    padding: 10,
  },

  containerPrincipal: {
    padding: 5,
    marginLeft: 10,
    width: "80%",
  },

  titulo2: {
    textAlign: "left",
    backgroundColor: "transparent",
    color: "black",
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(2.8) : responsiveFontSize(2.6),
  },
  titulo3: {
    textAlign: "left",
    backgroundColor: "transparent",
    color: "black",
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(1.8) : responsiveFontSize(1.8),
  },

  logo: {
    //width: 140,
    width: 50,
    height: 50,
    borderRadius: 50,
    marginTop: 10,
  },

  ColorTexto: {
    color: "#434346",
    fontSize: 24,
  },
  column: {
    flexDirection: "column",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 10,
    backgroundColor: "transparent",
    marginBottom: 5,
    marginHorizontal: 5,
    paddingHorizontal: 5,
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "stretch",
    paddingVertical: 0,
    backgroundColor: "#ffffff",
    marginBottom: 15,
    marginTop: 5,
    marginHorizontal: 15,
    paddingHorizontal: 5,
    borderRadius: 7,
    borderWidth: 1,
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 1,
  },
  list: {
    marginTop: 5,
  },
  Informacion1: {
    backgroundColor: "transparent",
    color: "#3483D8",
    marginTop: 0,
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(1.5) : responsiveFontSize(2.2),
  },
  Informacion: {
    backgroundColor: "transparent",
    color: "#434346",
    marginTop: 0,
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(1.5) : responsiveFontSize(2.2),
  },
  InformacionIcono: {
    backgroundColor: "transparent",
    color: "#434346",
    marginTop: 0,
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(1.5) : responsiveFontSize(1.5),
  },
});
