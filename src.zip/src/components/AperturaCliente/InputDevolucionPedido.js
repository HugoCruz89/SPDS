import React, { Component } from "react";
import {
  Text,
  View,
  StyleSheet,
  TextInput,
  TouchableHighlight,
  Picker,
  ScrollView,
  Platform,
  TouchableOpacity,
} from "react-native";
import { responsiveFontSize } from "react-native-responsive-dimensions";
import Modal from "react-native-modal";
import Icon from "react-native-vector-icons/FontAwesome";
import Icon2 from "react-native-vector-icons/MaterialIcons";
import SmartPicker from "react-native-smart-picker";
import { getMotivosDevolucion } from "../../LlamadasRest/MyHTTP";

export default class InputDevolucionPedido extends Component {
  constructor(props) {
    super(props);

    this.state = {
      catalogo: [],
      url: "",
    };
  }

  async getUrl() {
    getMotivosDevolucion()
      .then((data) => {
        this.setState({
          catalogo: data,
        });
      })
      .catch((mensaje) => {});
  }

  componentWillMount() {
    this.getUrl();
  }

  render() {
    const itemsInPicker = this.state.catalogo.map((data) => {
      return (
        <Picker.Item label={data.descripcion} key={data.id} value={data.id} />
      );
    });
    const cancelarPedido = (
      <Icon name="remove" size={25} color="white" marginRight="5%" />
    );
    const closeModal = <Icon name="chevron-left" size={20} color="white" />;
    const cleanInput = <Icon2 name="clear" size={20} color="red" />;
    const divCajasTapas = (
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          width: "97%",
          marginTop: 5,
        }}
      >
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            width: "45%",
            marginRight: "3%",
          }}
        >
          <Text style={styles.titulo2}>Cajas{"\n"}Vacías</Text>
          <TextInput
            keyboardType="numeric"
            returnKeyType="next"
            value={this.props.cajasDevolucion}
            underlineColorAndroid="transparent"
            placeholderTextColor="rgba(10,10,10,0.5)"
            style={styles.inputCajasTapas}
            onChangeText={(cajasDevolucion) =>
              this.props.onChangeCajasDev(cajasDevolucion)
            }
          />
          <TouchableOpacity onPress={this.props.ClearInputCajas}>
            {cleanInput}
          </TouchableOpacity>
        </View>
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            width: "45%",
          }}
        >
          <Text style={styles.titulo2}>Tapas{"\n"}Vacías</Text>
          <TextInput
            keyboardType="numeric"
            returnKeyType="next"
            value={this.props.tapasDevolucion}
            underlineColorAndroid="transparent"
            placeholderTextColor="rgba(10,10,10,0.5)"
            style={styles.inputCajasTapas}
            onChangeText={(tapasDevolucion) =>
              this.props.onChangeTapasDev(tapasDevolucion)
            }
          />
          <TouchableOpacity onPress={this.props.ClearInputTapas}>
            {cleanInput}
          </TouchableOpacity>
        </View>
      </View>
    );

    return (
      <View style={styles.container}>
        <Modal
          style={styles.modalTop}
          isVisible={this.props.isVisible}
          animationIn={"slideInRight"}
          animationOut={"slideOutLeft"}
          backdropColor={"black"}
          backdropOpacity={0.3}
        >
          <View style={styles.modalContent}>
            <TouchableHighlight
              style={{ width: "35%" }}
              onPress={this.props.onCloseModal}
            >
              {closeModal}
            </TouchableHighlight>
            <ScrollView style={styles.container}>
              {divCajasTapas}

              <View style={{ flex: 1, marginTop: 4, color: "withe" }}>
                <ScrollView style={styles.container}>
                  <SmartPicker
                    selectedValue={this.props.title}
                    label="Selecciona el motivo de devolución"
                    onValueChange={(title) => this.props.onChangeTitle(title)}
                  >
                    <Picker.Item label="" key="" value="" />
                    {itemsInPicker}
                  </SmartPicker>
                </ScrollView>
              </View>
            </ScrollView>
            <TouchableOpacity
              style={styles.button}
              onPress={this.props.onHandleItems}
            >
              <Text style={styles.buttonText}>
                {cancelarPedido} Devolver Pedido
              </Text>
            </TouchableOpacity>
          </View>
        </Modal>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  modalTop: {
    justifyContent: "flex-start",
    marginTop: 50,
    backgroundColor: "transparent",
  },
  modalContent: {
    backgroundColor: "#3483D8",
    padding: 20,
    borderRadius: 5,
  },
  input: {
    marginBottom: 5,
    height: 40,
    borderColor: "#ccc",
    borderWidth: 1,
    borderRadius: 3,
    color: "white",
  },
  button: {
    backgroundColor: "red",
    paddingTop: 15,
    paddingBottom: 15,
    marginTop: 5,
    borderRadius: 6,
  },
  buttonText: {
    textAlign: "center",
    color: "white",
  },
  container: {
    color: "white",
  },
  titulo2: {
    backgroundColor: "transparent",
    color: "white",
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(2) : responsiveFontSize(1.7),
  },
  inputCajasTapas: {
    marginBottom: 15,
    height: 35,
    borderWidth: 1,
    borderRadius: 5,
    backgroundColor: "#ffffff",
    width: "50%",
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
    padding: 0,
    paddingLeft: 7,
  },
});
