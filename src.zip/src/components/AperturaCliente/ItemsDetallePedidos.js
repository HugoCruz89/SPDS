//                        // 
// no se ocupa esta vista //
//                        // 

{/*
import React,{Component} from 'react';
import {Text,View,StyleSheet,
  ListView,TouchableOpacity,ScrollView,Alert,AsyncStorage,RefreshControl,Platform,Image
} from 'react-native';
import {Actions} from 'react-native-router-flux'
import Icon from 'react-native-vector-icons/Ionicons';
import {getPedidos} from '../../api-AperturaCliente'
import { responsiveHeight, responsiveWidth, responsiveFontSize } from 'react-native-responsive-dimensions';
const ID_STG='numeroSocio'
export default class ItemsDetallePedidos extends Component {

constructor(props) {
  super(props);
   this.getDatos()  
  const ds= new ListView.DataSource({rowHasChanged:(r1,r2)=> r1 !== r2})
   
  this.state ={
    dataSourcePedidos:ds,
     rfc:'',
     refreshing: false,
  }
  
}


 async getDatos()
    {
      let rfc=await AsyncStorage.getItem(ID_STG);      
       this.setState({
          rfc:rfc,
           
        })
     }
 

 _onRefresh() {
 
    this.setState({refreshing: true}); 
      
      getPedidos(this.state.rfc)
     .then((data)=>this.setState({ 
      dataSourcePedidos: this.state.dataSourcePedidos.cloneWithRows(data),
      refreshing: false, 
      }))
   
  }


componentDidMount(){
  this.upDateDataSource(this.props.datos)
}

componentWillReceiveProps(newProps){
    
    if(newProps.datos !== this.props.datos){
         this.upDateDataSource(newProps.datos)
        } 
  }
upDateDataSource = data =>{
          this.setState({
          dataSourcePedidos: this.state.dataSourcePedidos.cloneWithRows(data) 
      })
 }


render(){

   const detallePedido = (           
              <Icon
                name="ios-paper"
                size={35}
                color="white"
              />
              ) 

          
	return(
      <View style={{flex: 1}}>
      	     <ListView
             
      	       style={styles.list}
      	       enableEmptySections
      	       dataSource={this.state.dataSourcePedidos} 
      	       renderRow={({...datos})=>{     		
      		
      		return(
                
          
      		  <View style={styles.row}>
                {detallePedido}
                <View style={styles.containerPrincipal} >
                      <Text style={styles.titulo2}>{datos.Descripcio}</Text>
                      <Text style={styles.titulo2}>{datos.Descripcion}</Text>
                       <Text style={styles.Informacion}>Codigo: {datos.Material}</Text>
                      <Text style={styles.Informacion}>Peso: {datos.Peso} kg</Text>
                       <Text style={styles.Informacion}>Cantidad: {datos.Cantidad}</Text>
                        <Text style={styles.Informacion}>Unidad Venta: {datos.UnidadVenta}</Text>           
                </View>
              <View style={styles.column}>    
       
              </View>             
            </View>
      			)
      		}}
      	/>    
    </View>      
		  );
      }	
}

const styles = StyleSheet.create({
 

containerIconos:{
  flexDirection: 'column',
  alignItems: 'center', 
  backgroundColor: '#09467F',
  borderRadius: 50,
  width: 60,
  height: 60,
  padding: 10,
},


containerDatos:{
  flexDirection: 'row',
  justifyContent:  'space-between',
  padding: 10.
},

 containerPrincipal:{
  padding: 5,
  marginLeft: 10,
  width: '80%'
 },

 titulo2:{
    backgroundColor: 'transparent',
    color: '#98D17B',
    fontSize: Platform.OS === 'ios' ? responsiveFontSize(2.8): responsiveFontSize(2.3),
  },

 logo:{
    //width: 140,
    width: 50,
    height: 50,
    borderRadius: 50,
    marginTop: 10,
  },


ColorTexto:{
      color: 'white',
      fontSize: 24
},
column:{
  flexDirection: 'column',
  justifyContent:  'space-between', 
  alignItems:'center', 
  paddingVertical: 10,
  backgroundColor: 'transparent',
  marginBottom: 5,
  marginHorizontal: 5, 
  paddingHorizontal: 5

},
row:{
  flexDirection: 'row',
  justifyContent:  'space-between', 
  alignItems:'stretch', 
  paddingVertical: 10,
  backgroundColor: 'rgba(255, 255, 255, .10)',
  marginBottom: 15,
  marginHorizontal: 15, 
  paddingHorizontal: 5,
  borderRadius: 7,

},
list:{
  marginTop:5,
  

},

Informacion :{
    backgroundColor: 'transparent',
    color: 'white',
    marginTop: 0,
    fontSize: Platform.OS === 'ios' ? responsiveFontSize(1.3): responsiveFontSize(2),
   
  },
})*/}


