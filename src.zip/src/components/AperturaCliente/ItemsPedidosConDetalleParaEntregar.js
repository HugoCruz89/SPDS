import React, { Component } from "react";
import {
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  Alert,
  RefreshControl,
  Platform,
} from "react-native";
import ListView from "deprecated-react-native-listview";
import Icon from "react-native-vector-icons/Ionicons";
import { getDatosMerma } from "../../api-MermaActualiza";
import AsyncStorage from "@react-native-community/async-storage";
import { responsiveFontSize } from "react-native-responsive-dimensions";
import Input from "../AperturaCliente/InputKilogramosEntregados";

const URi_STG = "url";

export default class ItemsPedidosConDetalleParaEntregar extends Component {
  constructor(props) {
    super(props);
    const ds = new ListView.DataSource({
      rowHasChanged: (r1, r2) => r1 !== r2,
    });
    this.getUrl();
    this.state = {
      dataSourcePedidosConDetalle: ds,
      rfc: "",
      refreshing: false,
      idPedido: "",
      mermaDetalle: "0",
      estatusPedido: "",
      idFactura: "",
      latitud: null,
      longitud: null,
      error: null,
      url: "",
      isVisibleModal: false,
      Material: "",
      UnidadVenta: "",
      Peso: "",
      ///////////////
      visualCajas: false,
      visualPiezas: false,
      /////////////
      pzasMerma: "0",
      pzasDevueltas: "0",
      cajasDevueltas: "0",
      kilogramosDevueltos: "0",
      CantidadPiezasOCajas: "",
      unidadVenta: "",
      cajasXDetalle: "",
      cajasDevueltasXDetalle: "0",
    };
    this.handleModalShowKilogramos = this.handleModalShowKilogramos.bind(this);
    this.handleModalHideKilogramos = this.handleModalHideKilogramos.bind(this);
    this.addMerma = this.addMerma.bind(this);
    this.onChangeMerma = this.onChangeMerma.bind(this);

    this.onChangeCajasDevueltas = this.onChangeCajasDevueltas.bind(this);
    this.onChangePzasMerma = this.onChangePzasMerma.bind(this);
    this.onChangePzasDevueltas = this.onChangePzasDevueltas.bind(this);
    this.onChangeKilogramosDevueltos = this.onChangeKilogramosDevueltos.bind(
      this
    );
    this.onChangeCajasDevueltasXDetalle = this.onChangeCajasDevueltasXDetalle.bind(
      this
    );
  }

  ////////--------Metodos para mostrar modal de kilogramos Entregados------////////
  handleModalShowKilogramos(
    Material,
    UnidadVenta,
    Peso,
    CantidadPiezasOCajas,
    cajasXDetalle
  ) {
    if (UnidadVenta === "EA") {
      this.setState({
        visualPiezas: true,
        CantidadPiezasOCajas: CantidadPiezasOCajas,
        unidadVenta: "EA",
        cajasXDetalle: cajasXDetalle,
        isVisibleModal: true,
        Material: Material,
        UnidadVenta: UnidadVenta,
        Peso: Peso,
      });
    } else {
      this.setState({
        visualCajas: true,
        CantidadPiezasOCajas: CantidadPiezasOCajas,
        unidadVenta: "CS",
        isVisibleModal: true,
        Material: Material,
        UnidadVenta: UnidadVenta,
        Peso: Peso,
      });
    }
  }
  handleModalHideKilogramos() {
    this.setState({
      isVisibleModal: false,
      visualCajas: false,
      visualPiezas: false,
    });
  }
  //////////------------------------------------///////////////////////////////////////////

  async getUrl() {
    let url = await AsyncStorage.getItem(URi_STG);
    this.setState({
      url: url,
    });
  }

  componentDidMount() {
    this.upDateDataSource(this.props.datos);
    const idPedido = this.props.idPedido;
    const estatusPedido = this.props.estatusPedido;
    const idFactura = this.props.idFactura;
    this.setState({
      idPedido: idPedido,
      estatusPedido: estatusPedido,
      idFactura: idFactura,
    });
  }

  componentWillReceiveProps(newProps) {
    if (newProps.datos !== this.props.datos) {
      this.upDateDataSource(newProps.datos);
    }
  }
  upDateDataSource = (data) => {
    this.setState({
      dataSourcePedidosConDetalle: this.state.dataSourcePedidosConDetalle.cloneWithRows(
        data
      ),
    });
  };
  onChangeCajasDevueltasXDetalle(value) {
    this.setState({ cajasDevueltasXDetalle: value });
  }

  onChangeCajasDevueltas(value) {
    this.setState({ cajasDevueltas: value });
  }

  onChangePzasMerma(value) {
    this.setState({ pzasMerma: value });
  }

  onChangePzasDevueltas(value) {
    this.setState({ pzasDevueltas: value });
  }

  onChangeKilogramosDevueltos(value) {
    this.setState({ kilogramosDevueltos: value });
  }

  onChangeMerma(value) {
    this.setState({ mermaDetalle: value });
  }
  metodoPrueba() {
    this.setState({
      mermaDetalle: "0",
      estatusPedido: "",
    });
    this._onRefresh();
  }

  devolverBind(idProducto, unidadVenta) {
    this.props.handleModalShow2(idProducto, unidadVenta, this.state.idPedido);
  }
  /////////////////////////////////////////////
  //metodo que me refrescaba solo card actual//
  /////////////////////////////////////////////
  _onRefresh() {
    this.setState({
      refreshing: true,
    });

    getDatosMerma(
      this.state.idPedido,
      this.state.idFactura,
      this.state.url
    ).then((data) => {
      this.setState({
        mermaDetalle: "",
        dataSourcePedidosConDetalle: this.state.dataSourcePedidosConDetalle.cloneWithRows(
          data[0].listaDetalle
        ),
        refreshing: false,
      });
    });
  }
  /// ya no se ocupa este metodo//////////////

  //// este metodo ahora guarda los kilos entregeados en lugar de merma
  //// pero se dejo el metodo con los parametros anteriores
  addMerma() {
    this.handleModalHideKilogramos();
    const pzasMerma = this.state.pzasMerma;
    const pzasDevueltas = this.state.pzasDevueltas;
    const unidadVenta = String(this.state.UnidadVenta);
    const cantidadPiezasOCajas = this.state.CantidadPiezasOCajas;
    const cajasDevueltas = this.state.cajasDevueltas;
    const peso = this.state.Peso;
    const kilogramosDevueltos = this.state.kilogramosDevueltos;
    ///esto es para piezas
    const cajasDevueltasXDetalle = this.state.cajasDevueltasXDetalle;
    const cajasXDetalle = this.state.cajasXDetalle;
    //--la variable mermaDetalle ahora va alojar los kilos entregados------------//
    const merma = this.state.mermaDetalle;
    /// validacion de cajas que no entreguen mas de las que traen
    if (unidadVenta == "CS") {
      if (!Number.isInteger(parseFloat(cajasDevueltas))) {
        Alert.alert(
          "Error de captura!",
          "No se aceptan valores decimales en cajas",
          [{ text: "OK", onPress: () => {} }],
          { cancelable: false }
        );
        this.setState({
          cajasDevueltas: "0",
          kilogramosDevueltos: "0",
          mermaDetalle: "0",
        });
      } else if (parseInt(cajasDevueltas) == parseInt(cantidadPiezasOCajas)) {
        Alert.alert(
          "Error de captura!",
          "El numero de cajas devueltas no puede ser igual al numero de cajas totales del pedido, para devolver todas utiliza devolución por producto",
          [{ text: "OK", onPress: () => {} }],
          { cancelable: false }
        );
        this.setState({
          cajasDevueltas: "0",
          kilogramosDevueltos: "0",
          mermaDetalle: "0",
        });
      } else if (
        parseInt(cajasDevueltas) < 0 ||
        parseInt(kilogramosDevueltos) < 0 ||
        parseInt(merma) < 0
      ) {
        Alert.alert(
          "Error de captura!",
          "No se aceptan valores negativos",
          [{ text: "OK", onPress: () => {} }],
          { cancelable: false }
        );
        this.setState({
          cajasDevueltas: "0",
          kilogramosDevueltos: "0",
          mermaDetalle: "0",
        });
      } else if (
        (cajasDevueltas == "0" && kilogramosDevueltos != "0") ||
        (cajasDevueltas != "0" && kilogramosDevueltos == "0")
      ) {
        Alert.alert(
          "Error de captura!",
          "Es necesario capturar cajas devueltas y kilogramos devueltos",
          [{ text: "OK", onPress: () => {} }],
          { cancelable: false }
        );
        this.setState({
          cajasDevueltas: "0",
          kilogramosDevueltos: "0",
          mermaDetalle: "0",
        });
      } else {
        //valido que no entregues mas cajas de las que tienes o que entregues con numero negativos
        if (
          parseInt(cajasDevueltas) > parseInt(cantidadPiezasOCajas) ||
          parseInt(cajasDevueltas) < 0
        ) {
          Alert.alert(
            "Error de captura!",
            "No puedes devolver mas cajas de las que traes o devolver menos de cero cajas",
            [{ text: "OK", onPress: () => {} }],
            { cancelable: false }
          );
          this.setState({
            cajasDevueltas: "0",
            kilogramosDevueltos: "0",
            mermaDetalle: "0",
          });
        } else {
          //valido si lo kilogramos devueltos no sean mayores que el peso total y de los kilogrmaos entregados
          const kilogramosDisponibles =
            parseFloat(peso) - parseFloat(kilogramosDevueltos);
          //valido que los kilogramosDevueltos no sean mayor ni menor que el peso
          if (
            parseFloat(kilogramosDevueltos) > parseFloat(peso) ||
            parseFloat(kilogramosDevueltos) < 0
          ) {
            Alert.alert(
              "Error de captura!",
              "No puedes devolver mas Kilogramos de lo que traes",
              [{ text: "OK", onPress: () => {} }],
              { cancelable: false }
            );
            this.setState({
              cajasDevueltas: "0",
              kilogramosDevueltos: "0",
              mermaDetalle: "0",
            });
          } else {
            if (merma > kilogramosDisponibles) {
              Alert.alert(
                "Error de captura!",
                "Al devolver " +
                  kilogramosDevueltos +
                  "kg, el limite de kilogramos para entregar es: " +
                  kilogramosDisponibles +
                  "kg",
                [{ text: "OK", onPress: () => {} }],
                { cancelable: false }
              );
              this.setState({
                cajasDevueltas: "0",
                kilogramosDevueltos: "0",
                mermaDetalle: "0",
              });
            } else {
              //si paso todas la validaciones mando ejecuto el metodo
              this.devolucionParcialValidado();
            }
          }
        }
      }
    } //unidad de venta ='EA'
    else {
      sumaPzasDevMerm = parseInt(pzasDevueltas) + parseInt(pzasMerma);
      //validacion para piezas
      if (
        !Number.isInteger(parseFloat(pzasDevueltas)) ||
        !Number.isInteger(parseFloat(pzasMerma)) ||
        !Number.isInteger(parseFloat(cajasDevueltasXDetalle))
      ) {
        Alert.alert(
          "Error de captura!",
          "No se aceptan valores decimales en piezas o cajas",
          [{ text: "OK", onPress: () => {} }],
          { cancelable: false }
        );
        this.setState({
          cajasDevueltas: "0",
          kilogramosDevueltos: "0",
          mermaDetalle: "0",
        });
      } else if (
        parseInt(pzasMerma) < 0 ||
        parseInt(pzasDevueltas) < 0 ||
        parseInt(kilogramosDevueltos) < 0 ||
        parseInt(merma) < 0 ||
        parseInt(cajasDevueltasXDetalle) < 0
      ) {
        Alert.alert(
          "Error de captura!",
          "No se aceptan valores negativos",
          [{ text: "OK", onPress: () => {} }],
          { cancelable: false }
        );
        this.setState({
          pzasMerma: "0",
          pzasDevueltas: "0",
          kilogramosDevueltos: "0",
          mermaDetalle: "0",
        });
      } else if (parseInt(cajasDevueltasXDetalle) > parseInt(cajasXDetalle)) {
        Alert.alert(
          "Error de captura!",
          "No puedes devolver más cajas de las que trae tu pedido",
          [{ text: "OK", onPress: () => {} }],
          { cancelable: false }
        );
        this.setState({
          pzasMerma: "0",
          pzasDevueltas: "0",
          kilogramosDevueltos: "0",
          mermaDetalle: "0",
        });
      } else if (sumaPzasDevMerm > cantidadPiezasOCajas) {
        Alert.alert(
          "Error de captura!",
          "La suma de las piezas devueltas y piezas merma excede la cantidad permitida, verificar datos",
          [{ text: "OK", onPress: () => {} }],
          { cancelable: false }
        );
        this.setState({
          pzasMerma: "0",
          pzasDevueltas: "0",
          kilogramosDevueltos: "0",
          mermaDetalle: "0",
        });
      } else if (
        (pzasDevueltas == "0" && kilogramosDevueltos != "0") ||
        (pzasDevueltas != "0" && kilogramosDevueltos == "0")
      ) {
        Alert.alert(
          "Error de captura!",
          "Es necesario capturar piezas devueltas y kilogramos devueltos",
          [{ text: "OK", onPress: () => {} }],
          { cancelable: false }
        );
        this.setState({
          pzasMerma: "0",
          pzasDevueltas: "0",
          kilogramosDevueltos: "0",
          mermaDetalle: "0",
        });
      } else {
        //valido que no entregues mas pzas de las que tienes o que entregues con numero negativos
        if (
          parseInt(pzasDevueltas) > parseInt(cantidadPiezasOCajas) ||
          parseInt(pzasDevueltas) < 0
        ) {
          Alert.alert(
            "Error de captura!",
            "No puedes devolver mas piezas de las que traes o devolver menos de cero piezas",
            [{ text: "OK", onPress: () => {} }],
            { cancelable: false }
          );
          this.setState({
            pzasMerma: "0",
            pzasDevueltas: "0",
            kilogramosDevueltos: "0",
            mermaDetalle: "0",
          });
        } else {
          //valido si lo kilogramos devueltos no sean mayores que el peso total y de los kilogrmaos entregados

          const kilogramosDisponibles =
            parseFloat(peso) - parseFloat(kilogramosDevueltos);

          //valido que los kilogramosDevueltos no sean mayor ni menor que el peso
          if (
            parseFloat(kilogramosDevueltos) > parseFloat(peso) ||
            parseFloat(kilogramosDevueltos) < 0
          ) {
            Alert.alert(
              "Error de captura!",
              "No puedes devolver mas Kilogramos de lo que traes",
              [{ text: "OK", onPress: () => {} }],
              { cancelable: false }
            );
            this.setState({
              pzasMerma: "0",
              pzasDevueltas: "0",
              kilogramosDevueltos: "0",
              mermaDetalle: "0",
            });
          } else {
            if (merma > kilogramosDisponibles) {
              Alert.alert(
                "Error de captura!",
                "Al devolver " +
                  kilogramosDevueltos +
                  "kg, el limite de kilogramos para entregar es: " +
                  kilogramosDisponibles +
                  "kg",
                [{ text: "OK", onPress: () => {} }],
                { cancelable: false }
              );
              this.setState({
                pzasMerma: "0",
                pzasDevueltas: "0",
                kilogramosDevueltos: "0",
                mermaDetalle: "0",
              });
            } else {
              //si paso todas la validaciones ejecuto el metodo
              this.devolucionParcialValidado();
            }
          }
        }
      }
    }
  }

  //metodo para devolver parcial o entrega total de kilogramos
  devolucionParcialValidado() {
    const idpro = String(this.state.Material);
    const unidadVenta = String(this.state.UnidadVenta);
    //--Nota:--------------------------------------------------------------------//
    //--la variable mermaDetalle ahora va alojar los kilos entregados------------//
    const merma = this.state.mermaDetalle;
    const peso = this.state.Peso;
    const cajasDevueltasXDetalle = this.state.cajasDevueltasXDetalle;
    const kilogramosDevueltos = this.state.kilogramosDevueltos;
    if (parseInt(merma) <= 0) {
      Alert.alert(
        "¡Error de captura!",
        "No puedes entregar 0 kilogramos o menos de 0 ",
        [{ text: "OK", onPress: () => {} }],
        { cancelable: false }
      );
    } else {
      if (parseInt(merma) > parseInt(peso)) {
        Alert.alert(
          "¡Kilogramos entregados no puede ser mayor que el peso!",
          "Agregar Kilogramo entregados menor que el peso",
          [{ text: "OK", onPress: () => {} }],
          { cancelable: false }
        );
      } else {
        const url = this.state.url;
        fetch(url + "Merma/", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            idPedido: this.state.idPedido,
            idProducto: idpro,
            merma: merma,
            unidadVenta: unidadVenta,
            pzaMerma: this.state.pzasMerma,
            pzasDevueltas: this.state.pzasDevueltas,
            cajasDevueltas: this.state.cajasDevueltas,
            kilogramosDevueltos: kilogramosDevueltos,
            cajasDevueltasXDetalle: cajasDevueltasXDetalle,
          }),
        })
          .then(function (response) {
            if (response.ok) {
            } else {
              Alert.alert(
                "Error!",
                "Asegurate de tener conexión a internet",
                [{ text: "OK", onPress: () => {} }],
                { cancelable: false }
              );
              const error = new Error(response.statusText);
              error.response = response;
              throw error;
            }
          })
          .then(() => this.metodoPrueba())
          .catch((error) => {});
      }
    }
  } // fin de metodo devolucionParcialValidado

  render() {
    const input = (
      <Input
        onChangeCajasDevueltas={this.onChangeCajasDevueltas}
        onChangePzasMerma={this.onChangePzasMerma}
        onChangePzasDevueltas={this.onChangePzasDevueltas}
        onChangeKilogramosDevueltos={this.onChangeKilogramosDevueltos}
        onChangeCajasDevueltasXDetalle={this.onChangeCajasDevueltasXDetalle}
        onChangeMerma={this.onChangeMerma}
        addMerma={this.addMerma}
        mermaDetalle={this.state.mermaDetalle}
        visualCajas={this.state.visualCajas}
        visualPiezas={this.state.visualPiezas}
        isVisibleModal={this.state.isVisibleModal}
        handleModalHideKilogramos={this.handleModalHideKilogramos}
      />
    );

    const entregaProducto = (
      <Icon
        name="ios-close-circle-outline"
        size={35}
        color="red"
        marginRight="5%"
        marginTop="5%"
      />
    );

    const addMerma = <Icon name="ios-calculator" size={30} color="#3483D8" />;
    return (
      <View style={{ flex: 1 }}>
        {input}
        <ListView
          refreshControl={<RefreshControl refreshing={this.state.refreshing} />}
          style={styles.list}
          enableEmptySections
          dataSource={this.state.dataSourcePedidosConDetalle}
          renderRow={({ ...datos }) => {
            return (
              <View style={styles.row}>
                <View style={{ flexDirection: "column" }}>
                  {datos.EstatusDetalle == "0" &&
                  datos.EstatusGlobalPedido == "0" ? (
                    <TouchableOpacity
                      onPress={() =>
                        this.devolverBind(datos.Material, datos.UnidadVenta)
                      }
                    >
                      {entregaProducto}
                    </TouchableOpacity>
                  ) : null}
                </View>
                <View style={styles.containerPrincipal}>
                  {datos.EstatusDetalle == "1" ? (
                    <Text style={styles.producto}>Producto Devuelto</Text>
                  ) : null}
                  <Text style={styles.titulo1}>{datos.Descripcion}</Text>
                  <Text style={styles.Informacion}>
                    Codigo: {datos.Material}
                  </Text>
                  <Text style={styles.Informacion}>Peso: {datos.Peso} kg</Text>
                  {datos.UnidadVenta == "EA" ? (
                    <Text style={styles.Informacion}>
                      Piezas: {parseInt(datos.CantidadPiezasOCajas)}
                    </Text>
                  ) : null}
                  {datos.UnidadVenta == "EA" ? (
                    <Text style={styles.Informacion}>
                      Piezas Entregadas:{" "}
                      {parseInt(datos.TotalDePiezasEntregadas)}
                    </Text>
                  ) : null}
                  <Text style={styles.Informacion}>
                    Cajas Embarcadas: {parseInt(datos.Cantidad)}
                  </Text>
                  <Text style={styles.Informacion}>
                    Unidad Venta: {datos.UnidadVenta}
                  </Text>
                  {datos.Peso == datos.TotalKilogramosEntregados ? (
                    <Text style={styles.Informacion}>
                      Kg T Entregados:{datos.TotalKilogramosEntregados} kg
                    </Text>
                  ) : (
                    <Text style={styles.InformacionMerma}>
                      Kg Entregados: {datos.TotalKilogramosEntregados} kg
                    </Text>
                  )}
                  {datos.cajasDevueltasConProducto != "0" &&
                  datos.UnidadVenta == "CS" ? (
                    <Text style={styles.InformacionMerma}>
                      Cajas devueltas con producto:{" "}
                      {datos.cajasDevueltasConProducto}
                    </Text>
                  ) : null}
                  {datos.piezasDevueltas != "0" && datos.UnidadVenta == "EA" ? (
                    <Text style={styles.InformacionMerma}>
                      Piezas devueltas: {datos.piezasDevueltas}
                    </Text>
                  ) : null}
                  {datos.cajasDevueltasConProductoPzas != "0" &&
                  datos.UnidadVenta == "EA" ? (
                    <Text style={styles.InformacionMerma}>
                      Cajas devueltas con producto:{" "}
                      {datos.cajasDevueltasConProductoPzas}
                    </Text>
                  ) : null}
                  {datos.KilogramosDevueltos != "0" ? (
                    <Text style={styles.InformacionMerma}>
                      Kg Devueltos: {datos.KilogramosDevueltos} kg
                    </Text>
                  ) : null}
                  {datos.MermaDetalle != "0.00" ? (
                    <Text style={styles.InformacionMerma}>
                      Merma: {datos.MermaDetalle} kg
                    </Text>
                  ) : null}
                  {datos.EstatusGlobalPedido == "0" &&
                  datos.EstatusDetalle == "0" ? (
                    <View
                      style={{
                        flexDirection: "row",
                        top: "3%",
                        justifyContent: "space-between",
                        width: "70%",
                      }}
                    >
                      <Text style={styles.titulo2}>Entrega Parcial</Text>
                      <TouchableOpacity
                        style={{ width: 40, top: "-5%" }}
                        onPress={() =>
                          this.handleModalShowKilogramos(
                            datos.Material,
                            datos.UnidadVenta,
                            datos.Peso,
                            datos.CantidadPiezasOCajas,
                            datos.Cantidad
                          )
                        }
                      >
                        {addMerma}
                      </TouchableOpacity>
                    </View>
                  ) : null}
                </View>
              </View>
            ); //fin return
          }} // finrenderRow
        />
      </View>
    ); // return principal
  }
}

const styles = StyleSheet.create({
  inputMerma: {
    marginBottom: 10,
    height: 33,
    borderWidth: 1,
    borderRadius: 5,
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(1.8) : responsiveFontSize(2),
    backgroundColor: "#ffffff",
    width: "50%",
    padding: 0,
    paddingLeft: 7,
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
  },
  containerPrincipal: {
    padding: 5,
    marginLeft: 5,
    width: "90%",
  },
  titulo1: {
    backgroundColor: "transparent",
    color: "#434346",
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(1.8) : responsiveFontSize(2),
  },
  producto: {
    backgroundColor: "transparent",
    color: "red",
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(1.8) : responsiveFontSize(2.2),
  },
  titulo2: {
    top: "-2.5%",
    backgroundColor: "transparent",
    color: "#434346",
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(1.8) : responsiveFontSize(2),
  },
  column: {
    flexDirection: "column",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 10,
    backgroundColor: "transparent",
    marginBottom: 5,
    marginHorizontal: 5,
    paddingHorizontal: 5,
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "stretch",
    backgroundColor: "#ffffff",
    marginBottom: 15,
    marginHorizontal: 10,
    paddingHorizontal: 5,
    borderRadius: 7,
    marginTop: 8,
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
  },
  list: {
    marginTop: 5,
  },
  InformacionMerma: {
    backgroundColor: "transparent",
    color: "#FF3100",
    marginTop: 0,
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(1.3) : responsiveFontSize(2),
  },
  Informacion: {
    backgroundColor: "transparent",
    color: "#434346",
    marginTop: 0,
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(1.3) : responsiveFontSize(2),
  },
});
