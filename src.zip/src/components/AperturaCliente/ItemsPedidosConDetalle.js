import React, { Component } from "react";
import {
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  Alert,
  RefreshControl,
  Platform,
} from "react-native";
import ListView from "deprecated-react-native-listview";
import { Actions } from "react-native-router-flux";
import Icon from "react-native-vector-icons/Ionicons";
import { getDatosPedidoXCliente } from "../../LlamadasRest/MyHTTP";
import { responsiveFontSize } from "react-native-responsive-dimensions";
import Input from "../AperturaCliente/InputDevolucionPedido";
import Input2 from "../AperturaCliente/InputDevolucionPedidoParcial";
import AsyncStorage from "@react-native-community/async-storage";

import { isNumero } from "../../ValidacionRegex/Regex";

const ID_STG = "numeroSocio";
const TELEFONO_STG = "telefono";
const URi_STG = "url";
const RUTA_STG = "ruta";
import ItemsApi from "../AperturaCliente/ItemsPedidosConDetalleParaEntregar";
import Geolocation from "@react-native-community/geolocation";
export default class ItemsPedidosConDetalle extends Component {
  constructor(props) {
    super(props);
    this.getDatos();
    const ds = new ListView.DataSource({
      rowHasChanged: (r1, r2) => r1 !== r2,
    });

    this.state = {
      dataSourcePedidos: ds,
      rfc: "",
      refreshing: false,
      mensaje: "",
      data: [],
      title: "",
      isVisible: false,
      idPedido: "",
      idFactura: "",
      telefono: "",
      telefonoCliente: "",
      url: "",
      idRuta: "",
      idCliente: "",
      title2: "",
      isVisible2: false,
      idProducto: "",
      unidadVenta: "",
      idPedidoDevolucion: "",
      cajasDevolucion: "",
      tapasDevolucion: "",
    };
    this.handleModalShow = this.handleModalShow.bind(this);
    this.handleModalHide = this.handleModalHide.bind(this);
    this.handleAddItems = this.handleAddItems.bind(this);
    this.onChangeTitle = this.onChangeTitle.bind(this);
    this._onRefresh = this._onRefresh.bind(this);
    this.onChangeCajasDev = this.onChangeCajasDev.bind(this);
    this.onChangeTapasDev = this.onChangeTapasDev.bind(this);

    /////////limio los input de devolucion pedido/////////////
    this.ClearInputCajas = this.ClearInputCajas.bind(this);
    this.ClearInputTapas = this.ClearInputTapas.bind(this);
    /////metodos para devoler el producto parcial//////////

    this.handleModalShow2 = this.handleModalShow2.bind(this);
    this.handleModalHide2 = this.handleModalHide2.bind(this);
    this.devolverPedido = this.devolverPedido.bind(this);
    this.onChangeTitle2 = this.onChangeTitle2.bind(this);
  }
  ////////////////////////////////////////////////////////////////////////
  //////// Metodos para devolver producto parcial ////////////////////////
  ////////////////////////////////////////////////////////////////////////
  // metodo para la devolucion del pedido por producto
  devolverPedido() {
    this.handleModalHide2();
    const idpro = String(this.state.idProducto);
    const unidadVenta = String(this.state.unidadVenta);
    const motivoDevolucion = this.state.title2;

    const url = this.state.url;

    if (motivoDevolucion == "") {
      Alert.alert(
        "Falta Agregar el motivo de devolución parcial",
        "Es necesario completar este campo para cancelar el pedido ",
        [{ text: "OK", onPress: () => {} }],
        { cancelable: false }
      );
    } else {
      return fetch(url + "GetPedidosXCliente/", {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          idPedido: this.state.idPedidoDevolucion,
          idProducto: idpro,
          motivoDevolucion: motivoDevolucion,
          unidadVenta: unidadVenta,
        }),
      })
        .then(function (response) {
          if (response.ok) {
            Alert.alert(
              "Se ha guardado la información con éxito",
              "Se han enviado los datos correctamente ",
              [{ text: "OK", onPress: () => {} }],
              { cancelable: false }
            );
          } else {
            Alert.alert(
              "Error!",
              "Asegurate de tener conexión a internet",
              [{ text: "OK", onPress: () => {} }],
              { cancelable: false }
            );
            const error = new Error(response.statusText);
            error.response = response;
            throw error;
          }
        })
        .then(() => this._onRefresh())
        .catch((error) => {});
    }
  }

  handleModalShow2(idProducto, unidadVenta, idPedidoDevolucion) {
    this.setState({
      isVisible2: true,
      idProducto: idProducto,
      unidadVenta: unidadVenta,
      idPedidoDevolucion: idPedidoDevolucion,
    });
  }
  handleModalHide2() {
    this.setState({
      isVisible2: false,
      title2: "",
    });
  }

  onChangeTitle2(value) {
    this.setState({ title2: value });
  }

  ////////////////////////////////////////////////////////////////////////

  async getDatos() {
    const rfc = await AsyncStorage.getItem(ID_STG);
    const telefono = await AsyncStorage.getItem(TELEFONO_STG);
    const url = await AsyncStorage.getItem(URi_STG);
    const idRuta = await AsyncStorage.getItem(RUTA_STG);
    this.setState({
      rfc: rfc,
      telefono: telefono,
      url: url,
      idRuta: idRuta,
    });
  }

  _onRefresh() {
    this.setState({
      refreshing: true,
    });
    getDatosPedidoXCliente(
      this.state.rfc,
      this.state.idCliente,
      this.state.idRuta
    ).then((data) => {
      this.setState({
        dataSourcePedidos: this.state.dataSourcePedidos.cloneWithRows(
          data[0].pedidosConDetalle
        ),
        refreshing: false,
      });
    });
  }

  componentWillMount() {
    const telefonoCliente = this.props.telefonoCliente;
    const idCliente = this.props.idCliente;

    this.setState({
      telefonoCliente: telefonoCliente,
      idCliente: idCliente,
    });
    this.upDateDataSource(this.props.datos);
  }

  UNSAFE_componentWillReceiveProps(newProps) {
    if (newProps.datos !== this.props.datos) {
      this.upDateDataSource(newProps.datos);
    }
  }
  upDateDataSource = (data) => {
    this.setState({
      dataSourcePedidos: this.state.dataSourcePedidos.cloneWithRows(data),
    });
  };

  llamaVistaEntregaProducto(
    idPedido,
    idFactura,
    pesoTotal,
    mermaTotal,
    pesoTotalSinFiltro
  ) {
    const telefonoCliente = this.state.telefonoCliente;
    const url = this.state.url;
    const idCliente = this.state.idCliente;
    Actions.entregaPedido({
      idPedido,
      idFactura,
      pesoTotal,
      mermaTotal,
      telefonoCliente,
      url,
      idCliente,
      pesoTotalSinFiltro,
    });
  }

  //////////////////////////////////////////////////////////
  ////////------Metodo para neviar el GPS--------///////////
  //////////////////////////////////////////////////////////
  envioGPS(idPedido, idFactura) {
  
    const rfc = this.state.rfc;

    Geolocation.getCurrentPosition(
      (info) => {
        const latitud = info.coords.latitude;
        const longitud = info.coords.longitude;
        const url = this.state.url;
        fetch(url + "GPS/", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            idPedido: idPedido,
            idFactura: idFactura,
            latitud: latitud,
            longitud: longitud,
            idOperador: rfc,
            bandera: "2",
          }),
        })
          .then(function (response) {
            if (response.ok) {
            } else {
              const error = new Error(response.statusText);
              error.response = response;
              throw error;
            }
          })
          .catch((error) => {});
      },
      (error) => this.setState({ error: error.message })
    );
  }

  ////////////////////////////////////////////////////////////////
  //////-----metodo para la devolucion total del pedido---////////
  handleAddItems() {
    this.handleModalHide();
    const idPedido = this.state.idPedido;
    const idFactura = this.state.idFactura;
    const motivo = this.state.title;
    const cajas = this.state.cajasDevolucion;
    const tapas = this.state.tapasDevolucion;
    const url = this.state.url;

    //// valido si viene vacia le coloco el valor en cero
    if (cajas == "") {
      cajas = "0";
    }
    if (tapas == "") {
      tapas = "0";
    }
    if (motivo == "") {
      Alert.alert(
        "Falta Agregar el motivo de devolución",
        "Es necesario completar este campo para cancelar el pedido ",
        [{ text: "OK", onPress: () => {} }],
        { cancelable: false }
      );
    } else {
      const url1 =
        url +
        "BitacoraPedido?idPedido=" +
        idPedido +
        "&IdFactura=" +
        idFactura +
        "&motivo=" +
        motivo +
        "&cajas=" +
        String(parseInt(cajas)) +
        "&tapas=" +
        String(parseInt(tapas));

      return fetch(url1, {
        method: "delete",
      })
        .then(function (response) {
          if (response.ok) {
            Actions.aperturaClienteHome();
            Alert.alert(
              "Se ha guardado la información con éxito",
              "Se han enviado los datos correctamente ",
              [{ text: "OK", onPress: () => {} }],
              { cancelable: false }
            );
          } else {
            Alert.alert(
              "Error!",
              "Asegurate de tener conexión a internet",
              [{ text: "OK", onPress: () => {} }],
              { cancelable: false }
            );
            const error = new Error(response.statusText);
            error.response = response;
            throw error;
          }
        })
        .then(() => this.envioGPS(idPedido, idFactura))
        .catch((error) => {});
    }
  }

  onChangeTitle(value) {
    this.setState({ title: value });
  }
  //limpio input cajas
  ClearInputCajas() {
    this.setState({ cajasDevolucion: "" });
  }
  onChangeCajasDev(cajasDevolucion) {
    if (isNumero(cajasDevolucion)) {
      this.setState({ cajasDevolucion });
    } else {
      Alert.alert(
        "Caracter Invalido!",
        "",
        [{ text: "OK", onPress: () => {} }],
        { cancelable: false }
      );
    }
  }
  //limpio input tapas
  ClearInputTapas() {
    this.setState({ tapasDevolucion: "" });
  }
  onChangeTapasDev(tapasDevolucion) {
    if (isNumero(tapasDevolucion)) {
      this.setState({ tapasDevolucion });
    } else {
      Alert.alert(
        "Caracter Invalido!",
        "",
        [{ text: "OK", onPress: () => {} }],
        { cancelable: false }
      );
    }
  }

  handleModalShow(idPedido, idFactura) {
    this.setState({
      isVisible: true,
      idPedido: idPedido,
      idFactura: idFactura,
    });
  }

  handleModalHide() {
    this.setState({
      isVisible: false,
      title: "",
      cajasDevolucion: "",
      tapasDevolucion: "",
    });
  }

  render() {
    const entregaProducto = (
      <Icon
        name="ios-checkmark-circle-outline"
        size={35}
        color="#29E61F"
        marginRight="5%"
      />
    );
    const consultarProducto = (
      <Icon name="ios-today" size={35} color="#29E61F" marginRight="5%" />
    );

    const input1 = (
      <Input
        onChangeTitle={this.onChangeTitle}
        onChangeTapasDev={this.onChangeTapasDev}
        onChangeCajasDev={this.onChangeCajasDev}
        onHandleItems={this.handleAddItems}
        title={this.state.title}
        cajasDevolucion={this.state.cajasDevolucion}
        tapasDevolucion={this.state.tapasDevolucion}
        isVisible={this.state.isVisible}
        onCloseModal={this.handleModalHide}
        ClearInputCajas={this.ClearInputCajas}
        ClearInputTapas={this.ClearInputTapas}
      />
    );

    const input2 = (
      <Input2
        onChangeTitle2={this.onChangeTitle2}
        devolverPed={this.devolverPedido}
        title2={this.state.title2}
        isVisible2={this.state.isVisible2}
        onCloseModal2={this.handleModalHide2}
      />
    );

    return (
      <View style={{ flex: 1 }}>
        {input1}
        {input2}
        <ListView
          refreshControl={
            <RefreshControl
              refreshing={this.state.refreshing}
              _onRefresh={this._onRefresh.bind(this)}
            />
          }
          style={styles.list}
          enableEmptySections
          dataSource={this.state.dataSourcePedidos}
          renderRow={({ ...datos }) => {
            return (
              <View style={styles.row}>
                <View style={styles.containerPrincipal}>
                  <View style={{ flexDirection: "row" }}>
                    <View>
                      <Text style={styles.titulo2}>
                        Factura: {datos.Factura}
                      </Text>
                      <Text style={styles.titulo2}>
                        Pedido: {datos.IdPedido}
                      </Text>

                      {datos.EstatusPedido == "1" ? (
                        <Text style={styles.entregado}>Pedido Entregado</Text>
                      ) : null}
                      {datos.EstatusPedido == "2" ? (
                        <Text style={styles.devuelto}>Pedido Devuelto</Text>
                      ) : null}
                    </View>
                    <View style={{ flexDirection: "row", marginLeft: "11%" }}>
                      {datos.EstatusPedido == "2" ? null : null}
                      {datos.EstatusPedido == "1" ? (
                        <TouchableOpacity
                          onPress={() =>
                            this.llamaVistaEntregaProducto(
                              datos.IdPedido,
                              datos.Factura,
                              datos.Peso,
                              datos.MermaDetalle,
                              datos.TotalKgEntregados
                            )
                          }
                        >
                          <View style={styles.containerIconos}>
                            {consultarProducto}
                          </View>
                          <Text style={styles.Informacion}>
                            Consultar{"\n"}Entrega
                          </Text>
                        </TouchableOpacity>
                      ) : null}
                      {datos.EstatusPedido == "0" &&
                      datos.BanderaDetalleProducto == "0" ? (
                        <TouchableOpacity
                          onPress={() =>
                            this.llamaVistaEntregaProducto(
                              datos.IdPedido,
                              datos.Factura,
                              datos.Peso,
                              datos.MermaDetalle,
                              datos.TotalKgEntregados
                            )
                          }
                        >
                          <View style={styles.containerIconos}>
                            {entregaProducto}
                          </View>
                          <Text style={styles.Informacion}>
                            Entrega{"\n"}Pedido
                          </Text>
                        </TouchableOpacity>
                      ) : null}

                      <View style={{ marginLeft: "10%" }}>
                        {datos.EstatusPedido == "0" ? (
                          <TouchableOpacity
                            onPress={() =>
                              this.handleModalShow(
                                datos.IdPedido,
                                datos.Factura
                              )
                            }
                          >
                            <View style={styles.containerIconos}>
                              <Icon
                                name="ios-close-circle-outline"
                                size={35}
                                color="red"
                              />
                            </View>
                            <Text style={styles.Informacion}>
                              Devolucíon{"\n"}Pedido
                            </Text>
                          </TouchableOpacity>
                        ) : null}
                      </View>
                    </View>
                  </View>
                  <ItemsApi
                    datos={datos.listaDetalle}
                    idPedido={datos.IdPedido}
                    idFactura={datos.Factura}
                    estatusPedido={datos.EstatusPedido}
                    _onRefresh={this._onRefresh}
                    handleModalShow2={this.handleModalShow2}
                  />
                </View>
              </View>
            );
          }}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  containerIconos: {
    backgroundColor: "#fcfcff",
    borderRadius: 50,
    padding: 5,
    height: 45,
    alignItems: "center",
    width: 45,
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
  },

  containerDatos: {
    flexDirection: "row",
    justifyContent: "space-between",
    padding: 10,
  },

  containerPrincipal: {
    padding: 5,
    marginLeft: 10,
    width: "95%",
  },

  titulo2: {
    backgroundColor: "transparent",
    color: "black",
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(2.8) : responsiveFontSize(2.3),
  },
  devuelto: {
    backgroundColor: "transparent",
    color: "red",
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(2.8) : responsiveFontSize(2.3),
  },
  entregado: {
    backgroundColor: "transparent",
    color: "blue",
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(2.8) : responsiveFontSize(2.3),
  },
  logo: {
    width: 50,
    height: 50,
    borderRadius: 50,
    marginTop: 10,
  },

  ColorTexto: {
    color: "#434346",
    fontSize: 24,
  },
  column: {
    flexDirection: "column",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 10,
    backgroundColor: "transparent",
    marginBottom: 5,
    marginHorizontal: 5,
    paddingHorizontal: 5,
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "stretch",
    paddingVertical: 10,
    backgroundColor: "#ffffff",
    marginBottom: 15,
    marginHorizontal: 15,
    paddingHorizontal: 5,
    borderRadius: 7,
    marginTop: 7,
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
  },
  list: {
    marginTop: 5,
  },
  Informacion: {
    backgroundColor: "transparent",
    color: "#434346",
    marginTop: 0,
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(1.3) : responsiveFontSize(1.5),
  },
});
