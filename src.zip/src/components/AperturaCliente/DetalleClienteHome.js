import React, { Component } from "react";
import { StyleSheet, View } from "react-native";
import { Actions } from "react-native-router-flux";
import HeaderContenido from "../Home/HeaderDetallePedido";
import ItemsApi from "../AperturaCliente/ItemsDetallePedidos";

export default class DetalleClienteHome extends Component {
  constructor(props) {
    super(props);
    const ds1 = new ListView.DataSource({
      rowHasChanged: (r1, r2) => r1 !== r2,
    });
    this.state = {
      dataSourceDetalle: ds1,
      pedidos: "",
      datos: [],
      datosDetallePedido: [],
    };
  }
  componentWillMount() {
    const detallePedido = this.props.pedidos;
    this.setState({
      datosDetallePedido: detallePedido,
    });
  }

  componentWillReceiveProps(newProps) {
    if (newProps.datosDetallePedido !== this.props.datosDetallePedido) {
      this.upDateDataSource(newProps.datosDetallePedido);
    }
  }

  upDateDataSource = (data) => {
    this.setState({
      datosDetallePedido: data,
    });
  };

  home() {
    Actions.aperturaClienteHome();
  }

  llammaVistaAperturaClienteEntrega() {
    Actions.aperturaClienteEntrega();
  }

  render() {
    const datosDetallePedido = this.state.datosDetallePedido;

    return (
      <View style={{ flex: 1 }}>
        <HeaderContenido home={this.home.bind(this)} />

        <View style={styles.containerPrincipal}>
          <ItemsApi datos={datosDetallePedido} />
        </View>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  containerPrincipal: {
    flex: 2,
    backgroundColor: "#09467F",
  },
});
