import React, { Component } from "react";
import {
  Text,
  View,
  StyleSheet,
  TextInput,
  TouchableHighlight,
  ScrollView,
  Platform,
} from "react-native";
import { responsiveFontSize } from "react-native-responsive-dimensions";
import Modal from "react-native-modal";
import Icon from "react-native-vector-icons/FontAwesome";
import Panel from "react-native-panel";
import AsyncStorage from "@react-native-community/async-storage";

const URi_STG = "url";
export default class InputKilogramosEntregados extends Component {
  ////////-------------  Entrega Parcial --------------------/////////
  constructor(props) {
    super(props);
    this.state = {
      catalogo: [],
      url: "",
    };
  }

  async getUrl() {
    let url = await AsyncStorage.getItem(URi_STG);
  }

  componentWillMount() {
    this.getUrl();
  }

  render() {
    const guardarKilos = (
      <Icon name="save" size={25} color="white" marginRight="5%" />
    );
    const closeModal = <Icon name="chevron-down" size={20} color="white" />;

    const divKilogramosEntregados = (
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          width: "50%",
          marginTop: 5,
        }}
      >
        {this.props.visualPiezas ? (
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              width: "90%",
              marginRight: "5%",
            }}
          >
            <Text style={styles.titulo2}>Piezas{"\n"}Merma</Text>
            <TextInput
              keyboardType="numeric"
              returnKeyType="next"
              value={this.props.pzasMerma}
              underlineColorAndroid="transparent"
              placeholderTextColor="rgba(10,10,10,0.5)"
              style={styles.inputPzasMerma}
              onChangeText={(pzasMerma) =>
                this.props.onChangePzasMerma(pzasMerma)
              }
            />
          </View>
        ) : null}
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            width: "100%",
          }}
        >
          <Text style={styles.titulo2}>Kilogramos{"\n"}Entregados</Text>
          <TextInput
            keyboardType="numeric"
            returnKeyType="next"
            value={this.props.mermaDetalle}
            underlineColorAndroid="transparent"
            placeholderTextColor="rgba(10,10,10,0.5)"
            style={styles.inputCajasTapas}
            onChangeText={(mermaDetalle) =>
              this.props.onChangeMerma(mermaDetalle)
            }
          />
        </View>
      </View>
    );

    return (
      <View style={styles.container}>
        <Modal
          style={styles.modalTop}
          isVisible={this.props.isVisibleModal}
          animationIn={"slideInUp"}
          animationOut={"slideOutDown"}
          backdropColor={"black"}
          animationInTiming={1000}
          animationOutTiming={1000}
          backdropOpacity={0.2}
        >
          <View style={styles.modalContent}>
            <TouchableHighlight
              style={{ width: "35%" }}
              onPress={this.props.handleModalHideKilogramos}
            >
              {closeModal}
            </TouchableHighlight>
            <ScrollView style={styles.container}>
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "center",
                  width: "97%",
                  padding: 10,
                }}
              >
                <Text style={styles.Encabezado}>Entrega Parcial</Text>
              </View>
              {/*--------panel para devolcuion-----------*/}
              <Panel
                style={styles.firstHeaderContainer}
                header="Devolución Parcial"
                onPress={() => null}
              >
                {this.props.visualCajas ? (
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      width: "97%",
                      marginTop: 5,
                    }}
                  >
                    <View
                      style={{
                        flexDirection: "row",
                        justifyContent: "space-between",
                        width: "50%",
                        marginRight: "3%",
                      }}
                    >
                      <Text style={styles.titulo2}>Cajas{"\n"}Devueltas</Text>
                      <TextInput
                        keyboardType="numeric"
                        returnKeyType="next"
                        value={this.props.cajasDevueltas}
                        underlineColorAndroid="transparent"
                        placeholderTextColor="rgba(10,10,10,0.5)"
                        style={styles.inputCajasTapas}
                        onChangeText={(cajasDevueltas) =>
                          this.props.onChangeCajasDevueltas(cajasDevueltas)
                        }
                      />
                    </View>
                    <View
                      style={{
                        flexDirection: "row",
                        justifyContent: "space-between",
                        width: "50%",
                        marginRight: "3%",
                      }}
                    >
                      <Text style={styles.titulo2}>
                        Kilogramos{"\n"}Devueltos
                      </Text>
                      <TextInput
                        keyboardType="numeric"
                        returnKeyType="next"
                        value={this.props.kilogramosDevueltos}
                        underlineColorAndroid="transparent"
                        placeholderTextColor="rgba(10,10,10,0.5)"
                        style={styles.inputCajasTapas}
                        onChangeText={(kilogramosDevueltos) =>
                          this.props.onChangeKilogramosDevueltos(
                            kilogramosDevueltos
                          )
                        }
                      />
                    </View>
                  </View>
                ) : null}
                {this.props.visualPiezas ? (
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      width: "97%",
                      marginTop: 5,
                    }}
                  >
                    <View
                      style={{
                        flexDirection: "row",
                        justifyContent: "space-between",
                        width: "50%",
                        marginRight: "3%",
                      }}
                    >
                      <Text style={styles.titulo2}>Piezas{"\n"}Devueltas</Text>
                      <TextInput
                        keyboardType="numeric"
                        returnKeyType="next"
                        value={this.props.pzasDevueltas}
                        underlineColorAndroid="transparent"
                        placeholderTextColor="rgba(10,10,10,0.5)"
                        style={styles.inputCajasTapas}
                        onChangeText={(pzasDevueltas) =>
                          this.props.onChangePzasDevueltas(pzasDevueltas)
                        }
                      />
                    </View>
                    <View
                      style={{
                        flexDirection: "row",
                        justifyContent: "space-between",
                        width: "50%",
                        marginRight: "3%",
                      }}
                    >
                      <Text style={styles.titulo2}>
                        Kilogramos{"\n"}Devueltos
                      </Text>
                      <TextInput
                        textContentType="telephoneNumber"
                        keyboardType="numeric"
                        returnKeyType="next"
                        value={this.props.kilogramosDevueltos}
                        underlineColorAndroid="transparent"
                        placeholderTextColor="rgba(10,10,10,0.5)"
                        style={styles.inputCajasTapas}
                        onChangeText={(kilogramosDevueltos) =>
                          this.props.onChangeKilogramosDevueltos(
                            kilogramosDevueltos
                          )
                        }
                      />
                    </View>
                  </View>
                ) : null}
                {this.props.visualPiezas ? (
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      width: "97%",
                      marginTop: 5,
                    }}
                  >
                    <View
                      style={{
                        flexDirection: "row",
                        justifyContent: "space-between",
                        width: "50%",
                        marginRight: "3%",
                      }}
                    >
                      <Text style={styles.titulo2}>Cajas{"\n"}Devueltas</Text>
                      <TextInput
                        keyboardType="numeric"
                        returnKeyType="next"
                        value={this.props.cajasDevueltasXDetalle}
                        underlineColorAndroid="transparent"
                        placeholderTextColor="rgba(10,10,10,0.5)"
                        style={styles.inputCajasTapas}
                        onChangeText={(cajasDevueltasXDetalle) =>
                          this.props.onChangeCajasDevueltasXDetalle(
                            cajasDevueltasXDetalle
                          )
                        }
                      />
                    </View>
                  </View>
                ) : null}
              </Panel>
              {/*--------fin panel para devolcuion-------*/}
              <View
                styles={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                  width: "100%",
                }}
              >
                {divKilogramosEntregados}
              </View>
            </ScrollView>

            <TouchableHighlight
              style={styles.button}
              onPress={this.props.addMerma}
            >
              <Text style={styles.buttonText}>
                {guardarKilos} Guardar Entrega Parcial
              </Text>
            </TouchableHighlight>
          </View>
        </Modal>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  firstHeaderContainer: {
    backgroundColor: "#3483D8",
    borderRadius: 6,
    paddingHorizontal: "1%",
  },
  modalTop: {
    justifyContent: "flex-start",
    marginTop: "40%",
    backgroundColor: "transparent",
  },

  modalContent: {
    backgroundColor: "#3483D8",
    padding: 20,
    borderRadius: 5,
  },

  input: {
    marginBottom: 5,
    height: 40,
    borderColor: "#ccc",
    borderWidth: 1,
    borderRadius: 3,
    color: "white",
  },
  button: {
    //	backgroundColor: '#09467F',
    backgroundColor: "#0BA803",
    paddingTop: 15,
    paddingBottom: 15,
    marginTop: 5,
    borderRadius: 6,
  },
  buttonText: {
    textAlign: "center",
    color: "white",
  },
  container: {
    //textAlign:  'center',
    color: "white",
  },

  Encabezado: {
    backgroundColor: "transparent",
    color: "white",
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(2) : responsiveFontSize(2),
  },
  titulo2: {
    backgroundColor: "transparent",
    color: "white",
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(2) : responsiveFontSize(1.7),
  },
  inputCajasTapas: {
    marginBottom: 15,
    height: 35,
    borderWidth: 1,
    borderRadius: 5,
    backgroundColor: "#ffffff",
    width: "50%",
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
    padding: 0,
    paddingLeft: 7,
  },
  inputPzasMerma: {
    marginBottom: 15,
    height: 35,
    borderWidth: 1,
    borderRadius: 5,
    backgroundColor: "#ffffff",
    width: "50%",
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
    padding: 0,
  },
});
