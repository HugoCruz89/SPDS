import React, { Component } from "react";
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  Alert,
  TouchableOpacity,
  Platform,
  ActivityIndicator,
} from "react-native";
import AsyncStorage from "@react-native-community/async-storage";
import Icon from "react-native-vector-icons/FontAwesome";
import Icon2 from "react-native-vector-icons/MaterialIcons";
import { Actions } from "react-native-router-flux";
import HeaderContenido from "../Home/HeaderDetallePedido";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import {
  responsiveHeight,
  responsiveWidth,
  responsiveFontSize,
} from "react-native-responsive-dimensions";
import DocumentPicker from "react-native-document-picker";

import { showToast, showLoading, hideLoading } from "react-native-notifyer";
import {
  getPedido,
  getDatosPedidoXCliente,
  getRegexXCliente,
  DeleteImagenes,
} from "../../LlamadasRest/MyHTTP";

import { RNCamera } from "react-native-camera";
import Geolocation from "@react-native-community/geolocation";
import { isNumero, isTemp, regexFolio } from "../../ValidacionRegex/Regex";
import { GetDateTime } from "../Utilidades/GetDateTime";
import { BorraImagenes } from "../Utilidades/Utilerias";

const USR_STG = "numeroSocio";
const URi_STG = "url";
const RUTA_STG = "ruta";

export default class EntregaPedido extends Component {
  constructor(props) {
    super(props);
    this.getDatos();
    this.state = {
      motivoDevolucion: "",
      idPedido: "",
      idFactura: "",
      pesoTotal: "",
      KilogramosTotalesEntregados: "",
      merma: "",
      cajasDevueltas: "",
      tapasDevueltas: "",
      temperatura: "",
      folio: "",
      estatusPedido: "",
      imagenFolio: "",
      mermaTotal: "",
      showTheThing: false,
      arrayImagen: [],
      IdImagen: "",
      aux: "",
      rfc: "",
      telefono: "",
      telefonoCliente: "",
      arrayImagenComplementaria: [],
      IdImagenComplementaria: "",
      aux2: "",
      showTheThingEvidComple: false,
      url: "",
      idCliente: "",
      pesoTotalSinFiltro: "",
      numeroImagenesFolio: "",
      numeroEvidencia: "",
      isVisibleCamaraFolio: false,
      isVisibleEvidenciaComplementaria: false,
      idRuta: "",
      Regex: "",
      loading: false,
      folder1: true,
      loading2: false,
      folder2: true,
      arrayAdjuntos1: [],
      arrayAdjuntos2: [],
    };
  }

  async getDatos() {
    const idCliente = this.props.idCliente;
    getRegexXCliente(idCliente)
      .then((data) => {
        this.setState({
          Regex: data.regex,
        });
      })
      .catch((mensaje) => {});

    let rfc = await AsyncStorage.getItem(USR_STG);
    let url = await AsyncStorage.getItem(URi_STG);
    let idRuta = await AsyncStorage.getItem(RUTA_STG);

    this.setState({
      rfc: rfc,
      url: url,
      idRuta: idRuta,
    });
    this.envioGPS(rfc, "0", "inicio");
  }

  async envioGPS(rfc, bandera, evento) {
    const idP = this.props.idPedido;
    const idF = this.props.idFactura;
    this.setState({
      idPedido: idP,
      idFactura: idF,
    });
    /// se manda el evento al apertura
    if (evento == "inicio") {
      const idPedido = this.state.idPedido;
      const idFactura = this.state.idFactura;
      Geolocation.getCurrentPosition(
        (info) => {
          const latitud = info.coords.latitude;
          const longitud = info.coords.longitude;
          const url = this.state.url;
          fetch(url + "GPS/", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              idPedido: idPedido,
              idFactura: idFactura,
              latitud: latitud,
              longitud: longitud,
              idOperador: rfc,
              bandera: bandera,
              fechaCelular: GetDateTime(),
            }),
          })
            .then(function (response) {
              if (response.ok) {
              } else {
                const error = new Error(response.statusText);
                error.response = response;
                throw error;
              }
            })
            .catch((error) => {});
        },
        (error) => this.envioGPSSinDatos(rfc, "0")
      );
    } else {
      const idPedido = this.state.idPedido;
      const idFactura = this.state.idFactura;
      Geolocation.getCurrentPosition(
        (info) => {
          const latitud = info.coords.latitude;
          const longitud = info.coords.longitude;
          const url = this.state.url;
          fetch(url + "GPS/", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              idPedido: idPedido,
              idFactura: idFactura,
              latitud: latitud,
              longitud: longitud,
              idOperador: rfc,
              bandera: bandera,
              fechaCelular: GetDateTime(),
            }),
          })
            .then(function (response) {
              if (response.ok) {
              } else {
                const error = new Error(response.statusText);
                error.response = response;
                throw error;
              }
            })
            .catch((error) => {});
        },
        (error) => this.envioGPSSinDatos(rfc, "1")
      );
    }
  }
  //////////////////////////////////////////////
  //inciop sin coordenadas
  envioGPSSinDatos(rfc, bandera) {
    const idPedido = this.state.idPedido;
    const idFactura = this.state.idFactura;
    const latitud = "n/d";
    const longitud = "n/d";
    const url = this.state.url;
    fetch(url + "GPS/", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        idPedido: idPedido,
        idFactura: idFactura,
        latitud: latitud,
        longitud: longitud,
        idOperador: rfc,
        bandera: bandera,
        fechaCelular: GetDateTime(),
      }),
    })
      .then(function (response) {
        if (response.ok) {
        } else {
          const error = new Error(response.statusText);
          error.response = response;
          throw error;
        }
      })
      .catch((error) => {});
  }
  /////////////////////////////////////////
  componentWillMount() {
    showLoading();
    const IdPedido = this.props.idPedido;
    const IdFactura = this.props.idFactura;
    const pesoTotal = this.props.pesoTotal;
    const mermaTotal = this.props.mermaTotal;
    const telefonoCliente = this.props.telefonoCliente;
    const pesoTotalSinFiltro = this.props.pesoTotalSinFiltro;
    const pesoT = parseFloat(pesoTotal).toFixed(2);
    const mermaT = parseFloat(mermaTotal).toFixed(2);
    const diferencia = pesoT - mermaT;
    const idCliente = this.props.idCliente;

    this.setState({
      telefonoCliente: telefonoCliente,
      idPedido: String(IdPedido),
      idFactura: String(IdFactura),
      pesoTotal: String(pesoTotal),
      merma: String(mermaTotal),
      KilogramosTotalesEntregados: String(parseFloat(diferencia).toFixed(2)),
      idCliente: idCliente,
      pesoTotalSinFiltro: pesoTotalSinFiltro,
    });

    getPedido(IdPedido, IdFactura)
      .then((data) => {
        hideLoading();
        this.setState({
          temperatura: String(data.Temperatura),
          cajasDevueltas: String(data.CajasDevueltas),
          tapasDevueltas: String(data.TapasDevueltas),
          folio: String(data.Folio),
          estatusPedido: String(data.EstatusPedido),
          arrayImagen: data.numeroImagenesFolio,
          arrayImagenComplementaria: data.numeroEvidencias,
          arrayAdjuntos1: data.numeroImagenesFolioAdjuntos,
          arrayAdjuntos2: data.numeroEvidenciasAdjuntos,
        });
      })
      .catch((mensaje) => {});
  }

  obtengoDatosVista() {
    getDatosPedidoXCliente(
      this.state.rfc,
      this.state.idCliente,
      this.state.idRuta
    ).then((data) => {
      this.llamaVista(
        data[0].pedidosConDetalle,
        data[0].telefono,
        data[0].idCliente
      );
    });
  }

  home() {
    this.obtengoDatosVista();
  }

  llamaVista(PedidosConDetalle, telefono, idCliente) {
    Actions.aperturaClienteEntrega({ PedidosConDetalle, telefono, idCliente });
  }

  onChangeKilogramos(KilogramosTotalesEntregados) {
    const number = parseFloat(KilogramosTotalesEntregados).toFixed(2);
    const pesoEntregado = number;
    const pesoTotal = parseFloat(this.state.pesoTotal).toFixed(2);
    const diferencia = pesoTotal - pesoEntregado;
    this.setState({
      KilogramosTotalesEntregados,
      merma: String(parseFloat(diferencia).toFixed(2)),
    });
  }

  ClearInputTapas() {
    this.setState({ tapasDevueltas: "" });
  }
  ClearInputCajas() {
    this.setState({ cajasDevueltas: "" });
  }
  onChangeCajasDevueltas(cajasDevueltas) {
    if (isNumero(cajasDevueltas)) {
      this.setState({ cajasDevueltas });
    } else {
      showToast("Carcater Invalido");
    }
  }
  onChangeTapasDevueltas(tapasDevueltas) {
    if (isNumero(tapasDevueltas)) {
      this.setState({ tapasDevueltas });
    } else {
      showToast("Carcater Invalido");
    }
  }

  onChangeFolio(folio) {
    this.setState({ folio });
  }

  onChangeMotivoDevolucion(motivoDevolucion) {
    this.setState({ motivoDevolucion });
  }
  onChangeTemperatura(temperatura) {
    this.setState({ temperatura });
  }

  GrabarDatos() {
    const cajas = this.state.cajasDevueltas;
    const tapas = this.state.tapasDevueltas;
    const folio = this.state.folio;
    const reg = this.state.Regex;
    if (String(folio).length == 0) {
      if (
        this.state.arrayImagen.length > 0 ||
        this.state.arrayAdjuntos1.length > 0
      ) {
        Alert.alert("Es Necesario Capturar el Folio");
        return;
      }
    }
    if (String(folio).length != 0) {
      if (this.state.arrayImagen.length == 0) {
        if (this.state.arrayAdjuntos1.length == 0) {
          Alert.alert("Es Necesario Capturar adjunto o imagen");
          return;
        }
      }
    }
    if (String(folio).length > 0) {
      if (!regexFolio(folio, reg)) {
        Alert.alert(
          "¡Folio Incorrecto!",
          "Ingresa correctamente el folio de tu cliente",
          [{ text: "OK", onPress: () => {} }],
          { cancelable: false }
        );
        return;
      }
    }
    if (cajas == "") cajas = "0";
    if (tapas == "") tapas = "0";
    if (isTemp(this.state.temperatura)) {
      showLoading();
      const url = this.state.url;
      fetch(url + "BitacoraPedido/", {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          EstatusPedido: "0",
          IdPedido: this.state.idPedido,
          IdFactura: this.state.idFactura,
          Temperatura: this.state.temperatura,
          Merma: this.state.merma,
          Folio: this.state.folio,
          CajasDevueltas: String(parseInt(cajas)),
          TapasDevueltas: String(parseInt(tapas)),
          KilogramosTotalesEntregados: this.state.pesoTotal,
          imagenFolio: JSON.stringify(this.state.arrayImagen),
          imagenEvidenciaComplementaria: JSON.stringify(
            this.state.arrayImagenComplementaria
          ),
          fechaCelular: GetDateTime(),
        }),
      })
        .then(function (response) {
          if (response.ok) {
            hideLoading();
            Alert.alert(
              "Se ha guardado la información con éxito",
              "Se han enviado los datos correctamente ",
              [{ text: "OK", onPress: () => {} }],
              { cancelable: false }
            );
          } else {
            hideLoading();
            Alert.alert(
              "Algo salio mal!",
              "Error:" + response.status,
              [{ text: "OK", onPress: () => {} }],
              { cancelable: false }
            );
            const error = new Error(response.statusText);
            error.response = response;
            throw error;
          }
        })
        .catch((error) => {});
    } else {
      Alert.alert(
        "Error de Captura!",
        "Temperatura no valida ",
        [{ text: "OK", onPress: () => {} }],
        { cancelable: false }
      );
      return;
    }
  }

  FinalizarPedido() {
    const rfc = this.state.rfc;
    this.envioGPS(rfc, "1", "fin");

    const cajas = this.state.cajasDevueltas;
    const tapas = this.state.tapasDevueltas;
    const folio = this.state.folio;
    const reg = this.state.Regex;
    if (cajas == "") {
      cajas = "0";
    }
    if (tapas == "") {
      tapas = "0";
    }
    if (String(folio).length == 0) {
      if (
        this.state.arrayImagen.length > 0 ||
        this.state.arrayAdjuntos1.length > 0
      ) {
        Alert.alert("Es Necesario Capturar el Folio");
        return;
      }
    }
    if (String(folio).length != 0) {
      if (this.state.arrayImagen.length == 0) {
        if (this.state.arrayAdjuntos1.length == 0) {
          Alert.alert("Es Necesario Capturar adjunto o imagen");
          return;
        }
      }
    }
    if (String(folio).length > 0) {
      if (!regexFolio(folio, reg)) {
        Alert.alert(
          "¡Folio Incorrecto!",
          "Ingresa correctamente el folio de tu cliente",
          [{ text: "OK", onPress: () => {} }],
          { cancelable: false }
        );
        return;
      }
    }
    if (isTemp(this.state.temperatura)) {
      if (
        this.state.merma == "" ||
        this.state.KilogramosTotalesEntregados == "0" ||
        cajas == "" ||
        tapas == ""
      ) {
        Alert.alert(
          "¡Datos Incompletos!",
          "Debes ingresar Cajas y Tapas devueltas para finalizar el pedido  ",
          [{ text: "OK", onPress: () => {} }],
          { cancelable: false }
        );
        return;
      }
      showLoading();
      const url = this.state.url;
      fetch(url + "BitacoraPedido/", {
        method: "PUT",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          EstatusPedido: "1",
          IdPedido: this.state.idPedido,
          IdFactura: this.state.idFactura,
          Temperatura: this.state.temperatura,
          Merma: this.state.merma,
          Folio: this.state.folio,
          CajasDevueltas: String(parseInt(cajas)),
          TapasDevueltas: String(parseInt(tapas)),
          KilogramosTotalesEntregados: this.state.pesoTotal,
          imagenFolio: JSON.stringify(this.state.arrayImagen),
          imagenEvidenciaComplementaria: JSON.stringify(
            this.state.arrayImagenComplementaria
          ),
          fechaCelular: GetDateTime(),
        }),
      })
        .then((response) => {
          if (response.ok) {
            hideLoading();
            BorraImagenes(this.state.arrayAdjuntos1);
            BorraImagenes(this.state.arrayAdjuntos2);
            Actions.aperturaClienteHome();
            Alert.alert(
              "Se ha guardado la información con éxito",
              "Se finalizo el pedido correctamente ",
              [{ text: "OK", onPress: () => {} }],
              { cancelable: false }
            );
          } else {
            hideLoading();
            Alert.alert(
              "Error!",
              "Asegurate de tener conexión a internet",
              [{ text: "OK", onPress: () => {} }],
              { cancelable: false }
            );
            const error = new Error(response.statusText);
            error.response = response;
            throw error;
          }
        })
        .catch((error) => {});
    } else {
      Alert.alert(
        "Error de Captura!",
        "Temperatura no valida ",
        [{ text: "OK", onPress: () => {} }],
        { cancelable: false }
      );
      return;
    }
  }

  MetodoAuxiliarParaActualizarVista() {
    getPedido(this.state.idPedido, this.state.idFactura)
      .then((data) => {
        hideLoading();

        this.setState({
          temperatura: String(data.Temperatura),
          cajasDevueltas: String(data.CajasDevueltas),
          tapasDevueltas: String(data.TapasDevueltas),
          folio: data.Folio != "" ? String(data.Folio) : this.state.folio,
          estatusPedido: String(data.EstatusPedido),
          arrayAdjuntos1: data.numeroImagenesFolioAdjuntos,
          arrayAdjuntos2: data.numeroEvidenciasAdjuntos,
        });
      })
      .catch((mensaje) => {});
  }

  limpioImagenes(IsFolio, IsAdjunto) {
    if (IsFolio == "1" && IsAdjunto == "0") {
      this.setState({
        arrayImagen: [],
      });
    }
    if (IsFolio == "0" && IsAdjunto == "0") {
      this.setState({
        arrayImagenComplementaria: [],
      });
    }

    showLoading();
    DeleteImagenes(
      this.state.idPedido,
      this.state.idFactura,
      IsFolio,
      IsAdjunto
    )
      .then((data) => {
        if (data == "True") {
          this.MetodoAuxiliarParaActualizarVista();
          hideLoading();
        } else {
          hideLoading();
          alert("Algo ocurrio mal, intentalo nuevamente");
        }
      })
      .catch((mensaje) => {});
  }

  //abro la camara de folio
  openImagePicker() {
    this.setState({ isVisibleCamaraFolio: true });
  }
  // cierro camara de folio
  closeImagePicker() {
    this.setState({ isVisibleCamaraFolio: false });
  }
  ///nuevo metodo para capturar la imagen del folio
  takePicture = async function () {
    showLoading();
    if (this.camera) {
      const options = { quality: 0.7, base64: true, width: 788 };

      const data = await this.camera.takePictureAsync(options);
      let id = this.state.arrayImagen.length;
      this.state.arrayImagen.push({
        id: id,
        imagenData: String(data.base64),
        tipoArchivo: "jpg",
        IsAdjunto: "0",
      });
      this.setState({
        showTheThing: true,
        isVisibleCamaraFolio: false,
      });
      hideLoading();
    }
  };
  // abro la camara de evidencia
  openImagePickerEvidenciaComplementaria() {
    this.setState({ isVisibleEvidenciaComplementaria: true });
  }
  //cierro la camara de evidencia
  closeImagePickerEvidenciaComplementaria() {
    this.setState({ isVisibleEvidenciaComplementaria: false });
  }
  //tomo la imagen de la evidencia complementaria
  takePicture2 = async function () {
    showLoading();
    if (this.camera) {
      const options = { quality: 0.7, base64: true, width: 788 };

      const data = await this.camera.takePictureAsync(options);

      const id = this.state.arrayImagenComplementaria.length;
      this.state.arrayImagenComplementaria.push({
        id: id,
        imagenData: String(data.base64),
        tipoArchivo: "jpg",
        IsAdjunto: "0",
      });

      this.setState({
        showTheThingEvidComple: true,
        isVisibleEvidenciaComplementaria: false,
      });
      hideLoading();
    }
  };

  async ArchivoGaleria(bandera) {
    if (bandera != "1") {
      if (this.state.folio == "") {
        Alert.alert(
          "¡Datos Incompletos!",
          "Es obligatorio capturar folio e imagen para guardar datos de pedido",
          [{ text: "OK", onPress: () => {} }],
          { cancelable: false }
        );
        return;
      }
    }

    if (String(this.state.folio).length > 0 && bandera != "1") {
      if (!regexFolio(this.state.folio, this.state.Regex)) {
        Alert.alert(
          "¡Folio Incorrecto!",
          "Ingresa correctamente el folio de tu cliente",
          [{ text: "OK", onPress: () => {} }],
          { cancelable: false }
        );
        return;
      }
    }

    try {
      const res = await DocumentPicker.pick({
        type: [DocumentPicker.types.pdf],
      });
      const id =
        bandera == "0"
          ? this.state.arrayAdjuntos1.lenght
          : this.state.arrayAdjuntos2.lenght;

      if (res.size > 2000000) {
        Alert.alert(
          "¡Archivo Demaciado Grande!",
          "Archivo demasiado grande, reducir la calidad o dividirlo en varios archivos",
          [{ text: "OK", onPress: () => {} }],
          { cancelable: false }
        );
        return;
      }

      this.AddArrayFile(res, res.type, bandera, id);
    } catch (err) {
      if (DocumentPicker.isCancel(err)) {
      } else {
      }
    }
  }

  async AddArrayFile(file, tipoArchivo, bandera, id) {
    showLoading();
    if (bandera === "0") {
      this.setState({
        folder1: false,
        loading: true,
      });
    } else {
      this.setState({
        folder2: false,
        loading2: true,
      });
    }
   

    const uploadUrl = this.state.url + "Utilidades";
    const data = new FormData();
    data.append("idPedido", this.state.idPedido);
    data.append("idFactura", this.state.idFactura);
    data.append("idConsecutivo", String(id));
    data.append("tipoArchivo", tipoArchivo);
    data.append("folio", this.state.folio);
    data.append("IsAdjunto", "1");
    data.append("isEvidenciaComplementaria", bandera);
    data.append("path", String(file.name));
    data.append("file_attachment", file);

    fetch(uploadUrl, {
      method: "POST",
      body: data,
      headers: {
        "Content-Type": "multipart/form-data; ",
      },
    })
      .then((res) => {
        if (res.ok) {
          res.json().then((data) => {
            if (data == "True") {
              hideLoading();
              this.addContador(bandera);
            } else {
              hideLoading();
              this.finishedLoad(bandera);
              Alert.alert(data);
            }
          });
        } else if (res.status == 401) {
          alert("Oops! algo salio mal, intenta nuevamente ");
        }
      })
      .catch((error) => {});
  }

  addContador(bandera) {
    this.MetodoAuxiliarParaActualizarVista();
    if (bandera == 0) {
      this.setState({
        folder1: true,
        loading: false,
        showTheThing: true,
        isVisibleCamaraFolio: false,
      });
    } else {
      this.setState({
        folder2: true,
        loading2: false,
        showTheThingEvidComple: true,
        isVisibleEvidenciaComplementaria: false,
      });
    }
  }
  finishedLoad(bandera) {
    if (bandera == 0) {
      this.setState({
        folder1: true,
        loading: false,
        showTheThing: true,
        isVisibleCamaraFolio: false,
      });
    } else {
      this.setState({
        folder2: true,
        loading2: false,
        showTheThingEvidComple: true,
        isVisibleEvidenciaComplementaria: false,
      });
    }
  }

  render() {
    const save = <Icon name="save" size={20} color="white" />;
    const finalizarPedido = (
      <Icon name="check-circle" size={20} color="white" />
    );
    const capturarImagen = (
      <Icon2 name="panorama-fish-eye" size={45} color="white" />
    );
    const cancelarImagen = <Icon2 name="clear" size={30} color="white" />;
    const camara = <Icon name="camera" size={30} color="#3483D8" />;
    const adjuntar = (
      <Icon name="folder-open" size={30} color="#3483D8" marginLeft="9" />
    );

    return (
      <View style={{ flex: 1 }}>
        <HeaderContenido home={this.home.bind(this)} />

        <View style={styles.containerPrincipal}>
          <View style={styles.textoContainerTitulo}>
            <Text style={styles.titulo}>Bitacora de Entrega</Text>
            <Text style={styles.titulo1}>Factura : {this.state.idFactura}</Text>
          </View>
          <View style={styles.containerInpput}>
            <KeyboardAwareScrollView>
              <View style={styles.modalContent}>
                <View
                  style={{
                    flexDirection: "row",
                    justifyContent: "flex-start",
                    width: "100%",
                    height: "17%",
                    padding: "1%",
                    borderColor: "#ddd",
                    borderWidth: 0.5,
                    padding: "2.5%",
                    borderRadius: 5,
                    borderBottomWidth: 0,
                    shadowColor: "#3483D8",
                    shadowOffset: { width: 0, height: 1 },
                    shadowOpacity: 0.8,
                    shadowRadius: 2,
                    elevation: 2,
                  }}
                >
                  <View
                    style={{
                      justifyContent: "center",
                      padding: "1%",
                      flexDirection: "column",
                      width: "65%",
                      height: "100%",
                    }}
                  >
                    <Text style={styles.titulo2}>Folio: </Text>
                    <TextInput
                      returnKeyType="next"
                      value={this.state.folio}
                      underlineColorAndroid="transparent"
                      placeholderTextColor="rgba(10,10,10,0.5)"
                      style={styles.input}
                      onChangeText={(folio) => this.onChangeFolio(folio)}
                    />
                  </View>
                  <View style={{ padding: "1%" }}>
                    <View
                      style={{
                        flexDirection: "row",
                        justifyContent: "flex-start",
                      }}
                    >
                      {this.state.arrayImagen.length < 5 ? (
                        <TouchableOpacity
                          style={{ paddingLeft: 7 }}
                          onPress={this.openImagePicker.bind(this)}
                        >
                          {camara}
                        </TouchableOpacity>
                      ) : null}
                      <Text style={styles.titulo1}>
                        {this.state.arrayImagen.length === undefined
                          ? 0
                          : this.state.arrayImagen.length}
                      </Text>
                      {this.state.estatusPedido == "0" ? (
                        <TouchableOpacity
                          style={{ width: 30, padding: "1%" }}
                          onPress={() => this.limpioImagenes("1", "0")}
                        >
                          <Icon2
                            name="remove-circle-outline"
                            size={26}
                            color="red"
                          />
                        </TouchableOpacity>
                      ) : null}
                    </View>
                    <View
                      style={{
                        flexDirection: "row",
                        justifyContent: "flex-start",
                        paddingLeft: 6,
                      }}
                    >
                      {this.state.folder1 ? (
                        this.state.arrayAdjuntos1.length < 5 ? (
                          <TouchableOpacity
                            style={{ marginLeft: 0 }}
                            onPress={() => this.ArchivoGaleria("0")}
                          >
                            {adjuntar}
                          </TouchableOpacity>
                        ) : null
                      ) : null}
                      {this.state.loading ? (
                        <View style={{ paddingBottom: 4 }}>
                          <ActivityIndicator
                            animating={this.state.loading}
                            size="small"
                            color="#00ff00"
                          />
                        </View>
                      ) : null}
                      <Text style={styles.titulo1}>
                        {this.state.arrayAdjuntos1.length}
                      </Text>

                      {this.state.estatusPedido == "0" ? (
                        <TouchableOpacity
                          style={{ width: 30, padding: "1%" }}
                          onPress={() => this.limpioImagenes("1", "1")}
                        >
                          <Icon2
                            name="remove-circle-outline"
                            size={26}
                            color="red"
                          />
                        </TouchableOpacity>
                      ) : null}
                    </View>
                  </View>
                </View>
                {this.state.isVisibleCamaraFolio && (
                  <View style={styles.container}>
                    <View
                      style={{
                        flexDirection: "row",
                        justifyContent: "center",
                        zIndex: 3,
                        position: "absolute",
                        height: 10,
                      }}
                    >
                      <TouchableOpacity
                        onPress={this.closeImagePicker.bind(this)}
                        style={styles.cancelCapture}
                      >
                        {cancelarImagen}
                      </TouchableOpacity>
                    </View>
                    <RNCamera
                      ref={(ref) => {
                        this.camera = ref;
                      }}
                      style={styles.preview}
                      autoFocus={RNCamera.Constants.AutoFocus.on}
                      type={RNCamera.Constants.Type.back}
                      flashMode={RNCamera.Constants.FlashMode.auto}
                      permissionDialogTitle={"Permission to use camera"}
                      permissionDialogMessage={
                        "We need your permission to use your camera phone"
                      }
                      // onGoogleVisionBarcodesDetected={({ barcodes }) => {
                      //   console.log(barcodes);
                      // }}
                    />
                    <View
                      style={{
                        flex: 0,
                        flexDirection: "row",
                        justifyContent: "center",
                      }}
                    >
                      <TouchableOpacity
                        onPress={this.takePicture.bind(this)}
                        style={styles.capture}
                      >
                        {capturarImagen}
                      </TouchableOpacity>
                    </View>
                  </View>
                )}
                <View
                  style={{
                    flexDirection: "row",
                    justifyContent: "flex-start",
                    width: "100%",
                    marginBottom: "2%",
                    marginTop: "2%",
                    height: "13%",
                    padding: "1%",
                    borderColor: "#ddd",
                    borderWidth: 0.5,
                    padding: "2.5%",
                    borderRadius: 5,
                    borderBottomWidth: 0,
                    shadowColor: "#3483D8",
                    shadowOffset: { width: 0, height: 1 },
                    shadowOpacity: 0.8,
                    shadowRadius: 2,
                    elevation: 2,
                  }}
                >
                  <Text style={styles.titulo2}>
                    Evidencia {"\n"}Complementaria:
                  </Text>
                  {this.state.arrayImagenComplementaria.length < 5 ? (
                    <TouchableOpacity
                      style={{ marginLeft: 5 }}
                      onPress={this.openImagePickerEvidenciaComplementaria.bind(
                        this
                      )}
                    >
                      {camara}
                    </TouchableOpacity>
                  ) : null}
                  <Text style={styles.titulo1}>
                    {this.state.arrayImagenComplementaria.length}
                  </Text>

                  {this.state.estatusPedido == "0" ? (
                    <TouchableOpacity
                      style={{ width: 30, padding: "1%" }}
                      onPress={() => this.limpioImagenes("0", "0")}
                    >
                      <Icon2
                        name="remove-circle-outline"
                        size={26}
                        color="red"
                      />
                    </TouchableOpacity>
                  ) : null}

                  {this.state.folder2 ? (
                    this.state.arrayAdjuntos1.length < 5 ? (
                      <TouchableOpacity
                        style={{ marginLeft: "8%" }}
                        onPress={() => this.ArchivoGaleria("1")}
                      >
                        {adjuntar}
                      </TouchableOpacity>
                    ) : null
                  ) : null}
                  {this.state.loading2 ? (
                    <View style={{ paddingBottom: 4, marginLeft: "8%" }}>
                      <ActivityIndicator
                        animating={this.state.loading2}
                        size="small"
                        color="#00ff00"
                      />
                    </View>
                  ) : null}
                  <Text style={styles.titulo1}>
                    {this.state.arrayAdjuntos2.length}
                  </Text>

                  {this.state.estatusPedido == "0" ? (
                    <TouchableOpacity
                      style={{ width: 30, padding: "1%", marginRight: 3 }}
                      onPress={() => this.limpioImagenes("0", "1")}
                    >
                      <Icon2
                        name="remove-circle-outline"
                        size={26}
                        color="red"
                      />
                    </TouchableOpacity>
                  ) : null}
                </View>
                {this.state.isVisibleEvidenciaComplementaria && (
                  <View style={styles.container}>
                    <View
                      style={{
                        flexDirection: "row",
                        justifyContent: "center",
                        zIndex: 3,
                        position: "absolute",
                        height: 10,
                      }}
                    >
                      <TouchableOpacity
                        onPress={this.closeImagePickerEvidenciaComplementaria.bind(
                          this
                        )}
                        style={styles.cancelCapture}
                      >
                        {cancelarImagen}
                      </TouchableOpacity>
                    </View>
                    <RNCamera
                      ref={(ref) => {
                        this.camera = ref;
                      }}
                      style={styles.preview}
                      autoFocus={RNCamera.Constants.AutoFocus.on}
                      type={RNCamera.Constants.Type.back}
                      flashMode={RNCamera.Constants.FlashMode.auto}
                      permissionDialogTitle={"Permission to use camera"}
                      permissionDialogMessage={
                        "We need your permission to use your camera phone"
                      }
                      // onGoogleVisionBarcodesDetected={({ barcodes }) => {
                      //   console.log(barcodes);
                      // }}
                    />
                    <View
                      style={{
                        flex: 0,
                        flexDirection: "row",
                        justifyContent: "center",
                      }}
                    >
                      <TouchableOpacity
                        onPress={this.takePicture2.bind(this)}
                        style={styles.capture}
                      >
                        {capturarImagen}
                      </TouchableOpacity>
                    </View>
                  </View>
                )}
                <View style={styles.divCajasTapas}>
                  <Text style={styles.titulo3}>
                    Devolución de Plástico Vacío
                  </Text>
                  <View style={{ flexDirection: "row", marginLeft: "2%" }}>
                    <View
                      style={{
                        flexDirection: "row",
                        justifyContent: "flex-start",
                        width: "45%",
                        marginRight: "3%",
                      }}
                    >
                      <Text style={styles.titulo2}>Cajas{"\n"}Vacías</Text>
                      <TextInput
                        keyboardType="numeric"
                        returnKeyType="next"
                        value={this.state.cajasDevueltas}
                        underlineColorAndroid="transparent"
                        placeholderTextColor="rgba(10,10,10,0.5)"
                        style={styles.inputCajasTapas}
                        onChangeText={(cajasDevueltas) =>
                          this.onChangeCajasDevueltas(cajasDevueltas)
                        }
                      />
                    </View>
                    <View
                      style={{
                        flexDirection: "row",
                        justifyContent: "flex-start",
                        width: "45%",
                      }}
                    >
                      <Text style={styles.titulo2}>Tapas{"\n"}</Text>
                      <TextInput
                        keyboardType="numeric"
                        returnKeyType="next"
                        value={this.state.tapasDevueltas}
                        underlineColorAndroid="transparent"
                        placeholderTextColor="rgba(10,10,10,0.5)"
                        style={styles.inputCajasTapas}
                        onChangeText={(tapasDevueltas) =>
                          this.onChangeTapasDevueltas(tapasDevueltas)
                        }
                      />
                    </View>
                  </View>
                </View>
                <View
                  style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    width: "100%",
                    marginTop: 5,
                  }}
                >
                  <Text style={styles.titulo2}>Temperatura Termo °C</Text>
                  <TextInput
                    keyboardType="numeric"
                    returnKeyType="go"
                    value={this.state.temperatura}
                    underlineColorAndroid="transparent"
                    placeholderTextColor="rgba(10,10,10,0.5)"
                    style={styles.inputKgTemperatura}
                    onChangeText={(temperatura) =>
                      this.onChangeTemperatura(temperatura)
                    }
                  />
                </View>
                <Text style={styles.titulo2}>
                  Kilogramos Totales : {this.state.pesoTotalSinFiltro} kg
                </Text>
                <Text style={styles.titulo2}>
                  Kilogramos Entregados : {this.state.pesoTotal} kg
                </Text>
                <Text style={styles.titulo2}>
                  Merma : {this.state.merma} kg
                </Text>

                {this.state.estatusPedido == "0" ? (
                  <View style={{ top: "3%" }}>
                    <TouchableOpacity
                      style={styles.button2}
                      onPress={() => this.GrabarDatos()}
                    >
                      <Text style={styles.buttonText}>{save} Grabar Datos</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={styles.button}
                      onPress={() => this.FinalizarPedido()}
                    >
                      <Text style={styles.buttonText}>
                        {finalizarPedido} Finalizar Pedido
                      </Text>
                    </TouchableOpacity>
                  </View>
                ) : null}
              </View>
            </KeyboardAwareScrollView>
          </View>
        </View>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  containerLoading: {
    flex: 1,
    justifyContent: "center",
  },
  horizontal: {
    flexDirection: "row",
    justifyContent: "space-around",
    padding: 10,
  },
  container: {
    flex: 1,
    flexDirection: "column",
    backgroundColor: "black",
    position: "absolute",
    zIndex: 3,
    elevation: 5,
    width: responsiveWidth(95),
    height: responsiveHeight(73.5),
    marginTop: 20,
  },
  preview: {
    flex: 1,
    justifyContent: "flex-end",
    alignItems: "center",
    width: responsiveWidth(100),
    height: responsiveHeight(100),
  },
  capture: {
    backgroundColor: "transparent",
    paddingHorizontal: "43%",
    alignSelf: "center",
    marginTop: "-39%",
  },
  cancelCapture: {
    backgroundColor: "transparent",
    paddingHorizontal: 10,
    alignSelf: "center",
    marginTop: 15,
  },
  divCajasTapas: {
    flexDirection: "column",
    justifyContent: "space-between",
    width: "100%",
    borderColor: "#ddd",
    borderWidth: 0.5,
    padding: 5,
    borderRadius: 5,
    borderBottomWidth: 0,
    shadowColor: "#3483D8",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 2,
  },
  titulo1: {
    backgroundColor: "transparent",
    color: "black",
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(2) : responsiveFontSize(2),
    padding: "2%",
  },
  titulo: {
    backgroundColor: "transparent",
    color: "black",
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(2) : responsiveFontSize(2.5),
    padding: "2%",
  },
  titulo2: {
    backgroundColor: "transparent",
    color: "#434346",
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(2) : responsiveFontSize(1.7),
    padding: 0,
  },
  titulo3: {
    textAlign: "center",
    backgroundColor: "transparent",
    color: "#434346",
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(2) : responsiveFontSize(1.7),
  },
  textoContainerTitulo: {
    position: "absolute",
    alignItems: "center",
    width: "100%",
    height: "100%",
  },
  containerPrincipal: {
    flex: 2,
    backgroundColor: "#fcfcff",
  },
  modalContent: {
    backgroundColor: "transparent",
    padding: 20,
    height: responsiveHeight(75),
  },
  input: {
    marginBottom: 15,
    height: 35,
    borderWidth: 1,
    borderRadius: 5,
    width: "100%",
    backgroundColor: "#ffffff",
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
    padding: 0,
    paddingLeft: 7,
  },
  inputKgTemperatura: {
    marginBottom: 15,
    height: 35,
    borderWidth: 1,
    borderRadius: 5,
    backgroundColor: "#ffffff",
    width: "55%",
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
    padding: 0,
    paddingLeft: 7,
  },
  inputCajasTapas: {
    marginBottom: 15,
    height: 35,
    borderWidth: 1,
    borderRadius: 5,
    backgroundColor: "#ffffff",
    width: "50%",
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
    padding: 0,
    paddingLeft: 7,
  },
  icono: {
    marginBottom: "3%",
  },
  button: {
    backgroundColor: "#3483D8",
    paddingTop: 15,
    paddingBottom: 15,
    marginTop: 5,
    borderRadius: 5,
    top: "3%",
    marginBottom: "3%",
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
  },
  button2: {
    backgroundColor: "#0BA803",
    paddingTop: 15,
    paddingBottom: 15,
    marginTop: 5,
    borderRadius: 5,
    top: "3%",
    marginBottom: "3%",
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
  },
  buttonText: {
    textAlign: "center",
    color: "#fff",
  },
  containerInpput: {
    position: "absolute",
    width: "95%",
    height: "84%",
    top: "12%",
    marginLeft: "2.5%",
    backgroundColor: "#ffffff",
    borderRadius: 25,
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
  },
});
