import React, { Component } from "react";
import {
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  RefreshControl,
  Platform,
} from "react-native";
import AsyncStorage from "@react-native-community/async-storage";
import ListView from "deprecated-react-native-listview";
import { Actions } from "react-native-router-flux";
import Icon from "react-native-vector-icons/MaterialIcons";
import { responsiveFontSize } from "react-native-responsive-dimensions";
const ID_STG = "numeroSocio";
const IDPLANTA_STG = "idplanta";
const RUTA_STG = "ruta";
export default class ItemClientesConFoliosRecuperados extends Component {
  constructor(props) {
    super(props);
    this.getDatos();
    const ds = new ListView.DataSource({
      rowHasChanged: (r1, r2) => r1 !== r2,
    });

    this.state = {
      dataSourceClientesConFolio: ds,
      rfc: "",
      refreshing: false,
      idRuta: "",
      idPlanta: "",
    };
  }

  async getDatos() {
    let rfc = await AsyncStorage.getItem(ID_STG);
    let idRuta = await AsyncStorage.getItem(RUTA_STG);
    let idPlanta = await AsyncStorage.getItem(IDPLANTA_STG);
    this.setState({
      rfc: rfc,
      idRuta: idRuta,
      idPlanta: idPlanta,
    });
  }

  _onRefresh() {}

  componentDidMount() {
    this.upDateDataSource(this.props.datos);
  }

  componentWillReceiveProps(newProps) {
    if (newProps.datos !== this.props.datos) {
      this.upDateDataSource(newProps.datos);
    }
  }
  upDateDataSource = (data) => {
    this.setState({
      dataSourceClientesConFolio: this.state.dataSourceClientesConFolio.cloneWithRows(
        data
      ),
    });
  };

  llammaVistaFoliosRecuperados(nombreCliente, pedido, factura, idCliente) {
    Actions.recuperacionFolios({ nombreCliente, pedido, factura, idCliente });
  }
  render() {
    const RecuperacionFolios = (
      <Icon name="description" size={35} color="#3483D8" marginRight="5%" />
    );

    return (
      <View style={{ flex: 1 }}>
        <ListView
          refreshControl={
            <RefreshControl
              refreshing={this.state.refreshing}
              onRefresh={this._onRefresh.bind(this)}
            />
          }
          style={styles.list}
          enableEmptySections
          dataSource={this.state.dataSourceClientesConFolio}
          renderRow={({ ...datos }) => {
            return (
              <View style={styles.row}>
                <View style={styles.containerPrincipal}>
                  <View style={styles.containerDatos}>
                    <View
                      style={{
                        flexDirection: "column",
                        alignItems: "flex-start",
                        width: "90%",
                      }}
                    >
                      <Text style={styles.titulo2}>{datos.NombreCliente}</Text>
                      <Text style={styles.Informacion}>
                        Pedido: {datos.noPedido}
                      </Text>
                      <Text style={styles.Informacion}>
                        Factura: {datos.Factura}
                      </Text>
                    </View>
                    <View
                      style={{
                        flexDirection: "column",
                        alignItems: "center",
                        marginLeft: "4%",
                      }}
                    >
                      <TouchableOpacity
                        onPress={() =>
                          this.llammaVistaFoliosRecuperados(
                            datos.NombreCliente,
                            datos.noPedido,
                            datos.Factura,
                            datos.IdCliente
                          )
                        }
                      >
                        <View style={styles.containerIconos}>
                          {RecuperacionFolios}
                        </View>
                        <View style={styles.containerTextDeIconos}>
                          <Text style={styles.InformacionIcono}>
                            Recuperacíon{"\n"}de Folios
                          </Text>
                        </View>
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              </View>
            );
          }}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  containerTextDeIconos: {
    left: "15%",
    textAlign: "center",
  },
  containerIconos: {
    flexDirection: "column",
    alignItems: "center",
    backgroundColor: "#fcfcff",
    borderRadius: 50,
    width: 60,
    height: 60,
    padding: 10,

    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
  },

  containerDatos: {
    flexDirection: "row",
    justifyContent: "space-between",
    padding: 10,
  },

  containerPrincipal: {
    padding: 5,
    marginLeft: 10,
    width: "80%",
  },

  titulo2: {
    textAlign: "left",
    backgroundColor: "transparent",
    color: "black",
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(2.8) : responsiveFontSize(2.6),
  },

  column: {
    flexDirection: "column",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 10,
    backgroundColor: "transparent",
    marginBottom: 5,
    marginHorizontal: 5,
    paddingHorizontal: 5,
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "stretch",
    paddingVertical: 0,
    backgroundColor: "#ffffff",
    marginBottom: 15,
    marginTop: 5,
    marginHorizontal: 15,
    paddingHorizontal: 5,
    borderRadius: 7,
    borderWidth: 1,
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 1,
  },
  list: {
    marginTop: 5,
  },

  Informacion: {
    backgroundColor: "transparent",
    color: "#434346",
    marginTop: 0,
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(1.5) : responsiveFontSize(2.2),
  },
  InformacionIcono: {
    backgroundColor: "transparent",
    color: "#434346",
    marginTop: 0,
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(1.5) : responsiveFontSize(1.5),
  },
});
