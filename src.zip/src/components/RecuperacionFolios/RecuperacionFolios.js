import React, { Component } from "react";
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  TouchableHighlight,
  Alert,
  TouchableOpacity,
  Platform,
  ActivityIndicator,
} from "react-native";
import AsyncStorage from "@react-native-community/async-storage";
import Icon from "react-native-vector-icons/FontAwesome";
import Icon2 from "react-native-vector-icons/MaterialIcons";
import { Actions } from "react-native-router-flux";
import HeaderContenido from "../Home/HeaderDetallePedido";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import {
  responsiveHeight,
  responsiveWidth,
  responsiveFontSize,
} from "react-native-responsive-dimensions";
import { BorraImagenes } from "../Utilidades/Utilerias";
import { showLoading, hideLoading } from "react-native-notifyer";
import { regexFolio } from "../../ValidacionRegex/Regex";
import {
  getRegexXCliente,
  DeleteImagenesFoliosRecuperados,
} from "../../LlamadasRest/MyHTTP";
import { RNCamera } from "react-native-camera";

import DocumentPicker from "react-native-document-picker";
const USR_STG = "numeroSocio";
const IDPLANTA_STG = "idplanta";
const RUTA_STG = "ruta";
const URi_STG = "url";
export default class RecuperacionFolios extends Component {
  constructor(props) {
    super(props);
    this.getDatos();
    this.state = {
      folio: "",
      tapasDevueltas: "",
      nombreCliente: "",
      idCliente: "",
      idFactura: "",
      idPedido: "",
      showTheThing: false,
      arrayImagen: [],
      url: "",
      isVisibleCamaraFolio: false,
      Regex: "",
      loading: false,
      folder1: true,
      arrayAdjuntos1: [],
    };
  }

  async getDatos() {
    let rfc = await AsyncStorage.getItem(USR_STG);
    let idRuta = await AsyncStorage.getItem(RUTA_STG);
    let idPlanta = await AsyncStorage.getItem(IDPLANTA_STG);
    let url = await AsyncStorage.getItem(URi_STG);
    this.setState({
      rfc: rfc,
      idRuta: idRuta,
      idPlanta: idPlanta,
      url: url,
    });
  }

  componentWillMount() {
    const factura = this.props.factura;
    const nombreCliente = this.props.nombreCliente;
    const pedido = this.props.pedido;
    const idCliente = this.props.idCliente;
    this.setState({
      idFactura: factura,
      idPedido: pedido,
      nombreCliente: nombreCliente,
      idCliente: idCliente,
    });
    getRegexXCliente(idCliente)
      .then((data) => {
        this.setState({
          Regex: data.regex,
        });
      })
      .catch((mensaje) => {});
  }

  componentDidMount() {
    this.limpioImagenes("1", "1");
  }
  onChangeFolio(folio) {
    this.setState({ folio });
  }

  home() {
    Actions.recuperacionFoliosHome();
  }

  //abro la camara de folio
  openImagePicker() {
    this.setState({ isVisibleCamaraFolio: true });
  }
  // cierro camara de folio
  closeImagePicker() {
    this.setState({ isVisibleCamaraFolio: false });
  }

  ///nuevo metodo para capturar la imagen del folio
  takePicture = async function () {
    showLoading();
    if (this.camera) {
      const options = { quality: 0.7, base64: true, width: 788 };

      const data = await this.camera.takePictureAsync(options);
      let id = this.state.arrayImagen.length;
      this.state.arrayImagen.push({ id: id, imagenData: String(data.base64) });
      this.setState({
        showTheThing: true,
        isVisibleCamaraFolio: false,
      });
      hideLoading();
    }
  };

  limpioImagen() {
    this.setState({
      arrayImagen: [],
      showTheThing: false,
    });
  }

  GuardarFolio() {
    if (
      this.state.arrayImagen.length == 0 &&
      this.state.arrayAdjuntos1.length == 0
    ) {
      Alert.alert(
        "Datos Incompletos",
        "Es necesario ingresar al menos una imagen o un archivo adjunto  ",
        [{ text: "OK", onPress: () => {} }],
        { cancelable: false }
      );
      return;
    } else {
      if (this.state.folio == "") {
        Alert.alert(
          "Datos Incompletos",
          "Es necesario ingresar folio para poder recuperar el folio ",
          [{ text: "OK", onPress: () => {} }],
          { cancelable: false }
        );
        return;
      } else {
        showLoading();
        const url = this.state.url;

        fetch(url + "FoliosRecuperados/", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            idOperador: this.state.rfc,
            folio: this.state.folio,
            idPedio: this.state.idPedido,
            idFactura: this.state.idFactura,
            imagenFolio: JSON.stringify(this.state.arrayImagen),
            idCliente: this.state.idCliente,
            idRuta: this.state.idRuta,
            idPlanta: this.state.idPlanta,
            tipoArchivo: "jpg",
            IsAdjunto: "0",
            isEvidenciaComplementaria: "0",
            Nombre: "Foto",
            IsRecuperado: "0",
          }),
        })
          .then((response) => {
            if (response.ok) {
              hideLoading();
              BorraImagenes(this.state.arrayAdjuntos1);
              Actions.recuperacionFoliosHome();
              Alert.alert(
                "Se ha guardado la información con éxito",
                "Se han enviado los datos correctamente ",
                [{ text: "OK", onPress: () => {} }],
                { cancelable: false }
              );
            } else {
              hideLoading();
              Alert.alert(
                "Algo salio mal!",
                "Error:" + response.status,
                [{ text: "OK", onPress: () => {} }],
                { cancelable: false }
              );
              const error = new Error(response.statusText);
              error.response = response;
              throw error;
            }
          })
          .catch((error) => {});
      }
    }
  }

  limpioImagenes(IsFolio, IsAdjunto) {
    showLoading();
    DeleteImagenesFoliosRecuperados(
      this.state.idPedido,
      this.state.idFactura,
      IsFolio,
      IsAdjunto
    )
      .then((data) => {
        if (data == "True") {
          this.setState({
            arrayAdjuntos1: [],
            arrayImagen: [],
          });
          hideLoading();
        } else {
          hideLoading();
          alert("Algo ocurrio mal, intentalo nuevamente");
        }
      })
      .catch((mensaje) => {});
  }

  async ArchivoGaleria(bandera) {
    if (String(this.state.folio).length > 0) {
      if (!regexFolio(this.state.folio, this.state.Regex)) {
        Alert.alert(
          "¡Folio Incorrecto!",
          "Ingresa correctamente el folio de tu cliente",
          [{ text: "OK", onPress: () => {} }],
          { cancelable: false }
        );
        return;
      }
    }
    if (this.state.folio == "") {
      Alert.alert(
        "¡Datos Incompletos!",
        "Es obligatorio capturar folio e imagen para guardar datos de pedido",
        [{ text: "OK", onPress: () => {} }],
        { cancelable: false }
      );
      return;
    }

    try {
      const res = await DocumentPicker.pick({
        type: [DocumentPicker.types.images, DocumentPicker.types.pdf],
      });
      const id =
        bandera == "0"
          ? this.state.arrayAdjuntos1.lenght
          : this.state.arrayAdjuntos2.lenght;
      this.AddArrayFile(res, res.type, bandera, id);
    } catch (err) {
      if (DocumentPicker.isCancel(err)) {
      } else {
      }
    }
  }

  async AddArrayFile(file, tipoArchivo, bandera, id) {
    if (bandera === "0") {
      this.setState({
        folder1: false,
        loading: true,
      });
    }

    const uploadUrl = this.state.url + "FoliosRecuperados";
    const data = new FormData();
    data.append("idPedido", this.state.idPedido);
    data.append("idFactura", this.state.idFactura);
    data.append("idConsecutivo", String(id));
    data.append("tipoArchivo", tipoArchivo);
    data.append("folio", this.state.folio);
    data.append("IsAdjunto", "1");
    data.append("isEvidenciaComplementaria", bandera);
    data.append("IdOperador", this.state.rfc);
    data.append("idCliente", this.state.idCliente);
    data.append("idPlanta", this.state.idPlanta);
    data.append("idRuta", this.state.idRuta);
    data.append("nombre", file.name);
    data.append("IsRecuperado", "0");
    data.append("file_attachment", file);

    fetch(uploadUrl, {
      method: "PUT",
      body: data,
      headers: {
        "Content-Type": "multipart/form-data; ",
      },
    })
      .then((res) => {
        if (res.ok) {
          res.json().then((data) => {
            if (data == "Truee") {
              const lenght = this.state.arrayAdjuntos1.lenght;
              this.state.arrayAdjuntos1.push({
                id: lenght,
                Path: file.name,
              });
              this.setState({
                folder1: true,
                loading: false,
                showTheThing: true,
                isVisibleCamaraFolio: false,
              });
            } else {
              Alert.alert(data);
            }
          });
        } else if (res.status == 401) {
          alert("Oops! algo salio mal, intenta nuevamente ");
        }
      })
      .catch((error) => {});
  }

  render() {
    const save = <Icon name="save" size={20} color="white" />;

    const camara = <Icon name="camera" size={30} color="#3483D8" />;
    const capturarImagen = (
      <Icon2 name="panorama-fish-eye" size={45} color="white" />
    );
    const adjuntar = (
      <Icon name="folder-open" size={30} color="#3483D8" marginLeft="9" />
    );
    const cancelarImagen = <Icon2 name="clear" size={30} color="white" />;
    return (
      <View style={{ flex: 1 }}>
        <HeaderContenido home={this.home.bind(this)} />
        <View style={styles.containerPrincipal}>
          <View style={styles.textoContainerTitulo}>
            <Text style={styles.titulo1}>Recuperación de Folios</Text>
            <Text style={styles.titulo1}>
              Cliente : {this.state.nombreCliente}
            </Text>
          </View>
          <View style={styles.containerInpput}>
            <KeyboardAwareScrollView>
              <View style={styles.modalContent}>
                <Text style={styles.titulo1}>
                  Pedido : {this.state.idPedido}
                </Text>
                <Text style={styles.titulo1}>
                  Factura : {this.state.idFactura}
                </Text>
                <View
                  style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    width: "100%",

                    height: "20%",
                  }}
                >
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "flex-start",
                      width: "90%",
                      marginRight: "3%",
                    }}
                  >
                    <View
                      style={{
                        justifyContent: "center",
                        padding: "1%",
                        flexDirection: "column",
                        width: "65%",
                        height: "100%",
                      }}
                    >
                      <Text style={styles.titulo2}>Folio</Text>
                      <TextInput
                        returnKeyType="next"
                        value={this.state.folio}
                        underlineColorAndroid="transparent"
                        placeholderTextColor="rgba(10,10,10,0.5)"
                        style={styles.input}
                        onChangeText={(folio) => this.onChangeFolio(folio)}
                      />
                    </View>
                    <View>
                      <View
                        style={{
                          flexDirection: "row",
                          justifyContent: "flex-start",
                        }}
                      >
                        {this.state.arrayImagen.length < 5 ? (
                          <TouchableOpacity
                            style={{ paddingLeft: 7 }}
                            onPress={this.openImagePicker.bind(this)}
                          >
                            {camara}
                          </TouchableOpacity>
                        ) : null}
                        <Text style={styles.titulo1}>
                          {" "}
                          {this.state.arrayImagen.length}
                        </Text>
                        {this.state.showTheThing && (
                          <TouchableOpacity
                            style={{ width: 30, paddingLeft: 7 }}
                            onPress={() => this.limpioImagenes("0", "0")}
                          >
                            <Icon2
                              name="remove-circle-outline"
                              size={25}
                              color="red"
                            />
                          </TouchableOpacity>
                        )}
                      </View>
                      <View
                        style={{
                          flexDirection: "row",
                          justifyContent: "flex-start",
                          paddingLeft: 6,
                        }}
                      >
                        {this.state.folder1 ? (
                          this.state.arrayAdjuntos1.length < 5 ? (
                            <TouchableOpacity
                              style={{ marginRight: 2 }}
                              onPress={() => this.ArchivoGaleria("0")}
                            >
                              {adjuntar}
                            </TouchableOpacity>
                          ) : null
                        ) : null}
                        {this.state.loading ? (
                          <View style={{ paddingBottom: 4 }}>
                            <ActivityIndicator
                              animating={this.state.loading}
                              size="small"
                              color="#00ff00"
                            />
                          </View>
                        ) : null}
                        <Text style={styles.titulo1}>
                          {this.state.arrayAdjuntos1.length}
                        </Text>
                        <TouchableOpacity
                          style={{ width: 30, padding: "1%", marginLeft: 2 }}
                          onPress={() => this.limpioImagenes("1", "1")}
                        >
                          <Icon2
                            name="remove-circle-outline"
                            size={26}
                            color="red"
                          />
                        </TouchableOpacity>
                      </View>
                    </View>
                  </View>
                </View>

                {!this.state.isVisibleCamaraFolio && (
                  <TouchableHighlight
                    style={styles.button2}
                    onPress={() => this.GuardarFolio()}
                  >
                    <Text style={styles.buttonText}>
                      {save} Recuperar Folio
                    </Text>
                  </TouchableHighlight>
                )}
              </View>
              {this.state.isVisibleCamaraFolio && (
                <View style={styles.container}>
                  <View
                    style={{
                      justifyContent: "center",
                      zIndex: 3,
                      position: "absolute",
                      height: "5%",
                      marginTop: "2%",
                    }}
                  >
                    <TouchableOpacity
                      onPress={this.closeImagePicker.bind(this)}
                      style={styles.cancelCapture}
                    >
                      {cancelarImagen}
                    </TouchableOpacity>
                  </View>
                  <View></View>
                  <RNCamera
                    ref={(ref) => {
                      this.camera = ref;
                    }}
                    style={styles.preview}
                    type={RNCamera.Constants.Type.back}
                    flashMode={RNCamera.Constants.FlashMode.off}
                    permissionDialogTitle={"Permission to use camera"}
                    permissionDialogMessage={
                      "We need your permission to use your camera phone"
                    }
                   
                    onBarCodeRead={(barcode) => {
                      const { data } = barcode;
                      this.setState({ isVisibleCamaraFolio: false });
                      Alert.alert(
                        "Lectura de Codigo Correcta",
                        `Codigo: ${data} `,
                        [{ text: "ok", onPress: () => {} }]
                      );
                    }}
                  />
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "center",
                      zIndex: 3,
                      position: "absolute",
                      height: 10,
                      marginTop: "100%",
                    }}
                  >
                    <TouchableOpacity
                      onPress={this.takePicture.bind(this)}
                      style={styles.capture}
                    >
                      {capturarImagen}
                    </TouchableOpacity>
                  </View>
                </View>
              )}
            </KeyboardAwareScrollView>
          </View>
        </View>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: "column",
    backgroundColor: "black",
    position: "absolute",
    zIndex: 3,
    elevation: 5,
    height: responsiveHeight(100),
  },
  preview: {
    flex: 1,
    width: responsiveWidth(100),
    height: responsiveHeight(100),
  },
  capture: {
    backgroundColor: "transparent",
    marginHorizontal: "42%",
    alignSelf: "center",
    marginTop: 15,
    width: "13%",
  },
  cancelCapture: {
    backgroundColor: "transparent",
    marginHorizontal: "3%",
    alignSelf: "center",
    marginTop: "1%",
  },
  titulo1: {
    backgroundColor: "transparent",
    color: "black",
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(2) : responsiveFontSize(2.2),
  },
  titulo2: {
    backgroundColor: "transparent",
    color: "#434346",
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(2) : responsiveFontSize(1.7),
  },
  textoContainerTitulo: {
    position: "absolute",
    alignItems: "center",
    width: "100%",
    height: "100%",
    top: "2.5%",
  },
  containerPrincipal: {
    flex: 2,
    backgroundColor: "#fcfcff",
  },
  modalContent: {
    backgroundColor: "transparent",
    padding: 20,
    height: responsiveHeight(65),
  },
  input: {
    marginBottom: 15,
    height: 35,
    borderWidth: 1,
    borderRadius: 5,
    width: "100%",
    backgroundColor: "#ffffff",
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
    padding: 0,
    paddingLeft: 7,
  },
  button2: {
    backgroundColor: "#0BA803",
    paddingTop: 15,
    paddingBottom: 15,
    marginTop: 5,
    borderRadius: 5,
    top: "3%",
    marginBottom: "3%",
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
  },
  buttonText: {
    textAlign: "center",
    color: "#fff",
  },
  containerInpput: {
    position: "absolute",
    width: "95%",
    height: "80%",
    top: "14%",
    marginLeft: "2.5%",
    backgroundColor: "#ffffff",
    borderRadius: 25,
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
  },
});
