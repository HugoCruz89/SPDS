import React, { Component } from "react";
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  
  TouchableOpacity,
  Platform,
} from "react-native";
import AsyncStorage from "@react-native-community/async-storage";
import Icon from "react-native-vector-icons/FontAwesome";
import { Actions } from "react-native-router-flux";
import HeaderContenido from "../Home/HeaderContenido";
import { getClientesConFolio } from "../../LlamadasRest/MyHTTP";
import ItemsApi from "../RecuperacionFolios/ItemClientesConFoliosRecuperados";
import { showLoading, hideLoading } from "react-native-notifyer";
import { responsiveFontSize } from "react-native-responsive-dimensions";

const IDPLANTA_STG = "idplanta";

const URi_STG = "url";
export default class RecuperacionFoliosHome extends Component {
  constructor(props) {
    super(props);
    this.getDatos();
    this.state = {
      datos: [],
      idCliente: "",
      idPlanta: "",
      url: "",
      idFactura: "",
    };
  }

  async getDatos() {
    //showLoading()
    let idPlanta = await AsyncStorage.getItem(IDPLANTA_STG);
    let url = await AsyncStorage.getItem(URi_STG);
    this.setState({
      idPlanta: idPlanta,
      url: url,
    });
  }

  componentWillReceiveProps(newProps) {
    if (newProps.datos !== this.props.datos) {
      this.upDateDataSource(newProps.datos);
    }
  }
  upDateDataSource = (data) => {
    this.setState({
      datos: data,
    });
  };

  onChangeIdFactura(idFactura) {
    this.setState({ idFactura });
  }

  onChangeIdCliente(idCliente) {
    this.setState({ idCliente: idCliente });

    if (idCliente.length < 3) {
      this.setState({ datos: [] });
    } else {
      showLoading();
      const idPlanta = this.state.idPlanta;

      const filtro = "xClientes";
      //metod que trae los clientes con folios pendientes filtrados por el idCliente
      getClientesConFolio(idCliente, idPlanta, filtro)
        .then((data) => {
          if (data.length > 0) {
            this.setState({ datos: data });
          } else if (data.length === undefined) {
            this.setState({ datos: [] });
          }
        })
        .then((data) => hideLoading())
        .catch((error) => hideLoading());
    }
  }

  home() {
    Actions.home();
  }

  buscarFolio() {
    showLoading();
    const idFactura = this.state.idFactura;
    const idPlanta = this.state.idPlanta;

    const filtro = "xFactura";
    //metod que trae los clientes con folios pendientes filtrados por el idFactura
    getClientesConFolio(idFactura, idPlanta, filtro)
      .then((data) => this.setState({ datos: data }))
      .then((data) => hideLoading())
      .catch((error) => hideLoading());
  }

  render() {
    const datos = this.state.datos;

    const buscar = <Icon name="search" size={25} color="#3483D8" />;
    return (
      <View style={{ flex: 1 }}>
        <HeaderContenido home={this.home.bind(this)} />

        <View style={styles.containerPrincipal}>
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              width: "80%",
              marginRight: "3%",
              marginTop: 10,
            }}
          >
            <Text style={styles.titulo2}>Cliente</Text>
            <TextInput
              // keyboardType = 'numeric'
              returnKeyType="next"
              value={this.state.idCliente}
              underlineColorAndroid="transparent"
              placeholderTextColor="rgba(10,10,10,0.5)"
              style={styles.inputIDCliente}
              onChangeText={(idCliente) => this.onChangeIdCliente(idCliente)}
            />
            {/*      <TouchableOpacity  onPress={()=>this.buscarCliente()}>
              {buscar}
              </TouchableOpacity>*/}
          </View>
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              width: "80%",
              marginRight: "3%",
              marginTop: 10,
            }}
          >
            <Text style={styles.titulo2}>Factura</Text>
            <TextInput
              keyboardType="numeric"
              returnKeyType="next"
              value={this.state.idFactura}
              underlineColorAndroid="transparent"
              placeholderTextColor="rgba(10,10,10,0.5)"
              style={styles.inputIDCliente}
              onChangeText={(idFactura) => this.onChangeIdFactura(idFactura)}
            />
            <TouchableOpacity
              style={{ marginLeft: "5%" }}
              onPress={() => this.buscarFolio()}
            >
              {buscar}
            </TouchableOpacity>
          </View>
          <ItemsApi datos={datos} />
        </View>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  containerPrincipal: {
    flex: 2,
    backgroundColor: "#fcfcff",
  },

  titulo2: {
    backgroundColor: "transparent",
    color: "#434346",
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(2) : responsiveFontSize(2),
    marginLeft: 10,
    marginRight: 10,
  },
  inputIDCliente: {
    marginBottom: 15,
    height: 35,
    borderWidth: 1,
    borderRadius: 5,
    backgroundColor: "#ffffff",
    width: "80%",
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,

    padding: 0,
    paddingLeft: 7,
  },
});
