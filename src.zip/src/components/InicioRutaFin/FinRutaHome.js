import React, { Component } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableHighlight,
  Alert
} from "react-native";
import Icon2 from "react-native-vector-icons/MaterialIcons";
import { Actions } from "react-native-router-flux";
import HeaderContenido from "../Home/HeaderDetallePedido";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import AsyncStorage from "@react-native-community/async-storage";
import { getGTS } from "../../LlamadasRest/MyHTTP";
import { EstiloFinRuta } from "../../Estilos/Estilos";
import { showToast, showLoading, hideLoading } from "react-native-notifyer";
import Panel from "react-native-panel";
import { getResumenRuta } from "../../LlamadasRest/MyHTTP";
import Geolocation from "@react-native-community/geolocation";
import { isNumero } from "../../ValidacionRegex/Regex";
import { isFormValido } from "../../ValidacionRegex/ValidacionFormInicioRuta";
import { GetDateTime } from "../Utilidades/GetDateTime";

const RFC_STG = "RFC";
const NOMBRE_STG = "nombre";
const PATERNO_STG = "apPat";
const MATERNO_STG = "apMat";
const PLANTA_STG = "planta";
const USR_STG = "numeroSocio";
const ROL_STG = "rol";
const TELEFONO_STG = "telefono";
const IDPLANTA_STG = "idplanta";
const RUTA_STG = "ruta";
const URi_STG = "url";
const FECHAAPERTURA_STG = "fechaApertura";
const VEHICULO_STG = "vehiculo";
const ID_STG = "numeroSocio";
const SESSION_KEY = "__SESSION_TIMER__";

finalizarProceso = () => {
  AsyncStorage.removeItem(SESSION_KEY);
  AsyncStorage.removeItem(RFC_STG);
  AsyncStorage.removeItem(URi_STG);
  AsyncStorage.removeItem(NOMBRE_STG);
  AsyncStorage.removeItem(PATERNO_STG);
  AsyncStorage.removeItem(MATERNO_STG);
  AsyncStorage.removeItem(ID_STG);
  AsyncStorage.removeItem(ROL_STG);
  AsyncStorage.removeItem(RUTA_STG);
  AsyncStorage.removeItem(TELEFONO_STG);
  AsyncStorage.removeItem(PLANTA_STG);
  AsyncStorage.removeItem(IDPLANTA_STG);
  AsyncStorage.removeItem(FECHAAPERTURA_STG);
  Actions.login();
};

export default class FinRutaHome extends Component {
  constructor(props) {
    super(props);
    this.getDatos();
    this.state = {
      idRuta: "",
      idPlanta: "",
      idOperador: "",
      horaTermoSalida: "",
      TempSalidaCD: "",
      TerCalSalCD: "",
      LtsCargaCombSalida: "",
      KmInicial: "",
      LtsCargaTermoSalida: "",
      DEVPlastVacío: "",
      Tapas: "",
      PzasDevueltas: "",
      CajasComplDev: "",
      fechaApertura: "",
    };
  }

  async getDatos() {
    showLoading();
    let idOperador = await AsyncStorage.getItem(USR_STG);
    let idRuta = await AsyncStorage.getItem(RUTA_STG);
    let url = await AsyncStorage.getItem(URi_STG);
    let idPlanta = await AsyncStorage.getItem(IDPLANTA_STG);
    let fechaApertura = await AsyncStorage.getItem(FECHAAPERTURA_STG);

    this.setState({
      idOperador,
      idRuta,
      idPlanta,
      url,
      fechaApertura,
    });
    const bandera = "1";
    getGTS(idOperador, bandera, fechaApertura)
      .then((data) =>
        this.setState({
          // horaTermoSalida:data.Horometro,
          // TempSalidaCD:data.Temp1,
          // KmInicial:data.Odometro
        })
      )
      .then((data) => hideLoading())
      .catch((error) => hideLoading());

    getResumenRuta(idOperador, fechaApertura, idRuta)
      .then((data) =>
        this.setState({
          DEVPlastVacío: data.TotalCajasDevueltasXPedido,
          Tapas: data.TotalTapasDevueltasXPedido,
          PzasDevueltas: data.TotalPzasDevueltas,
          CajasComplDev: data.TotalCajasConProductoDevueltas,
        })
      )
      .then((data) => hideLoading())
      .catch((error) => hideLoading());
  }

  grabarDatos() {
    showLoading();
    const idOperador = this.state.idOperador;
    const idRuta = this.state.idRuta;
    const idPlanta = this.state.idPlanta;
    const url = this.state.url;
    const fechaApertura = this.state.fechaApertura;
    fetch(url + "GPS", {
      method: "PUT",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        idOperador: idOperador,
        idPedido: idRuta,
        idFactura: idPlanta,
        bandera: "1",
        longitud: "0",
        latitud: "0",
        fechaApertura: fechaApertura,
        fechaCelular: GetDateTime(),
      }),
    })
      .then(function (response) {
        if (response.ok) {
          hideLoading();
          response.json().then(function (data) {
            const Respuesta = data;
            if (Respuesta === "Ruta Finalizada Con Exito") {
              Actions.home();
              Alert.alert(
                "¡" + data + "!",
                "",
                [{ text: "OK", onPress: () => this.finalizarProceso() }],
                { cancelable: false }
              );
            } else {
              Alert.alert(
                "¡Algo salio mal!",
                "Detalle: " + data,
                [
                  {
                    text: "Cancelar",
                    onPress: () => {},
                  },
                  { text: "OK", onPress: () =>{} },
                ],
                { cancelable: false }
              );
            }
          });
        } else {
          hideLoading();
          Alert.alert(
            "¡Algo salio mal!",
            "Intenta nuevamente",
            [
              {
                text: "Cancelar",
                onPress: () =>{},
              },
              { text: "OK", onPress: () =>{} },
            ],
            { cancelable: false }
          );
          const error = new Error(response.statusText);

          error.response = response;
          throw error;
        }
      })
      .catch((error) => {
        Alert.alert(
          "¡Algo salio mal!",
          "Intenta nuevamente",
          [
            { text: "Cancelar", onPress: () => {} },
            { text: "OK", onPress: () => {} },
          ],
          { cancelable: false }
        );
      });
  } //finalziarRuta

  onChangeHoraTermoSalida(horaTermoSalida) {
    if (isNumero(horaTermoSalida)) {
      this.setState({ horaTermoSalida });
    } else {
      showToast("Carcater Invalido");
    }
  }
  onChangeTempSalidaCD(TempSalidaCD) {
    this.setState({ TempSalidaCD });
  }

  onChangeTerCalSalCD(TerCalSalCD) {
    if (isNumero(TerCalSalCD)) {
      this.setState({ TerCalSalCD });
    } else {
      showToast("Carcater Invalido");
    }
  }
  onChangeLtsCargaCombSalida(LtsCargaCombSalida) {
    this.setState({ LtsCargaCombSalida });
  }

  onChangeKmInicial(KmInicial) {
    if (isNumero(KmInicial)) {
      this.setState({ KmInicial });
    } else {
      showToast("Carcater Invalido");
    }
  }
  onChangeLtsCargaTermoSalida(LtsCargaTermoSalida) {
    this.setState({ LtsCargaTermoSalida });
  }

  home() {
    Actions.home();
  }

  finalizarRuta = () => {
    const objeto = new Object();
    objeto = {
      horometro: this.state.horaTermoSalida,
      kmIncial: this.state.KmInicial,
      terCalSalCD: this.state.TerCalSalCD,
      temperatura: this.state.TempSalidaCD,
      LtsCargaCombSalida: this.state.LtsCargaCombSalida,
      LtsCargaTermoSalida: this.state.LtsCargaTermoSalida,
    };
    if (isFormValido(JSON.stringify(objeto))) {
      showLoading();
      Geolocation.getCurrentPosition(
        (info) => {
          const latitud = info.coords.latitude;
          const longitud = info.coords.longitude;
          const url = this.state.url;
          const fechaApertura = this.state.fechaApertura;

          fetch(url + "InicioFinRuta/", {
            method: "PUT",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              idRuta: this.state.idRuta,
              idPlanta: this.state.idPlanta,
              idOperador: this.state.idOperador,
              horaTermoEntrada: this.state.horaTermoSalida,
              TempEntradaCD: this.state.TempSalidaCD,
              TerCalEntCD: this.state.TerCalSalCD,
              LtsCargaCombEntrada: this.state.LtsCargaCombSalida,
              KmFinal: this.state.KmInicial,
              LtsCargaTermoEntrada: this.state.LtsCargaTermoSalida,
              latitud: latitud,
              longitud: longitud,
              FechaApertura: fechaApertura,
            }),
          })
            .then(() => this.grabarDatos())
            .catch((error) => {
              Alert.alert(
                "Algo salio mal!",
                "Error:" + error,
                [{ text: "OK", onPress: () => {} }],
                { cancelable: false }
              );
            });
        },
        (error) => this.finalizarRutaSinDatos()
      );
    }
  }; //grabarDatos

  finalizarRutaSinDatos() {
    const latitud = "n/d";
    const longitud = "n/d";
    const url = this.state.url;
    const fechaApertura = this.state.fechaApertura;

    let temperatura = this.state.TempSalidaCD;
    let temperaturaValidada = String(parseFloat(temperatura));
    fetch(url + "InicioFinRuta/", {
      method: "PUT",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        idRuta: this.state.idRuta,
        idPlanta: this.state.idPlanta,
        idOperador: this.state.idOperador,
        horaTermoEntrada: this.state.horaTermoSalida,
        TempEntradaCD: temperaturaValidada,
        TerCalEntCD: this.state.TerCalSalCD,
        LtsCargaCombEntrada: this.state.LtsCargaCombSalida,
        KmFinal: this.state.KmInicial,
        LtsCargaTermoEntrada: this.state.LtsCargaTermoSalida,
        latitud: latitud,
        longitud: longitud,
        FechaApertura: fechaApertura,
      }),
    })
      .then(() => this.grabarDatos())
      .catch((error) => {
        Alert.alert(
          "Algo salio mal!",
          "Error:" + error,
          [{ text: "OK", onPress: () => {} }],
          { cancelable: false }
        );
      });
  }

  render() {
    const save = <Icon2 name="usb" size={20} color="white" />;
    return (
      <View style={{ flex: 1 }}>
        <HeaderContenido home={this.home.bind(this)} />
        <View style={EstiloFinRuta.containerPrincipal}>
          <View style={EstiloFinRuta.textoContainerTitulo}>
            <Text style={EstiloFinRuta.titulo1}>Finalizar Ruta</Text>
          </View>
          <View style={EstiloFinRuta.containerInpput}>
            <KeyboardAwareScrollView>
              <View style={EstiloFinRuta.modalContent}>
                {/*///////////////////------------------Resumen Ruta--------------------------////////////////////////////////////////////////////////////////*/}
                <Panel
                  style={EstiloFinRuta.firstHeaderContainer}
                  header="Resumen de Ruta"
                >
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      width: "97%",
                    }}
                  >
                    <View
                      style={{
                        flexDirection: "row",
                        justifyContent: "space-between",
                        width: "50%",
                        marginRight: "3%",
                        marginBottom: "3%",
                      }}
                    >
                      <Text style={EstiloFinRuta.titulo2}>
                        Cajas Plast. Vacío: {this.state.DEVPlastVacío}{" "}
                      </Text>
                    </View>
                    <View
                      style={{
                        flexDirection: "row",
                        justifyContent: "flex-start",
                        width: "50%",
                      }}
                    >
                      <Text style={EstiloFinRuta.titulo2}>
                        Tapas Dev.: {this.state.Tapas}
                      </Text>
                    </View>
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      width: "97%",
                    }}
                  >
                    <View
                      style={{
                        flexDirection: "row",
                        justifyContent: "flex-start",
                        width: "50%",
                        marginRight: "3%",
                      }}
                    >
                      <Text style={EstiloFinRuta.titulo2}>
                        Pzas Devueltas: {this.state.PzasDevueltas}
                      </Text>
                    </View>
                    <View
                      style={{
                        flexDirection: "row",
                        justifyContent: "flex-start",
                        width: "50%",
                      }}
                    >
                      <Text style={EstiloFinRuta.titulo2}>
                        Cajas Compl. Dev.: {this.state.CajasComplDev}{" "}
                      </Text>
                    </View>
                  </View>
                </Panel>

                {/*///////////////////------------------GTS--------------------------////////////////////////////////////////////////////////////////*/}
                <View
                  style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    width: "97%",
                    marginTop: "5%",
                  }}
                >
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      width: "50%",
                      marginRight: "3%",
                    }}
                  >
                    <Text style={EstiloFinRuta.titulo2}>
                      Hor. Term.{"\n"}Entrada
                    </Text>
                    <TextInput
                      keyboardType="numeric"
                      returnKeyType="next"
                      value={this.state.horaTermoSalida}
                      underlineColorAndroid="transparent"
                      placeholderTextColor="rgba(10,10,10,0.5)"
                      style={EstiloFinRuta.inputCajasTapas}
                      onChangeText={(horaTermoSalida) =>
                        this.onChangeHoraTermoSalida(horaTermoSalida)
                      }
                    />
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      width: "50%",
                    }}
                  >
                    <Text style={EstiloFinRuta.titulo2}>
                      Temp.{"\n"}Entrada CD
                    </Text>
                    <TextInput
                      keyboardType="numeric"
                      returnKeyType="next"
                      value={this.state.TempSalidaCD}
                      underlineColorAndroid="transparent"
                      placeholderTextColor="rgba(10,10,10,0.5)"
                      style={EstiloFinRuta.inputCajasTapas}
                      onChangeText={(TempSalidaCD) =>
                        this.onChangeTempSalidaCD(TempSalidaCD)
                      }
                    />
                  </View>
                </View>
                <View
                  style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    width: "97%",
                  }}
                >
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      width: "50%",
                      marginRight: "3%",
                    }}
                  >
                    <Text style={EstiloFinRuta.titulo2}>
                      Ter. Cal.{"\n"}Ent. CD.
                    </Text>
                    <TextInput
                      //editable = {false}
                      keyboardType="numeric"
                      returnKeyType="next"
                      value={this.state.TerCalSalCD}
                      underlineColorAndroid="transparent"
                      placeholderTextColor="rgba(10,10,10,0.5)"
                      style={EstiloFinRuta.inputCajasTapas}
                      onChangeText={(TerCalSalCD) =>
                        this.onChangeTerCalSalCD(TerCalSalCD)
                      }
                    />
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      width: "50%",
                    }}
                  >
                    <Text style={EstiloFinRuta.titulo2}>
                      Lts. Carga{"\n"}Comb. Entrada
                    </Text>
                    <TextInput
                      keyboardType="numeric"
                      returnKeyType="next"
                      value={this.state.LtsCargaCombSalida}
                      underlineColorAndroid="transparent"
                      placeholderTextColor="rgba(10,10,10,0.5)"
                      style={EstiloFinRuta.inputCajasTapas}
                      onChangeText={(LtsCargaCombSalida) =>
                        this.onChangeLtsCargaCombSalida(LtsCargaCombSalida)
                      }
                    />
                  </View>
                </View>
                <View
                  style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    width: "97%",
                  }}
                >
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      width: "50%",
                      marginRight: "3%",
                    }}
                  >
                    <Text style={EstiloFinRuta.titulo2}>Km.{"\n"}Final</Text>
                    <TextInput
                      keyboardType="numeric"
                      returnKeyType="next"
                      value={this.state.KmInicial}
                      underlineColorAndroid="transparent"
                      placeholderTextColor="rgba(10,10,10,0.5)"
                      style={EstiloFinRuta.inputCajasTapas}
                      onChangeText={(KmInicial) =>
                        this.onChangeKmInicial(KmInicial)
                      }
                    />
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      width: "50%",
                    }}
                  >
                    <Text style={EstiloFinRuta.titulo2}>
                      Lts. Carga{"\n"}Termo. Entrada
                    </Text>
                    <TextInput
                      keyboardType="numeric"
                      returnKeyType="next"
                      value={this.state.LtsCargaTermoSalida}
                      underlineColorAndroid="transparent"
                      placeholderTextColor="rgba(10,10,10,0.5)"
                      style={EstiloFinRuta.inputCajasTapas}
                      onChangeText={(LtsCargaTermoSalida) =>
                        this.onChangeLtsCargaTermoSalida(LtsCargaTermoSalida)
                      }
                    />
                  </View>
                </View>
                <TouchableHighlight
                  style={EstiloFinRuta.button2}
                  onPress={() =>
                    Alert.alert(
                      "¡Estas Seguro de Finalizar Ruta!",
                      "Este proceso ya no podrá revertirse",
                      [
                        {
                          text: "Cancelar",
                          onPress: () => {},
                        },
                        { text: "OK", onPress: this.finalizarRuta },
                      ],
                      { cancelable: false }
                    )
                  }
                >
                  <Text style={EstiloFinRuta.buttonText}>
                    {save} Finalizar Ruta
                  </Text>
                </TouchableHighlight>
              </View>
            </KeyboardAwareScrollView>
          </View>
        </View>
      </View>
    );
  }
}
