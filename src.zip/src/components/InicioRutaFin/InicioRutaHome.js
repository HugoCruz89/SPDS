import React, { Component } from "react";
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  TouchableHighlight,
  Alert,
  Platform,
} from "react-native";
import AsyncStorage from "@react-native-community/async-storage";
import Icon2 from "react-native-vector-icons/MaterialIcons";
import { Actions } from "react-native-router-flux";
import HeaderContenido from "../Home/HeaderDetallePedido";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import { getGTS } from "../../LlamadasRest/MyHTTP";
import {
  responsiveHeight,
  responsiveFontSize,
} from "react-native-responsive-dimensions";
import { showToast, showLoading, hideLoading } from "react-native-notifyer";
import Geolocation from "@react-native-community/geolocation";
import { isFormValido } from "../../ValidacionRegex/ValidacionFormInicioRuta";
import { isNumero } from "../../ValidacionRegex/Regex";
import { GetDateTime } from "../Utilidades/GetDateTime";
import { GetUrl } from "../Utilidades/UrlUtility";

const USR_STG = "numeroSocio";
const IDPLANTA_STG = "idplanta";
const RUTA_STG = "ruta";
const URi_STG = "url";
const FECHAAPERTURA_STG = "fechaApertura";
export default class InicioRutaHome extends Component {
  constructor(props) {
    super(props);
    this.getDatos();
    this.state = {
      idRuta: "",
      idPlanta: "",
      idOperador: "",
      horaTermoSalida: "",
      TempSalidaCD: "",
      TerCalSalCD: "",
      LtsCargaCombSalida: "",
      KmInicial: "",
      LtsCargaTermoSalida: "",
      visible: "0",
      fechaApertura: "",
    };
  }

  async getDatos() {
    GetUrl();
    showLoading();
    let idOperador = await AsyncStorage.getItem(USR_STG);
    let idRuta = await AsyncStorage.getItem(RUTA_STG);
    let idPlanta = await AsyncStorage.getItem(IDPLANTA_STG);
    let url = await AsyncStorage.getItem(URi_STG);
    let fechaApertura = await AsyncStorage.getItem(FECHAAPERTURA_STG);
    this.setState({
      idOperador,
      idRuta,
      url,
      idPlanta,
      fechaApertura,
    });
    const bandera = "0";

    getGTS(idOperador, bandera, fechaApertura)
      .then((data) => {
        if (data.Nombre === "1") {
          this.setState({
            horaTermoSalida: data.Horometro,
            TempSalidaCD: data.Temp1,
            KmInicial: data.Odometro,
            visible: data.Nombre,
            LtsCargaCombSalida: data.Temp2,
            LtsCargaTermoSalida: data.Temp3,
          });
        } else {
          this.setState({
            //   horaTermoSalida:data.Horometro,
            //   TempSalidaCD:data.Temp1,
            //   KmInicial:data.Odometro,
            visible: data.Nombre,
            LtsCargaCombSalida: "",
            LtsCargaTermoSalida: "",
          });
        }
      })
      .then((data) => hideLoading())
      .catch((error) => hideLoading());
  }

  /// grabo datos bitacoraTraco
  GuardardatosGTS() {
    const idOperador = this.state.idOperador;
    const idPedido = this.state.idRuta;
    const idFactura = this.state.idPlanta;
    const fechaApertura = this.state.fechaApertura;
    const url = this.state.url;
    fetch(url + "GPS/", {
      method: "PUT",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        idOperador: idOperador,
        //idRuta
        idPedido: idPedido,
        //idPlanta
        idFactura: idFactura,
        bandera: "0",
        longitud: "0",
        latitud: "0",
        fechaApertura: fechaApertura,
        fechaCelular: GetDateTime(),
      }),
    })
      .then(function (response) {
        if (response.ok) {
          hideLoading();
        } else {
          hideLoading();
          const error = new Error(response.statusText);

          error.response = response;
          throw error;
        }
      })
      .catch((error) => {
        hideLoading();
      });
  }

  onChangeHoraTermoSalida(horaTermoSalida) {
    if (isNumero(horaTermoSalida)) {
      this.setState({ horaTermoSalida });
    } else {
      showToast("Carcater Invalido");
    }
  }
  onChangeTempSalidaCD(TempSalidaCD) {
    this.setState({ TempSalidaCD });
  }

  onChangeTerCalSalCD(TerCalSalCD) {
    if (isNumero(TerCalSalCD)) {
      this.setState({ TerCalSalCD });
    } else {
      showToast("Carcater Invalido");
    }
  }
  onChangeLtsCargaCombSalida(LtsCargaCombSalida) {
    this.setState({ LtsCargaCombSalida });
  }

  onChangeKmInicial(KmInicial) {
    if (isNumero(KmInicial)) {
      this.setState({ KmInicial });
    } else {
      showToast("Carcater Invalido");
    }
  }
  onChangeLtsCargaTermoSalida(LtsCargaTermoSalida) {
    this.setState({ LtsCargaTermoSalida });
  }

  home() {
    Actions.home();
  }
  //grabar en bitacoraTracoCelular sin coordenadas
  GrabarDatosSinCoordenadas() {
   
    const latitud = "0";
    const longitud = "0";
    let temperatura = this.state.TempSalidaCD;
    const validaTemperatura = String(parseFloat(temperatura));

    const url = this.state.url;
    fetch(url + "InicioFinRuta/", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        idRuta: this.state.idRuta,
        idPlanta: this.state.idPlanta,
        idOperador: this.state.idOperador,
        horaTermoSalida: this.state.horaTermoSalida,
        TempSalidaCD: validaTemperatura,
        TerCalSalCD: this.state.TerCalSalCD,
        LtsCargaCombSalida: this.state.LtsCargaCombSalida,
        KmInicial: this.state.KmInicial,
        LtsCargaTermoSalida: this.state.LtsCargaTermoSalida,
        latitud: latitud,
        longitud: longitud,
        FechaApertura: this.state.fechaApertura,
        //NumeroTelefono:numberoTelefono
      }),
    })
      .then(function (response) {
        if (response.ok) {
          hideLoading();
          Actions.home();
          Alert.alert(
            "Se ha guardado la información con éxito ",
            "Sin coordenadas ",
            [{ text: "OK", onPress: () => {} }],
            { cancelable: false }
          );
        } else {
          hideLoading();
          Alert.alert(
            "Algo salio mal!",
            "Error:" + response._bodyInit,
            [{ text: "OK", onPress: () => {} }],
            { cancelable: false }
          );
          const error = new Error(response.statusText);
          error.response = response;
          throw error;
        }
      })
      .then(() => this.GuardardatosGTS())
      .catch((error) => {
        Alert.alert(
          "Algo salio mal!",
          "Error:" + error,
          [{ text: "OK", onPress: () => {} }],
          { cancelable: false }
        );
      });
  }

  //grabar en bitacoraTracoCelular
  GrabarDatos() {
    let objeto = new Object();
    objeto = {
      horometro: this.state.horaTermoSalida,
      kmIncial: this.state.KmInicial,
      terCalSalCD: this.state.TerCalSalCD,
      temperatura: this.state.TempSalidaCD,
      LtsCargaCombSalida: this.state.LtsCargaCombSalida,
      LtsCargaTermoSalida: this.state.LtsCargaTermoSalida,
    };
    if (this.state.visible == "1") {
      Alert.alert(
        "Ruta Ya Iniciada!",
        "Esta ruta ya se inicio previamente  ",
        [{ text: "OK", onPress: () => {} }],
        { cancelable: false }
      );
    } else {
      if (isFormValido(JSON.stringify(objeto))) {
        showLoading();
        if (this.state.LtsCargaTermoSalida == null)
          this.setState({ LtsCargaTermoSalida: "0" });
        if (this.state.LtsCargaCombSalida == null)
          this.setState({ LtsCargaCombSalida: "0" });
        Geolocation.getCurrentPosition(
          (info) => {
            const latitud = info.coords.latitude;
            const longitud = info.coords.longitude;
            const url = this.state.url;
            fetch(url + "InicioFinRuta/", {
              method: "POST",
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
              },
              body: JSON.stringify({
                idRuta: this.state.idRuta,
                idPlanta: this.state.idPlanta,
                idOperador: this.state.idOperador,
                horaTermoSalida: this.state.horaTermoSalida,
                TempSalidaCD: this.state.TempSalidaCD,
                TerCalSalCD: this.state.TerCalSalCD,
                LtsCargaCombSalida: this.state.LtsCargaCombSalida,
                KmInicial: this.state.KmInicial,
                LtsCargaTermoSalida: this.state.LtsCargaTermoSalida,
                latitud: String(latitud),
                longitud: String(longitud),
                FechaApertura: this.state.fechaApertura,
                // NumeroTelefono:numberoTelefono
              }),
            })
              .then(function (response) {
                if (response.ok) {
                  hideLoading();
                  Actions.home();
                  Alert.alert(
                    "Se ha guardado la información con éxito",
                    "Se han enviado los datos correctamente ",
                    [{ text: "OK", onPress: () => {} }],
                    { cancelable: false }
                  );
                } else {
                  hideLoading();
                  Alert.alert(
                    "Algo salio mal!",
                    "Error:" + response._bodyInit,
                    [
                     { text: "OK", onPress: () =>{} },
                    ],
                    { cancelable: false }
                  );
                  const error = new Error(response.statusText);
                  error.response = response;
                  throw error;
                }
              })
              .then(() => this.GuardardatosGTS())
              .catch((error) => {
                Alert.alert(
                  "Algo salio mal!",
                  "Error:" + error,
                  [{ text: "OK", onPress: () =>{} }],
                  { cancelable: false }
                );
              });
          },
          (error) => this.GrabarDatosSinCoordenadas()
        );
      }
    }
  }

  render() {
    const save = <Icon2 name="usb" size={20} color="white" top={5} />;
    return (
      <View style={{ flex: 1 }}>
        <HeaderContenido home={this.home.bind(this)} />
        <View style={styles.containerPrincipal}>
          <View style={styles.textoContainerTitulo}>
            <Text style={styles.titulo1}>Inicio de Ruta</Text>
          </View>
          <View style={styles.containerInpput}>
            <KeyboardAwareScrollView>
              <View style={styles.modalContent}>
                <View
                  style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    width: "97%",
                  }}
                >
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      width: "50%",
                      marginRight: "3%",
                    }}
                  >
                    <Text style={styles.titulo2}>Hor. Term.{"\n"}Salida</Text>
                    {this.state.visible == "1" ? (
                      <TextInput
                        editable={false}
                        keyboardType="numeric"
                        returnKeyType="next"
                        value={this.state.horaTermoSalida}
                        underlineColorAndroid="transparent"
                        placeholderTextColor="rgba(10,10,10,0.5)"
                        style={styles.inputCajasTapas}
                        onChangeText={(horaTermoSalida) =>
                          this.onChangeHoraTermoSalida(horaTermoSalida)
                        }
                      />
                    ) : (
                      <TextInput
                        keyboardType="numeric"
                        returnKeyType="next"
                        value={this.state.horaTermoSalida}
                        underlineColorAndroid="transparent"
                        placeholderTextColor="rgba(10,10,10,0.5)"
                        style={styles.inputCajasTapas}
                        onChangeText={(horaTermoSalida) =>
                          this.onChangeHoraTermoSalida(horaTermoSalida)
                        }
                      />
                    )}
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      width: "50%",
                    }}
                  >
                    <Text style={styles.titulo2}>Temp.{"\n"}Salida CD</Text>
                    {this.state.visible == "1" ? (
                      <TextInput
                        editable={false}
                        keyboardType="numeric"
                        returnKeyType="next"
                        value={this.state.TempSalidaCD}
                        underlineColorAndroid="transparent"
                        placeholderTextColor="rgba(10,10,10,0.5)"
                        style={styles.inputCajasTapas}
                        onChangeText={(TempSalidaCD) =>
                          this.onChangeTempSalidaCD(TempSalidaCD)
                        }
                      />
                    ) : (
                      <TextInput
                        keyboardType="numeric"
                        returnKeyType="next"
                        value={this.state.TempSalidaCD}
                        underlineColorAndroid="transparent"
                        placeholderTextColor="rgba(10,10,10,0.5)"
                        style={styles.inputCajasTapas}
                        onChangeText={(TempSalidaCD) =>
                          this.onChangeTempSalidaCD(TempSalidaCD)
                        }
                      />
                    )}
                  </View>
                </View>

                <View
                  style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    width: "97%",
                  }}
                >
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      width: "50%",
                      marginRight: "3%",
                    }}
                  >
                    <Text style={styles.titulo2}>Ter. Cal.{"\n"}Sal. CD.</Text>
                    {this.state.visible == "1" ? (
                      <TextInput
                        editable={false}
                        keyboardType="numeric"
                        returnKeyType="next"
                        value={this.state.TerCalSalCD}
                        underlineColorAndroid="transparent"
                        placeholderTextColor="rgba(10,10,10,0.5)"
                        style={styles.inputCajasTapas}
                        onChangeText={(TerCalSalCD) =>
                          this.onChangeTerCalSalCD(TerCalSalCD)
                        }
                      />
                    ) : (
                      <TextInput
                        keyboardType="numeric"
                        returnKeyType="next"
                        value={this.state.TerCalSalCD}
                        underlineColorAndroid="transparent"
                        placeholderTextColor="rgba(10,10,10,0.5)"
                        style={styles.inputCajasTapas}
                        onChangeText={(TerCalSalCD) =>
                          this.onChangeTerCalSalCD(TerCalSalCD)
                        }
                      />
                    )}
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      width: "50%",
                    }}
                  >
                    <Text style={styles.titulo2}>
                      Lts. Carga{"\n"}Comb. Salida
                    </Text>
                    {this.state.visible == "1" ? (
                      <TextInput
                        editable={false}
                        keyboardType="numeric"
                        returnKeyType="next"
                        value={this.state.LtsCargaCombSalida}
                        underlineColorAndroid="transparent"
                        placeholderTextColor="rgba(10,10,10,0.5)"
                        style={styles.inputCajasTapas}
                        onChangeText={(LtsCargaCombSalida) =>
                          this.onChangeLtsCargaCombSalida(LtsCargaCombSalida)
                        }
                      />
                    ) : (
                      <TextInput
                        keyboardType="numeric"
                        returnKeyType="next"
                        value={this.state.LtsCargaCombSalida}
                        underlineColorAndroid="transparent"
                        placeholderTextColor="rgba(10,10,10,0.5)"
                        style={styles.inputCajasTapas}
                        onChangeText={(LtsCargaCombSalida) =>
                          this.onChangeLtsCargaCombSalida(LtsCargaCombSalida)
                        }
                      />
                    )}
                  </View>
                </View>
                <View
                  style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    width: "97%",
                  }}
                >
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      width: "50%",
                      marginRight: "3%",
                    }}
                  >
                    <Text style={styles.titulo2}>Km.{"\n"}Inicial</Text>
                    {this.state.visible == "1" ? (
                      <TextInput
                        editable={false}
                        keyboardType="numeric"
                        returnKeyType="next"
                        value={this.state.KmInicial}
                        underlineColorAndroid="transparent"
                        placeholderTextColor="rgba(10,10,10,0.5)"
                        style={styles.inputCajasTapas}
                        onChangeText={(KmInicial) =>
                          this.onChangeKmInicial(KmInicial)
                        }
                      />
                    ) : (
                      <TextInput
                        keyboardType="numeric"
                        returnKeyType="next"
                        value={this.state.KmInicial}
                        underlineColorAndroid="transparent"
                        placeholderTextColor="rgba(10,10,10,0.5)"
                        style={styles.inputCajasTapas}
                        onChangeText={(KmInicial) =>
                          this.onChangeKmInicial(KmInicial)
                        }
                      />
                    )}
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      width: "50%",
                    }}
                  >
                    <Text style={styles.titulo2}>
                      Lts. Carga{"\n"}Termo. Salida
                    </Text>
                    {this.state.visible == "1" ? (
                      <TextInput
                        editable={false}
                        keyboardType="numeric"
                        returnKeyType="next"
                        value={this.state.LtsCargaTermoSalida}
                        underlineColorAndroid="transparent"
                        placeholderTextColor="rgba(10,10,10,0.5)"
                        style={styles.inputCajasTapas}
                        onChangeText={(LtsCargaTermoSalida) =>
                          this.onChangeLtsCargaTermoSalida(LtsCargaTermoSalida)
                        }
                      />
                    ) : (
                      <TextInput
                        keyboardType="numeric"
                        returnKeyType="next"
                        value={this.state.LtsCargaTermoSalida}
                        underlineColorAndroid="transparent"
                        placeholderTextColor="rgba(10,10,10,0.5)"
                        style={styles.inputCajasTapas}
                        onChangeText={(LtsCargaTermoSalida) =>
                          this.onChangeLtsCargaTermoSalida(LtsCargaTermoSalida)
                        }
                      />
                    )}
                  </View>
                </View>
                {this.state.visible == "1" ? (
                  <TouchableHighlight
                    disabled={true}
                    style={styles.button2}
                    onPress={() => this.GrabarDatos()}
                  >
                    <Text style={styles.buttonText}>
                      {save}Grabar Datos{"\n"}Inicio Ruta
                    </Text>
                  </TouchableHighlight>
                ) : (
                  <TouchableHighlight
                    style={styles.button2}
                    onPress={() => this.GrabarDatos()}
                  >
                    <Text style={styles.buttonText}>
                      {save}Grabar Datos{"\n"}Inicio Ruta
                    </Text>
                  </TouchableHighlight>
                )}
              </View>
            </KeyboardAwareScrollView>
            <View style={styles.textoContainerMensaje}>
              {this.state.visible == "1" ? (
                <Text style={styles.titulo1}>Ruta ya Iniciada</Text>
              ) : (
                <Text style={styles.titulo1}></Text>
              )}
            </View>
          </View>
        </View>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  titulo1: {
    backgroundColor: "transparent",
    color: "black",
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(2) : responsiveFontSize(2.2),
  },
  titulo2: {
    backgroundColor: "transparent",
    color: "#434346",
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(2) : responsiveFontSize(1.7),
  },
  textoContainerTitulo: {
    position: "absolute",
    alignItems: "center",
    width: "100%",
    height: "100%",
    top: "2.5%",
  },
  textoContainerMensaje: {
    position: "absolute",
    alignItems: "center",
    width: "100%",
    height: "100%",
    top: "60%",
  },
  containerPrincipal: {
    flex: 2,
    backgroundColor: "#fcfcff",
  },
  modalContent: {
    backgroundColor: "transparent",
    padding: 20,
    height: responsiveHeight(70),
  },
  input: {
    marginBottom: 15,
    height: 35,
    borderWidth: 1,
    borderRadius: 5,
    width: "70%",
    backgroundColor: "#ffffff",
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
    padding: 0,
    paddingLeft: 7,
  },
  inputKgTemperatura: {
    marginBottom: 15,
    height: 35,
    borderWidth: 1,
    borderRadius: 5,
    backgroundColor: "#ffffff",
    width: "65%",
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
    padding: 0,
    paddingLeft: 7,
  },
  inputCajasTapas: {
    marginBottom: 15,
    height: 35,
    borderWidth: 1,
    borderRadius: 5,
    backgroundColor: "#ffffff",
    width: "50%",
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
    padding: 0,
    paddingLeft: 7,
  },
  icono: {
    marginBottom: "3%",
  },
  button: {
    backgroundColor: "#3483D8",
    paddingTop: 15,
    paddingBottom: 15,
    marginTop: 5,
    borderRadius: 5,
    top: "3%",
    marginBottom: "3%",
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
  },
  button2: {
    backgroundColor: "#0BA803",
    paddingTop: 15,
    paddingBottom: 15,
    marginTop: 5,
    borderRadius: 5,
    top: "3%",
    marginBottom: "3%",
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
  },
  buttonText: {
    textAlign: "center",
    color: "#fff",
  },
  containerInpput: {
    position: "absolute",
    width: "95%",
    height: "80%",
    top: "12%",
    marginLeft: "2.5%",
    backgroundColor: "#ffffff",
    borderRadius: 25,
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
  },
});
