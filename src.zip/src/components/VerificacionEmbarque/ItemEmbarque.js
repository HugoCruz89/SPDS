import React, { Component } from "react";
import {
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  RefreshControl,
  Platform,
} from "react-native";
import AsyncStorage from "@react-native-community/async-storage";
import ListView from "deprecated-react-native-listview";
import { Actions } from "react-native-router-flux";
import Icon from "react-native-vector-icons/Ionicons";
import { getEmbarque } from "../../LlamadasRest/MyHTTP";
import { responsiveFontSize } from "react-native-responsive-dimensions";
const ID_STG = "numeroSocio";
const RUTA_STG = "ruta";
const URi_STG = "url";

export default class ItemEmbarque extends Component {
  constructor(props) {
    super(props);
    this.getDatos();
    const ds = new ListView.DataSource({
      rowHasChanged: (r1, r2) => r1 !== r2,
    });

    this.state = {
      dataSourceEmbarque: ds,
      rfc: "",
      refreshing: false,
      totalCS: this.props.totalCS,
      ruta: "",
      url: "",
    };
  }

  async getDatos() {
    let rfc = await AsyncStorage.getItem(ID_STG);
    let ruta = await AsyncStorage.getItem(RUTA_STG);
    let url = await AsyncStorage.getItem(URi_STG);
    let idRuta = await AsyncStorage.getItem(RUTA_STG);
    this.setState({
      rfc: rfc,
      ruta: ruta,
      url: url,
      idRuta: idRuta,
    });
  }

  _onRefresh() {
    this.setState({ refreshing: true });
    getEmbarque(this.state.rfc, this.state.idRuta).then((data) =>
      this.setState({
        dataSourceEmbarque: this.state.dataSourceEmbarque.cloneWithRows(
          data.listaVerficiacionEmbarque
        ),
        refreshing: false,
      })
    );
  }

  componentDidMount() {
    this.upDateDataSource(this.props.datos);
  }

  componentWillReceiveProps(newProps) {
    if (newProps.datos !== this.props.datos) {
      this.upDateDataSource(newProps.datos);
    }
  }
  upDateDataSource = (data) => {
    this.setState({
      dataSourceEmbarque: this.state.dataSourceEmbarque.cloneWithRows(data),
    });
  };

  MostrarDetalleEmbarque() {
    Actions.detalleEmbarque();
  }

  render() {
    const detalle = (
      <Icon
        name="logo-buffer"
        size={35}
        color="#3483D8"
        marginLeft="5%"
        backgroundColor="blue"
      />
    );
    return (
      <View style={{ flex: 1 }}>
        <View style={{ flexDirection: "row", marginBottom: "2%" }}>
          <View style={styles.contenedorEncabezado}>
            <Text style={styles.titulo1}>Ruta: {this.state.ruta}</Text>
            <Text style={styles.titulo1}>
              Total Cajas: {this.props.totalCS}
            </Text>
            <Text style={styles.titulo1}>
              Fecha Carga: {this.props.fechaCarga}
            </Text>
          </View>
          <View style={{}}>
            <View style={styles.containerIconos}>
              <TouchableOpacity onPress={() => this.MostrarDetalleEmbarque()}>
                <View style={{ marginLeft: "25%" }}>{detalle}</View>
                <Text style={styles.Informacion}> Detalle </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
        <ListView
          refreshControl={
            <RefreshControl
              refreshing={this.state.refreshing}
              onRefresh={this._onRefresh.bind(this)}
            />
          }
          style={styles.list}
          enableEmptySections
          dataSource={this.state.dataSourceEmbarque}
          renderRow={({ ...datos }) => {
            return (
              <View style={{ flexDirection: "row" }}>
                <View style={styles.row}>
                  <View style={styles.containerPrincipal2}>
                    <Text style={styles.Informacion}>
                      Producto: {datos.Material}
                    </Text>
                    <Text style={styles.Informacion1}>{datos.Descripcion}</Text>
                  </View>
                </View>
                <View style={styles.row2}>
                  <View style={styles.containerPrincipal}>
                    <Text style={styles.Informacion}>
                      Cajas: {datos.TotalCSxMaterial}
                    </Text>
                  </View>
                </View>
              </View>
            );
          }}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  containerIconos: {
    //flexDirection: 'row',
    alignItems: "center",
    backgroundColor: "#fcfcff",
    borderRadius: 50,
    width: "80%",
    //height: '40%',
    padding: 10,
    marginTop: 10,

    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 2,
  },

  titulo1: {
    marginHorizontal: "4%",
    backgroundColor: "transparent",
    color: "black",
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(2.8) : responsiveFontSize(2.7),
  },

  containerPrincipal: {
    padding: 5,
    marginLeft: 10,
    width: "100%",
  },
  containerPrincipal2: {
    padding: 5,
    marginLeft: 10,
    width: "65%",
  },

  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "stretch",
    paddingVertical: 0,
    backgroundColor: "#ffffff",
    marginBottom: 15,
    marginHorizontal: 1,
    paddingHorizontal: 5,
    marginLeft: "3%",
    marginTop: 9,
    borderRadius: 7,
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 2,
  },
  row2: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "stretch",
    paddingVertical: 0,
    backgroundColor: "#ffffff",
    marginBottom: 15,
    marginHorizontal: 15,
    paddingHorizontal: 5,
    marginLeft: "3%",
    width: "25%",
    marginTop: 9,
    borderRadius: 7,
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 2,
  },
  list: {
    marginTop: 5,
  },
  Informacion1: {
    backgroundColor: "transparent",
    color: "#3483D8",
    marginTop: 0,
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(1.5) : responsiveFontSize(2),
  },
  Informacion: {
    backgroundColor: "transparent",
    color: "#434346",
    marginTop: 0,
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(1.5) : responsiveFontSize(2),
  },
});
