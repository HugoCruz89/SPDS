import React, { Component } from "react";
import { StyleSheet, View, Platform } from "react-native";
import AsyncStorage from "@react-native-community/async-storage";
import { Actions } from "react-native-router-flux";
import HeaderContenido from "../Home/HeaderContenido";
import { getEmbarque } from "../../LlamadasRest/MyHTTP";
import ItemsApi from "../VerificacionEmbarque/ItemEmbarque";

import { responsiveFontSize } from "react-native-responsive-dimensions";
import { showLoading, hideLoading } from "react-native-notifyer";

const ID_STG = "numeroSocio";

const RUTA_STG = "ruta";
export default class VerficiacionEmbarqueHome extends Component {
  constructor(props) {
    super(props);
    this.getDatos();
    this.state = {
      datos: [],
      totalCS: 0,
      fechaCarga: "",
    };
  }
  async getDatos() {
    showLoading();
    let idOperador = await AsyncStorage.getItem(ID_STG);
    let idRuta = await AsyncStorage.getItem(RUTA_STG);

    getEmbarque(idOperador, idRuta)
      .then((data) =>
        this.setState({
          datos: data.listaVerficiacionEmbarque,
          totalCS: data.totalCSxEmbarque,
          fechaCarga: data.fechaCarga,
        })
      )
      .then((data) => hideLoading())
      .catch((error) => hideLoading());
  }

  componentWillReceiveProps(newProps) {
    if (newProps.datos !== this.props.datos) {
      this.upDateDataSource(newProps.datos);
    }
  }
  upDateDataSource = (data) => {
    this.setState({
      datos: data.listaVerficiacionEmbarque,
    });
  };

  home() {
    Actions.home();
  }
  llammaVistaAperturaClienteEntrega() {
    Actions.aperturaClienteEntrega();
  }

  render() {
    const datos = this.state.datos;
    const totalCS = this.state.totalCS;
    const fechaCarga = this.state.fechaCarga;

    return (
      <View style={{ flex: 1 }}>
        <HeaderContenido home={this.home.bind(this)} />

        <View style={styles.containerPrincipal}>
          <ItemsApi datos={datos} totalCS={totalCS} fechaCarga={fechaCarga} />
        </View>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  containerPrincipal: {
    flex: 2,
    backgroundColor: "#fcfcff",
  },
  titulo1: {
    marginTop: "10%",
    textAlign: "center",
    backgroundColor: "transparent",
    color: "black",
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(2) : responsiveFontSize(3.0),
  },
});
