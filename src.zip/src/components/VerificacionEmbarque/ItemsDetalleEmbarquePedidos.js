import React, { Component } from "react";
import { Text, View, StyleSheet, Platform } from "react-native";
import ListView from "deprecated-react-native-listview";
import { responsiveFontSize } from "react-native-responsive-dimensions";
import AsyncStorage from "@react-native-community/async-storage";
const ID_STG = "numeroSocio";
export default class ItemsDetalleEmbarquePedidos extends Component {
  constructor(props) {
    super(props);
    this.getDatos();
    const ds = new ListView.DataSource({
      rowHasChanged: (r1, r2) => r1 !== r2,
    });

    this.state = {
      dataSourceEmbarquePedidos: ds,
      rfc: "",
      refreshing: false,
    };
  }

  async getDatos() {
    let rfc = await AsyncStorage.getItem(ID_STG);
    this.setState({
      rfc: rfc,
    });
  }

  componentDidMount() {
    this.upDateDataSource(this.props.datos);
  }

  componentWillReceiveProps(newProps) {
    if (newProps.datos !== this.props.datos) {
      this.upDateDataSource(newProps.datos);
    }
  }
  upDateDataSource = (data) => {
    this.setState({
      dataSourceEmbarquePedidos: this.state.dataSourceEmbarquePedidos.cloneWithRows(
        data
      ),
    });
  };

  render() {
    return (
      <View style={{ flex: 1 }}>
        <ListView
          style={styles.list}
          enableEmptySections
          dataSource={this.state.dataSourceEmbarquePedidos}
          renderRow={({ ...datos }) => {
            return (
              <View style={styles.row}>
                <View style={styles.containerPrincipal}>
                  <Text style={styles.Informacion}>
                    Codigo: {datos.Material}
                  </Text>
                  <Text style={styles.Informacion1}>{datos.Descripcion}</Text>
                  <Text style={styles.Informacion}>
                    Total Embarcado: {datos.Cantidad}
                  </Text>
                  <Text style={styles.Informacion}>
                    Total de Kg Embarcados: {datos.Peso} kg
                  </Text>
                  <Text style={styles.Informacion}>
                    Unidad de Venta: {datos.UnidadVenta}
                  </Text>
                </View>
              </View>
            );
          }}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  containerPrincipal: {
    padding: 5,
    marginLeft: 10,
    width: "100%",
  },

  titulo2: {
    backgroundColor: "transparent",
    color: "#434346",
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(2.8) : responsiveFontSize(2.3),
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "stretch",
    paddingVertical: 10,
    backgroundColor: "#ffffff",
    marginBottom: 15,
    marginHorizontal: 15,
    paddingHorizontal: 5,
    borderRadius: 7,
    top: "2%",
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 2,
  },
  list: {
    marginTop: 5,
  },
  Informacion: {
    backgroundColor: "transparent",
    color: "#434346",
    marginTop: 0,
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(1.3) : responsiveFontSize(2),
  },
  Informacion1: {
    backgroundColor: "transparent",
    color: "#3483D8",
    marginTop: 0,
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(1.5) : responsiveFontSize(2),
  },
});
