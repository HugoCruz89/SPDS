import React, { Component } from "react";
import { Text, View, StyleSheet, RefreshControl, Platform } from "react-native";
import ListView from "deprecated-react-native-listview";
import { Actions } from "react-native-router-flux";
import { getDetalleEmbarque } from "../../LlamadasRest/MyHTTP";
import { responsiveFontSize } from "react-native-responsive-dimensions";
import Items from "../VerificacionEmbarque/DetalleEmbarquePedido";
import AsyncStorage from "@react-native-community/async-storage";
const ID_STG = "numeroSocio";
const URi_STG = "url";
const RUTA_STG = "ruta";
export default class ItemDetalleEmbarque extends Component {
  constructor(props) {
    super(props);
    this.getDatos();
    const ds = new ListView.DataSource({
      rowHasChanged: (r1, r2) => r1 !== r2,
    });
    const ds1 = new ListView.DataSource({
      rowHasChanged: (r1, r2) => r1 !== r2,
    });
    this.state = {
      dataSourceDetalleEmbarque: ds,
      dataSourceDetalleEmbarquePedido: ds1,
      rfc: "",
      refreshing: false,
      pedidos: [],
      url: "",
      idRuta: "",
    };
  }

  async getDatos() {
    let rfc = await AsyncStorage.getItem(ID_STG);
    let url = await AsyncStorage.getItem(URi_STG);
    let idRuta = await AsyncStorage.getItem(RUTA_STG);
    this.setState({
      rfc: rfc,
      url: url,
      idRuta: idRuta,
    });
  }

  _onRefresh() {
    this.setState({ refreshing: true });
    getDetalleEmbarque(this.state.rfc, this.state.idRuta).then((data) =>
      this.setState({
        dataSourceDetalleEmbarque: this.state.dataSourceDetalleEmbarque.cloneWithRows(
          data
        ),
        refreshing: false,
      })
    );
  }

  componentDidMount() {
    this.upDateDataSource(this.props.datos);
  }

  componentWillReceiveProps(newProps) {
    if (newProps.datos !== this.props.datos) {
      this.upDateDataSource(newProps.datos);
    }
  }
  upDateDataSource = (data) => {
    this.setState({
      dataSourceDetalleEmbarque: this.state.dataSourceDetalleEmbarque.cloneWithRows(
        data
      ),
    });
  };

  MostrarDetallePedidos(pedidos) {
    Actions.detalleClienteHome({ pedidos });
  }

  render() {
    return (
      <View style={{ flex: 1 }}>
        <ListView
          refreshControl={
            <RefreshControl
              refreshing={this.state.refreshing}
              onRefresh={this._onRefresh.bind(this)}
            />
          }
          style={styles.list}
          enableEmptySections
          dataSource={this.state.dataSourceDetalleEmbarque}
          renderRow={({ ...datos }) => {
            return (
              <View style={styles.row}>
                <View style={styles.containerPrincipal}>
                  <Text style={styles.titulo2}>
                    {datos.idCliente} - {datos.nombreCliente}
                  </Text>

                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      marginBottom: 2,
                    }}
                  >
                    <Text style={styles.Informacion}>
                      Total de Cajas Embarcadas:{" "}
                    </Text>
                    <Text style={styles.Informacion}>
                      {datos.totlaCSEmbarcadas}
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      marginBottom: 5,
                    }}
                  >
                    <Text style={styles.Informacion}>
                      Total de kg Embarcados:{" "}
                    </Text>
                    <Text style={styles.Informacion}>
                      {datos.totalKGEmbarcados} kg
                    </Text>
                  </View>
                  <View style={styles.containerDatos}>
                    <Items pedidos={datos.pedidos} />
                  </View>
                </View>
              </View>
            );
          }}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  containerIconos: {
    flexDirection: "column",
    alignItems: "center",
    backgroundColor: "#09467F",
    borderRadius: 50,
    width: 60,
    height: 60,
    padding: 10,
  },
  containerDatos: {
    width: "100%",
  },
  containerPrincipal: {
    padding: 5,
    marginLeft: 10,
    width: "93%",
    marginTop: 0,
    backgroundColor: "#ffffff",
  },
  titulo2: {
    backgroundColor: "transparent",
    color: "black",
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(2.8) : responsiveFontSize(2.3),
  },
  logo: {
    width: 50,
    height: 50,
    borderRadius: 50,
    marginTop: 10,
  },
  ColorTexto: {
    color: "#434346",
    fontSize: 24,
  },
  column: {
    flexDirection: "column",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 10,
    backgroundColor: "transparent",
    marginBottom: 5,
    marginHorizontal: 5,
    paddingHorizontal: 5,
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "stretch",
    paddingVertical: 0,
    backgroundColor: "#ffffff",
    marginBottom: 15,
    marginHorizontal: 15,
    paddingHorizontal: 5,
    borderRadius: 7,
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
  },
  list: {
    marginTop: 5,
  },
  Informacion: {
    backgroundColor: "transparent",
    color: "#434346",
    marginTop: 0,
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(1.3) : responsiveFontSize(1.9),
  },
});
