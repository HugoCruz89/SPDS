import React, { Component } from "react";
import { StyleSheet, View } from "react-native";
import { Actions } from "react-native-router-flux";
import HeaderContenido from "../Home/HeaderContenido";
import { getDetalleEmbarque } from "../../LlamadasRest/MyHTTP";
import ItemsApi from "../VerificacionEmbarque/ItemDetalleEmbarque";
import AsyncStorage from "@react-native-community/async-storage";
import { showLoading, hideLoading } from "react-native-notifyer";
const ID_STG = "numeroSocio";

const RUTA_STG = "ruta";
export default class DetalleEmbarque extends Component {
  constructor(props) {
    super(props);
    this.getDatos();
    this.state = {
      datos: [],
      pedidos: [],
    };
  }
  async getDatos() {
    showLoading();
    let idOperador = await AsyncStorage.getItem(ID_STG);

    let idRuta = await AsyncStorage.getItem(RUTA_STG);
    getDetalleEmbarque(idOperador, idRuta)
      .then((data) => this.setState({ datos: data }))
      .then((data) => {
        hideLoading();
      })
      .catch((error) => hideLoading());
  }

  componentWillReceiveProps(newProps) {
    if (newProps.datos !== this.props.datos) {
      this.upDateDataSource(newProps.datos);
    }
  }
  upDateDataSource = (data) => {
    this.setState({
      datos: data,
      // pedidos:data.pedidos
    });
  };

  home() {
    Actions.home();
  }
  llammaVistaAperturaClienteEntrega() {
    Actions.aperturaClienteEntrega();
  }

  render() {
    const datos = this.state.datos;

    return (
      <View style={{ flex: 1 }}>
        <HeaderContenido home={this.home.bind(this)} />

        <View style={styles.containerPrincipal}>
          <ItemsApi datos={datos} />
        </View>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  containerPrincipal: {
    flex: 2,
    backgroundColor: "#ffffff",
  },
});
