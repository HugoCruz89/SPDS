import React, { Component } from "react";
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  TouchableHighlight,
  Alert,
  Platform,
} from "react-native";
import AsyncStorage from "@react-native-community/async-storage";
import Icon from "react-native-vector-icons/FontAwesome";
import { Actions } from "react-native-router-flux";
import HeaderContenido from "../Home/HeaderDetallePedido";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import {
  responsiveHeight,
  responsiveFontSize,
} from "react-native-responsive-dimensions";

import { showLoading, hideLoading } from "react-native-notifyer";

const USR_STG = "numeroSocio";

const IDPLANTA_STG = "idplanta";
const RUTA_STG = "ruta";
const URi_STG = "url";
export default class EntregaCajas extends Component {
  constructor(props) {
    super(props);
    this.getDatos();
    this.state = {
      cajasDevueltas: "",
      tapasDevueltas: "",
      nombreCliente: "",
      idCliente: "",
      idRuta: "",
      idPlanta: "",
    };
  }

  async getDatos() {
    const rfc = await AsyncStorage.getItem(USR_STG);
    const idRuta = await AsyncStorage.getItem(RUTA_STG);
    const idPlanta = await AsyncStorage.getItem(IDPLANTA_STG);
    const url = await AsyncStorage.getItem(URi_STG);
    this.setState({
      rfc: rfc,
      idRuta: idRuta,
      idPlanta: idPlanta,
      url: url,
    });
  }

  componentWillMount() {
    const IdCliente = this.props.idCliente;
    const nombreCliente = this.props.nombreCliente;
    this.setState({
      idCliente: IdCliente,
      nombreCliente: nombreCliente,
    });
  }

  onChangeCajasDevueltas(cajasDevueltas) {
    this.setState({ cajasDevueltas });
  }
  onChangeTapasDevueltas(tapasDevueltas) {
    this.setState({ tapasDevueltas });
  }

  home() {
    Actions.recuperacionCajas();
  }

  GrabarDatos() {
    showLoading();
    const url = this.state.url;

    fetch(url + "CajasTapas/", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        idCliente: this.state.idCliente,
        idRuta: this.state.idRuta,
        idPlanta: this.state.idPlanta,
        cajas: this.state.cajasDevueltas,
        tapas: this.state.tapasDevueltas,
      }),
    })
      .then(function (response) {
        if (response.ok) {
          hideLoading();
          Actions.home();
          Alert.alert(
            "Se ha guardado la información con éxito",
            "Se han enviado los datos correctamente ",
            [{ text: "OK", onPress: () => {} }],
            { cancelable: false }
          );
        } else {
          hideLoading();
          Alert.alert(
            "Algo salio mal!",
            "Error:" + response.status,
            [{ text: "OK", onPress: () => {} }],
            { cancelable: false }
          );
          const error = new Error(response.statusText);
          error.response = response;
          throw error;
        }
      })
      .catch((error) => {});
  }

  render() {
    const save = <Icon name="save" size={20} color="white" />;

    return (
      <View style={{ flex: 1 }}>
        <HeaderContenido home={this.home.bind(this)} />
        <View style={styles.containerPrincipal}>
          <View style={styles.textoContainerTitulo}>
            <Text style={styles.titulo1}>Recuperación de Cajas</Text>
            <Text style={styles.titulo1}>
              Cliente : {this.state.nombreCliente}
            </Text>
          </View>
          <View style={styles.containerInpput}>
            <KeyboardAwareScrollView>
              <View style={styles.modalContent}>
                <View style={styles.divCajasTapas}>
                  <Text style={styles.titulo3}>
                    Devolución de Plástico Vacío
                  </Text>
                  <View style={{ flexDirection: "row", marginLeft: "2%" }}>
                    <View
                      style={{
                        flexDirection: "row",
                        justifyContent: "space-between",
                        width: "45%",
                        marginRight: "3%",
                      }}
                    >
                      <Text style={styles.titulo2}>Cajas{"\n"}Vacías</Text>
                      <TextInput
                        keyboardType="numeric"
                        returnKeyType="next"
                        value={this.state.cajasDevueltas}
                        underlineColorAndroid="transparent"
                        placeholderTextColor="rgba(10,10,10,0.5)"
                        style={styles.inputCajasTapas}
                        onChangeText={(cajasDevueltas) =>
                          this.onChangeCajasDevueltas(cajasDevueltas)
                        }
                      />
                    </View>
                    <View
                      style={{
                        flexDirection: "row",
                        justifyContent: "space-between",
                        width: "45%",
                      }}
                    >
                      <Text style={styles.titulo2}>Tapas{"\n"}</Text>
                      <TextInput
                        keyboardType="numeric"
                        returnKeyType="next"
                        value={this.state.tapasDevueltas}
                        underlineColorAndroid="transparent"
                        placeholderTextColor="rgba(10,10,10,0.5)"
                        style={styles.inputCajasTapas}
                        onChangeText={(tapasDevueltas) =>
                          this.onChangeTapasDevueltas(tapasDevueltas)
                        }
                      />
                    </View>
                  </View>
                </View>

                <TouchableHighlight
                  style={styles.button2}
                  onPress={() => this.GrabarDatos()}
                >
                  <Text style={styles.buttonText}>
                    {save} Recuperar Cajas y Tapas
                  </Text>
                </TouchableHighlight>
              </View>
            </KeyboardAwareScrollView>
          </View>
        </View>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  titulo3: {
    textAlign: "center",
    backgroundColor: "transparent",
    color: "#434346",
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(2) : responsiveFontSize(1.7),
  },
  divCajasTapas: {
    flexDirection: "column",
    justifyContent: "space-between",
    width: "100%",
    borderColor: "#ddd",
    borderWidth: 0.5,
    padding: 5,
    borderRadius: 5,

    borderBottomWidth: 0,
    shadowColor: "#3483D8",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 2,
  },

  titulo1: {
    backgroundColor: "transparent",
    color: "black",
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(2) : responsiveFontSize(2.2),
  },
  titulo2: {
    backgroundColor: "transparent",
    color: "#434346",
    fontSize:
      Platform.OS === "ios" ? responsiveFontSize(2) : responsiveFontSize(1.7),
  },

  textoContainerTitulo: {
    position: "absolute",
    alignItems: "center",
    width: "90%",
    height: "100%",
    top: "2.5%",
    textAlign: "center",
    marginHorizontal: "7%",
  },
  containerPrincipal: {
    flex: 2,
    backgroundColor: "#fcfcff",
  },

  modalContent: {
    backgroundColor: "transparent",
    padding: 20,
    height: responsiveHeight(70),
  },

  input: {
    marginBottom: 15,
    height: 35,
    borderWidth: 1,
    borderRadius: 5,
    width: "70%",
    backgroundColor: "#ffffff",
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,

    padding: 0,
    paddingLeft: 7,
  },
  inputKgTemperatura: {
    marginBottom: 15,
    height: 35,
    borderWidth: 1,
    borderRadius: 5,
    backgroundColor: "#ffffff",
    width: "65%",
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
    padding: 0,
    paddingLeft: 7,
  },
  inputCajasTapas: {
    marginBottom: 15,
    height: 35,
    borderWidth: 1,
    borderRadius: 5,
    backgroundColor: "#ffffff",
    width: "50%",
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,

    padding: 0,
    paddingLeft: 7,
  },
  icono: {
    marginBottom: "3%",
  },
  button: {
    backgroundColor: "#3483D8",
    paddingTop: 15,
    paddingBottom: 15,
    marginTop: 5,
    borderRadius: 5,
    top: "3%",
    marginBottom: "3%",
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
  },
  button2: {
    backgroundColor: "#0BA803",
    paddingTop: 15,
    paddingBottom: 15,
    marginTop: 5,
    borderRadius: 5,
    top: "3%",
    marginBottom: "3%",

    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
  },
  buttonText: {
    textAlign: "center",
    color: "#fff",
  },

  containerInpput: {
    position: "absolute",
    width: "95%",
    height: "80%",
    top: "15%",
    marginLeft: "2.5%",
    backgroundColor: "#ffffff",
    borderRadius: 25,

    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
  },
});
