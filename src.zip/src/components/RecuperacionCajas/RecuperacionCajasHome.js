import React, {Component} from 'react';
import {StyleSheet, View, AsyncStorage} 
from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import {Actions} from 'react-native-router-flux'
import HeaderContenido from '../Home/HeaderContenido'
import {getClientesCajas} from '../../LlamadasRest/MyHTTP'
import ItemsApi from '../RecuperacionCajas/ItemsClientesCajasApi'
import {showLoading,hideLoading} from 'react-native-notifyer'
const IDPLANTA_STG='idplanta'
const RUTA_STG='ruta'

export default class RecuperacionCajasHome extends Component{

constructor(props) {
        super(props); 
        this.getDatos()
        this.state = {       
        datos:[],
        }; 
    }  
 async getDatos()
    {
      showLoading()
      let idRuta=await AsyncStorage.getItem(RUTA_STG);   
       let idPlanta=await AsyncStorage.getItem(IDPLANTA_STG);         
      getClientesCajas(idRuta,idPlanta)
     .then((data)=>this.setState({ datos: data }))
     .then((data)=> hideLoading())
     .catch((error)=>hideLoading())
    }

     componentWillReceiveProps(newProps){    
        if(newProps.datos !== this.props.datos){
             this.upDateDataSource(newProps.datos)
            } 
       }
    upDateDataSource = data =>{
          this.setState({
          datos: data 
      })
       }

  home(){
  Actions.home()
}
	render(){
    const datos= this.state.datos
  

  const deleteRow = (           
              <Icon
                name="trash"
                size={20}
                color="white"                                   
              />
              ) 
		return(
     
			<View style={{flex: 1,}}>
				<HeaderContenido  home={this.home.bind(this)} />   

        <View style={styles.containerPrincipal}>                
        <ItemsApi 
            datos={datos}
            />
        </View>     
			</View>
		
		);
	}
}
const styles = StyleSheet.create({

  containerPrincipal:
  {
    flex: 2,
    backgroundColor: '#fcfcff',
  },
  
});