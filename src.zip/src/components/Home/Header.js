import React from 'react'
import {Text,View,StyleSheet, Image,TouchableOpacity,Platform} from 'react-native'

import Icon from 'react-native-vector-icons/FontAwesome'
import { responsiveHeight, responsiveWidth, responsiveFontSize } from 'react-native-responsive-dimensions';
import { ifIphoneX } from 'react-native-iphone-x-helper'

const ID_STG='numeroSocio'
const IDPLANTA_STG='idplanta'
const RUTA_STG='ruta'
const URi_STG='url'

const Header=props =>(
	<View style={styles.container}>
		<TouchableOpacity onPress={()=>props.toggle()}>
			<View style={{width: 30}}>
				<Icon
			 name="bars" 
			 color="#3483D8" 
			 size={25}
			  />
			</View>			
		</TouchableOpacity>
		<Image style={styles.logo} source={require('../../images/logo.png')} />
		 {props.datos.length==0?
		<View style={styles.notificacion}>
		 <TouchableOpacity onPress={()=>null}>
			<Icon name="bell-o" color='#3483D8' size={25}/>
			</TouchableOpacity>		
		</View>
         :<View style={styles.notificacion}>
		 <TouchableOpacity onPress={()=>props.alertaFolios()}>
			<Icon name="bell-o" color='red' size={25}/>
			</TouchableOpacity>
		<Text style={styles.textoNotificaciones}>{props.datos.length}</Text>	
			
		</View>}

		
	</View>
)

const styles= StyleSheet.create({
	 notificacion:{
       flexDirection: 'row',
       width: '10%' 
	 },
    textoNotificaciones:{
    	color: 'red'
    },

	container:{
		flexDirection: 'row',
		...ifIphoneX({
            height:Platform.OS === 'ios' ? responsiveHeight(9):responsiveHeight(7),
            paddingTop: 40,
        }, {
            height:Platform.OS === 'ios' ? responsiveHeight(7):responsiveHeight(7),
            top: Platform.OS === 'ios' ? 0: 0,
            paddingTop: Platform.OS === 'ios' ? 20: 0,
        }),
		alignItems:  'center',
		justifyContent:  'space-between',
		backgroundColor: 'white',
		paddingHorizontal: 20,

		 borderColor: '#ddd',
		  borderBottomWidth: 0,
		  shadowColor: '#000',
		  shadowOffset: {width: 0, height: 2},
		  shadowOpacity: 0.8,
		  shadowRadius: 2,
		  elevation: 2,
		
	},
	logo:{
		
		width: 45,
		height: 39
	}


})

export default Header