import React, { Component } from "react";
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Alert,
  PermissionsAndroid,
} from "react-native";
import AsyncStorage from "@react-native-community/async-storage";
import { Actions } from "react-native-router-flux";
import SideMenu from "react-native-side-menu";
import Menu from "./Menu";
import Header from "./Header";
import Icon from "react-native-vector-icons/FontAwesome";
import Icon2 from "react-native-vector-icons/MaterialIcons";
import NetInfo from "@react-native-community/netinfo";
import { hideLoading } from "react-native-notifyer";
import { responsiveFontSize } from "react-native-responsive-dimensions";
import { getClientesCajas } from "../../LlamadasRest/MyHTTP";

const IDPLANTA_STG = "idplanta";
const RUTA_STG = "ruta";
const ID_STG = "numeroSocio";
const URi_STG = "url";

export default class Home extends Component<{}> {
  constructor(props) {
    super(props);
    // this.requestSMSPermission()
    this.requestGPS();
    this.getDatos();
    this.checarRed();
    this.state = {
      isOpen: false,
      idOperador: "",
      idRuta: "",
      idPlanta: "",
      url: "",
      datos: [],
    };
  }

  async requestGPS() {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        {
          title: "Cool Photo App Camera Permission",
          message:
            "Cool Photo App needs access to your camera " +
            "so you can take awesome pictures.",
          buttonNeutral: "Ask Me Later",
          buttonNegative: "Cancel",
          buttonPositive: "OK",
        }
      );
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
      } else {
      }
    } catch (err) {}
  }

  checarRed() {
    NetInfo.fetch().then((connectionInfo) => {
      if (connectionInfo.type != "none") {
        this.getCajas();
      } else {
        this.setState({ datos: [] });
        Alert.alert(
          "¡Upsss...!",
          "Parece que no tienes conexión a internet",
          [{ text: "OK", onPress: () => {} }],
          { cancelable: false }
        );
      }
    });
  }

  async getCajas() {
    let idRuta = await AsyncStorage.getItem(RUTA_STG);
    let idPlanta = await AsyncStorage.getItem(IDPLANTA_STG);
    getClientesCajas(idRuta, idPlanta)
      .then((data) => this.setState({ datos: data }))
      .then((data) => hideLoading())
      .catch((error) => hideLoading());
  }

  async getDatos() {
    NetInfo.getConnectionInfo().then((connectionInfo) => {});
    let idOperador = await AsyncStorage.getItem(ID_STG);
    let idRuta = await AsyncStorage.getItem(RUTA_STG);
    let idPlanta = await AsyncStorage.getItem(IDPLANTA_STG);
    let url = await AsyncStorage.getItem(URi_STG);
    this.setState({
      idOperador: idOperador,
      idRuta: idRuta,
      idPlanta: idPlanta,
      url: url,
    });
  }

  alertaFolios() {
    Alert.alert(
      "Recuperación de Cajas",
      "Tienes clientes para recuperar cajas",
      [{ text: "OK", onPress: () => {} }],
      { cancelable: false }
    );
  }

  home() {
    Actions.home();
  }

  toggle() {
    this.setState({
      isOpen: !this.state.isOpen,
    });
  }

  updateMenu(isOpen) {
    this.setState({ isOpen });
  }

  llamaAperturaClienteHome() {
    Actions.aperturaClienteHome();
  }

  llamaVerificacionEmbarqueHome() {
    Actions.verficiacionEmbarqueHome();
  }

  llamaVistaRecuperacionCajas() {
    Actions.recuperacionCajas();
  }

  llamaVistaRecuperacionFolios() {
    Actions.recuperacionFoliosHome();
  }
  llamaVistaInicioRuta() {
    Actions.inicioRuta();
  }
  llamaVistaFinRuta() {
    Actions.finRuta();
  }

  render() {
    return (
      <View style={{ flex: 1 }}>
        <SideMenu
          menu={<Menu />}
          isOpen={this.state.isOpen}
          onChange={(isOpen) => this.updateMenu(isOpen)}
          style={{ flex: 1 }}
        >
          <Header
            navigation={this.props.navigation}
            toggle={this.toggle.bind(this)}
            alertaFolios={this.alertaFolios.bind(this)}
            datos={this.state.datos}
          />
          <View style={styles.containerPrincipal}>
            <View
              style={{
                flexDirection: "row",
                height: "28%",
                marginBottom: "5%",
              }}
            >
              <View style={styles.containerDiv}>
                <View style={styles.textoContainer}>
                  <View style={styles.row}>
                    <TouchableOpacity
                      onPress={() => this.llamaVistaInicioRuta()}
                    >
                      <Icon2
                        name="system-update"
                        color="#3483D8"
                        size={60}
                        style={styles.avatar2}
                      />
                      <Text style={styles.title}>Inicio{"\n"}Ruta</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
              <View style={styles.containerDiv}>
                <View style={styles.textoContainer}>
                  <View style={styles.row}>
                    <TouchableOpacity
                      onPress={() => this.llamaVerificacionEmbarqueHome()}
                    >
                      <Icon
                        name="truck"
                        color="#3483D8"
                        size={60}
                        style={styles.avatar}
                      />
                      <Text style={styles.title}>
                        Verificación {"\n"}Embarque
                      </Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            </View>
            <View
              style={{
                flexDirection: "row",
                height: "28%",
                marginBottom: "5%",
              }}
            >
              <View style={styles.containerDiv}>
                <View style={styles.textoContainer}>
                  <View style={styles.row}>
                    <TouchableOpacity
                      onPress={() => this.llamaAperturaClienteHome()}
                    >
                      <Icon
                        name="address-card"
                        color="#3483D8"
                        size={60}
                        style={styles.avatar}
                      />
                      <Text style={styles.title}>Entrega{"\n"}Cliente</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>

              <View style={styles.containerDiv}>
                <View style={styles.textoContainer}>
                  <View style={styles.row}>
                    <TouchableOpacity
                      onPress={() => this.llamaVistaRecuperacionFolios()}
                    >
                      <Icon
                        name="folder-open-o"
                        color="#3483D8"
                        size={60}
                        style={styles.avatar}
                      />
                      <Text style={styles.title}>
                        Recuperación {"\n"}Folios
                      </Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            </View>
            <View
              style={{
                flexDirection: "row",
                height: "28%",
                marginBottom: "5%",
              }}
            >
              <View style={styles.containerDiv}>
                <View style={styles.textoContainer}>
                  <View style={styles.row}>
                    <TouchableOpacity
                      onPress={() => this.llamaVistaRecuperacionCajas()}
                    >
                      <Icon
                        name="archive"
                        color="#3483D8"
                        size={60}
                        style={styles.avatar}
                      />
                      <Text style={styles.title}>Recuperación{"\n"}Cajas</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
              <View style={styles.containerDiv}>
                <View style={styles.textoContainer}>
                  <View style={styles.row}>
                    <TouchableOpacity onPress={() => this.llamaVistaFinRuta()}>
                      <Icon2
                        name="system-update"
                        color="#3483D8"
                        size={60}
                        style={styles.avatar}
                      />
                      <Text style={styles.title}>Finalizar {"\n"}Ruta</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            </View>
          </View>
        </SideMenu>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  containerPrincipal: {
    flex: 2,
    backgroundColor: "#fcfcff",
  },
  containerDiv: {
    flex: 2,
  },
  containerDiv2: {
    flex: 2,
  },
  title: {
    backgroundColor: "transparent",
    color: "#434346",
    fontSize: responsiveFontSize(2),
    padding: 10,
    textAlign: "center",
  },
  textoContainer: {
    position: "absolute",
    alignItems: "center",
    width: "100%",
    height: "100%",
    padding: "15%",
  },
  avatar: {
    width: 70,
    height: 70,
    marginTop: "2%",
    marginLeft: "15%",
  },
  avatar2: {
    width: 70,
    height: 70,
    marginTop: "2%",
    transform: [{ rotate: "180deg" }],
  },
  row: {
    flexDirection: "column",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: "#ffffff",
    borderRadius: 20,
    paddingHorizontal: 5,
    paddingVertical: "5%",
    width: "120%",
    height: "140%",
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 2,
  },
  row2: {
    paddingVertical: "5%",
    flexDirection: "column",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: "#ffffff",
    borderRadius: 20,
    borderWidth: 1,
    width: "60%",
    height: "140%",
    marginTop: "-15%",
    borderColor: "#ddd",
    borderBottomWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
  },
});
