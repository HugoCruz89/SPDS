import React, { Component } from "react";
import {
  StyleSheet,
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Alert,
} from "react-native";
import AsyncStorage from "@react-native-community/async-storage";
import { Actions } from "react-native-router-flux";
import Icon from "react-native-vector-icons/FontAwesome";
import Icon3 from "react-native-vector-icons/MaterialIcons";
import Icon2 from "react-native-vector-icons/Ionicons";
import VersionNumber from "react-native-version-number";

import {
  responsiveWidth,
  responsiveFontSize,
} from "react-native-responsive-dimensions";

const RFC_STG = "RFC";
const NOMBRE_STG = "nombre";
const PATERNO_STG = "apPat";
const MATERNO_STG = "apMat";
const ID_STG = "numeroSocio";
const ROL_STG = "rol";
const RUTA_STG = "ruta";
const TELEFONO_STG = "telefono";
const PLANTA_STG = "planta";
const IDPLANTA_STG = "idplanta";
const URi_STG = "url";
const VEHICULO_STG = "vehiculo";
const SESSION_KEY = "__SESSION_TIMER__";
export default class Menu extends Component {
  constructor(props) {
    super(props);
    this.getDatos();
    this.state = {
      NombreUsuario: "Operador",
      ruta: "default",
      planta: "default",
      idOperador: "",
      vehiculo: "",
    };
  }

  async getDatos() {
    let nombre = await AsyncStorage.getItem(NOMBRE_STG);
    let ruta = await AsyncStorage.getItem(RUTA_STG);
    let planta = await AsyncStorage.getItem(PLANTA_STG);
    let idOperador = await AsyncStorage.getItem(RFC_STG);
    let vehiculo = await AsyncStorage.getItem(VEHICULO_STG);

    this.state.NombreUsuario = nombre;
    this.state.ruta = ruta;
    this.state.planta = planta;
    this.state.idOperador = idOperador;
    this.state.vehiculo = vehiculo;
  }
  async logout() {
    await AsyncStorage.removeItem(RFC_STG);
    await AsyncStorage.removeItem(URi_STG);
    await AsyncStorage.removeItem(NOMBRE_STG);
    await AsyncStorage.removeItem(PATERNO_STG);
    await AsyncStorage.removeItem(MATERNO_STG);
    await AsyncStorage.removeItem(ID_STG);
    await AsyncStorage.removeItem(ROL_STG);
    await AsyncStorage.removeItem(RUTA_STG);
    await AsyncStorage.removeItem(TELEFONO_STG);
    await AsyncStorage.removeItem(PLANTA_STG);
    await AsyncStorage.removeItem(IDPLANTA_STG);
    await AsyncStorage.removeItem(SESSION_KEY);
    Actions.login();
  }

  informacionSistema() {
    const versionTelefono = VersionNumber.appVersion;

    Alert.alert(
      "Sistema Portatil de Ventas",
      "Version " + versionTelefono,
      [{ text: "OK", onPress: () => {} }],
      { cancelable: false }
    );
  }

  llamaVistaAperturaCliente() {
    Actions.aperturaClienteHome();
  }
  llamaVistaEmbarque() {
    Actions.verficiacionEmbarqueHome();
  }

  llamaVistaRecuperacionFolios() {
    Actions.recuperacionFoliosHome();
  }

  llamaVistaRecuperacionCajas() {
    Actions.recuperacionCajas();
  }

  render() {
    return (
      <View style={styles.menu}>
        <View style={styles.avatarContainer}>
          <View
            style={{
              flexDirection: "column",
              alignItems: "flex-start",
              marginTop: -5,
            }}
          >
            <View style={styles.avatarImage2}>
              <Icon3
                name="place"
                color="#3483D8"
                size={25}
                style={styles.avatar}
              />
              <Text style={styles.text}>CEDIS: {this.state.planta}</Text>
            </View>
            <View style={styles.avatarImage2}>
              <Icon2
                name="ios-key"
                color="#3483D8"
                size={25}
                style={styles.avatar}
              />
              <Text style={styles.text}>Operador: {this.state.idOperador}</Text>
            </View>
            <View style={styles.avatarImage2}>
              <Icon
                name="user-o"
                color="#3483D8"
                size={25}
                style={styles.avatar}
              />
              <Text style={styles.text}>{this.state.NombreUsuario}</Text>
            </View>
            <View style={styles.avatarImage2}>
              <Icon2
                name="ios-git-pull-request"
                color="#3483D8"
                size={30}
                style={styles.avatar}
              />
              <Text style={styles.text}>Ruta: {this.state.ruta}</Text>
            </View>
            <View style={styles.avatarImage2}>
              <Icon3
                name="directions-car"
                color="#3483D8"
                size={30}
                style={styles.avatar}
              />
              <Text style={styles.text}>Vehiculo: {this.state.vehiculo}</Text>
            </View>
          </View>
        </View>

        <TouchableOpacity
          onPress={() => this.llamaVistaEmbarque()}
          style={styles.avatarContainer}
        >
          <View style={styles.avatarImage}>
            <Text style={styles.text}>Verificación Embarque</Text>
          </View>
          <Icon name="truck" color="#3483D8" size={25} />
        </TouchableOpacity>
        <TouchableOpacity
          onPress={this.llamaVistaAperturaCliente}
          style={styles.avatarContainer}
        >
          <View style={styles.avatarImage}>
            <Text style={styles.text}>Entrega Cliente</Text>
          </View>
          <Icon name="address-card" color="#3483D8" size={25} />
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => this.llamaVistaRecuperacionFolios()}
          style={styles.avatarContainer}
        >
          <View style={styles.avatarImage}>
            <Text style={styles.text}>Recuperación Folios</Text>
          </View>
          <Icon name="folder-open-o" color="#3483D8" size={25} />
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => this.llamaVistaRecuperacionCajas()}
          style={styles.avatarContainer}
        >
          <View style={styles.avatarImage}>
            <Text style={styles.text}>Recuperación Cajas</Text>
          </View>
          <Icon name="archive" color="#3483D8" size={25} />
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => this.logout()}
          style={styles.avatarContainer}
        >
          <View style={styles.avatarImage}>
            <Text style={styles.text}>Salir</Text>
          </View>
          <Icon name="sign-out" color="#3483D8" size={25} />
        </TouchableOpacity>
        <TouchableOpacity
          onPress={this.informacionSistema}
          style={styles.avatarContainer}
        >
          <View style={styles.avatarImage}>
            <Text style={styles.text}>Información del Sistema</Text>
          </View>
          <Icon name="exclamation-circle" color="#3483D8" size={25} />
        </TouchableOpacity>

        <ScrollView style={styles.scrollContainer}></ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  menu: {
    flex: 1,
    backgroundColor: "white",
    //	width: width,
    //	height:'20%',
    //	backgroundColor:'yellow',
  },
  avatarContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    width: responsiveWidth(100) / 2 + 50,
    borderColor: "#fff",
    borderBottomWidth: 3,
    paddingHorizontal: "5%",
    paddingVertical: "4%",
    top: "2%",
  },
  avatar: {
    width: 30,
    height: 30,
    margin: 10,
  },
  avatarImage: {
    flexDirection: "row",
    alignItems: "center",
  },
  avatarImage2: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: "-2%",
  },
  text: {
    fontSize: responsiveFontSize(1.8),
    color: "#3483D8",
  },
});
