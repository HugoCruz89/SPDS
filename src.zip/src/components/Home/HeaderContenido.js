import React from 'react'
import {View,StyleSheet,TouchableOpacity, Image,Platform} from 'react-native'

import Icon from 'react-native-vector-icons/FontAwesome'
import { responsiveHeight, responsiveWidth, responsiveFontSize } from 'react-native-responsive-dimensions';
import { ifIphoneX } from 'react-native-iphone-x-helper'
const Header=props =>(
	
	<View style={styles.container}>
		<TouchableOpacity style={{width: 35}}  onPress={()=>props.home()}>
			<View style={{}}>
			  <Icon
			   name="chevron-left" 
			   color="#3483D8"
			   size={25} />
			</View>

		</TouchableOpacity>
		<Image style={styles.logo} source={require('../../images/logo.png')} />

		<Icon name="search" color='white' size={0}/>
	</View>
)

const styles= StyleSheet.create({
	container:{
		flexDirection: 'row',
		...ifIphoneX({
            height:Platform.OS === 'ios' ? responsiveHeight(9):responsiveHeight(7),
            paddingTop: 40,
        }, {
            height:Platform.OS === 'ios' ? responsiveHeight(7):responsiveHeight(7),
            top: Platform.OS === 'ios' ? 0: 0,
            paddingTop: Platform.OS === 'ios' ? 20: 0,
        }),
		alignItems:  'center',
		justifyContent:  'space-between',
		backgroundColor: 'white',
		paddingHorizontal: 20,
		top: Platform.OS === 'ios' ? 0: 0,

		borderColor: '#ddd',
		  borderBottomWidth: 0,
		  shadowColor: '#000',
		  shadowOffset: {width: 0, height: 2},
		  shadowOpacity: 0.8,
		  shadowRadius: 2,
		  elevation: 2,
	},
	logo:{
		marginRight:35,
		//width: 140,
			width: 45,
		height: 39
	}


})

export default Header