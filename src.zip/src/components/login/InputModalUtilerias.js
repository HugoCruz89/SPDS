import React,{Component} from 'react';
import {Text,View,StyleSheet,TextInput,TouchableHighlight,Picker,ScrollView,Platform
} from 'react-native';
import { responsiveHeight, responsiveWidth, responsiveFontSize } from 'react-native-responsive-dimensions';
import Modal from 'react-native-modal'
import Icon from 'react-native-vector-icons/FontAwesome';

import AsyncStorage from '@react-native-community/async-storage';
const URi_STG='url'
export default class InputModalUtilerias extends Component {

constructor(props) {
        super(props); 
     //   this.getUrl()
        this.state = { 
         catalogo:[],
         url:''
        }; 
    } 

async getUrl(){
	let url=await AsyncStorage.getItem(URi_STG);
	
	
} 

componentWillMount(){
	
		this.getUrl()
}



render(){

 const cambiarServidor = (           
              <Icon
                name="map-signs"
                size={25}
                color="white"
                marginRight= '5%' 
              />
              ) 
const closeModal = (
  <Icon
              name="chevron-down"
              size={20}
              color="white"
            />
  )
const usuario = (
 
    <View style={{flexDirection: 'row',justifyContent:  'center'   ,width: '100%',marginRight: '3%', marginTop: 5 }}>
        <Icon 
            name="user-o"
            color="white"
            size={25}
            style={styles.avatar}
            />
        <TextInput style={styles.input}
            value={this.state.userServidor}
            onChangeText={(userServidor)=>this.props.onChangeUsrServidor(userServidor)}
            underlineColorAndroid="transparent"           
            secureTextEntry
            returnKeyType="next"         
            placeholderTextColor="white"/> 
    </View>

  )
const pass = (
     <View style={{flexDirection: 'row',justifyContent:   'center' ,width: '100%',marginRight: '3%',marginTop: 5}}>
        <Icon 
            name="key"
            color="white"
            size={25}
            style={styles.avatar}
            />
        <TextInput style={styles.input}
            value={this.state.passServidor}
            onChangeText={(passServidor)=>this.props.onChangePassServidor(passServidor)}
            underlineColorAndroid="transparent"         
            secureTextEntry
            returnKeyType="go"
            //ref={(input)=>this.passwordInput=input}
            placeholderTextColor="white"/>
            <Text style={styles.errorLabel}>
               {this.props.mensajeInputServidor}
            </Text>    
     </View>
                          

  )


	return(
      <View style={styles.container}>
	     <Modal 
        style={styles.modalTop} 
        isVisible={this.props.isVisible2} 
	     	animationIn={'slideInUp'}
	     	animationOut={'slideOutDown'}	
        backdropColor={'black'}   
        backdropOpacity={.3}  
        animationInTiming={1500}
        animationOutTiming={1500}
	     >
	     	<View style={styles.modalContent}>
	     		 <TouchableHighlight style={{width: '35%'}} onPress={this.props.onCloseModal2}>
	     		 {closeModal}
	     		 </TouchableHighlight>                     
                     {usuario}
                     {pass}
                   		        	
		      	 <TouchableHighlight
			       style={styles.button}
			       onPress= {this.props.ingresarVistaConfiguracion}
			       >
			       <Text style={styles.buttonText}>{cambiarServidor}  Configurar Servidor</Text>
			       </TouchableHighlight>
	     	</View>
	     	
	     </Modal>

      </View>

      
		  );
      }	
}

const styles = StyleSheet.create({
	 
errorLabel:{
    color: '#FF0000',
    marginBottom: 15,
    textAlign: 'center',
    fontWeight:  '900',
    backgroundColor: 'transparent'
  },
   avatar:{
      width: 25,
      height: 25,   
    
    },
  input:{   
    height: 40,
    width: '70%',
    backgroundColor: 'rgba(255,255,255,0.8)',
    marginBottom: 20,
    color: '#000',
    paddingHorizontal: 15,
    paddingVertical: 10,
    borderRadius: 8,
    marginLeft: '2%'
  },

  modalTop:{
	justifyContent: 'flex-start',
	marginTop: 50, 
	backgroundColor: 'transparent',
	},

	modalContent:{
		backgroundColor: '#3483D8',
		padding: 20,
		borderRadius: 9
	},
	

	button:{
	//	backgroundColor: '#09467F',
	backgroundColor: '#0BA803',
		paddingTop: 15,
		paddingBottom: 15,
		marginTop: 5,
		borderRadius: 9,
    width: '80%',
    marginLeft: '9%',
	},
	buttonText:{
		textAlign:  'center',
		color:'white'
	},
container:{
  width: '100%',
		//textAlign:  'center',
		color:'white'
	},
	titulo2:{
    backgroundColor: 'transparent',
    color: 'white',
    fontSize: Platform.OS === 'ios' ? responsiveFontSize(2): responsiveFontSize(1.7),
  },
    inputCajasTapas:{
    marginBottom: 15,
    height: 35,   
    borderWidth: 1,
    borderRadius: 5,
    backgroundColor: '#ffffff',
    width: '50%',
    borderColor: '#ddd',
    borderBottomWidth: 0,
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 2},
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
     padding: 0,
    paddingLeft: 7,
  },
	})