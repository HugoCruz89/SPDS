import React, { Component } from "react";
import {
  StyleSheet,
  View,
  TextInput,
  TouchableOpacity,
  Text,
  Alert,
  TouchableWithoutFeedback,
  TouchableHighlight,
} from "react-native";
import Icon from "react-native-vector-icons/FontAwesome";
import Icon2 from "react-native-vector-icons/MaterialIcons";
import { Actions } from "react-native-router-flux";
import {
  responsiveHeight,
  responsiveFontSize,
} from "react-native-responsive-dimensions";
import {
  getDatosLogin,
  getVersionCurrent,
  postGenerico,
} from "../../LlamadasRest/MyHTTP";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import { showLoading, hideLoading } from "react-native-notifyer";
import NetInfo from "@react-native-community/netinfo";
import DeviceInfo from "react-native-device-info";
import VersionNumber from "react-native-version-number";
import Input2 from "../login/InputModalUtilerias";

import { SetUrlPro } from "../Utilidades/UrlUtility";
import {
  almacenaDatos,
  IsLogining,
  LeerImei,
  ValidarNumeroIMEI,
} from "../Utilidades/Utilerias";

export default class LoginForm extends Component {
  constructor(props) {
    super(props);
    //this.getNombre()
    this.ValidoVersion();
    this.checarRed();

    this.state = {
      usuario: "",
      datos: [],
      mensaje: "",
      url: "",
      isVisible2: false,
      userServidor: "",
      passServidor: "",
      mensajeInputServidor: "",
      isVisibleVersion: true,
      version: "",
    };
    this.handleModalShow2 = this.handleModalShow2.bind(this);
    this.handleModalHide2 = this.handleModalHide2.bind(this);
    this.onChangeUsrServidor = this.onChangeUsrServidor.bind(this);
    this.onChangePassServidor = this.onChangePassServidor.bind(this);
    this.ingresarVistaConfiguracion = this.ingresarVistaConfiguracion.bind(
      this
    );
  }
  //////////////////////////////////////////////////////////////////////////////////////////
  ///////////////----metodos para el modal de acceso al servidor----//////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////////
  onChangeUsrServidor(userServidor) {
    this.setState({ userServidor });
  }
  onChangePassServidor(passServidor) {
    this.setState({ passServidor });
  }

  handleModalShow2() {
    this.setState({
      isVisible2: true,
    });
  }

  handleModalHide2() {
    this.setState({
      isVisible2: false,
      mensajeInputServidor: "",
    });
  }

  ingresarVistaConfiguracion() {
    if (
      this.state.userServidor == "spdsadmin" &&
      this.state.passServidor == "123456"
    ) {
      // if (this.state.userServidor == "123" && this.state.passServidor == "123") {
      this.handleModalHide2();
      this.llamaVistaUtilerias();
    } else {
      Alert.alert(
        "¡Usuario o contraseña incorrecta!",
        "Para acceder a esta vista debes de solicitar las credenciales a soporte o al administrador",
        [{ text: "OK", onPress: () => {} }],
        { cancelable: false }
      );
      this.setState({
        mensajeInputServidor: "Usuario o contraseña incorrecta",
      });
    }
  }
  //////////////////////////////////////////////////////////////////////////////////////////
  ///////////////----fin de metodos para el modal de acceso al servidor----//////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////////
  async almacenaUsuario(datos) {
    if (datos != null) {
      if (!datos.lineaPermitida) {
        hideLoading();
        this.setState({
          mensaje: "¡Dispositivo NO Permitido!",
        });
        return;
      }
      const a = JSON.stringify(datos);
      const b = JSON.parse(a);
      if (b.Message != null) {
        hideLoading();
        this.setState({
          mensaje: "Servidor Incorrecto",
        });
      } else {
        if (datos.NumeroDePedidos > 0) {
          hideLoading();
          almacenaDatos(datos);
        } else {
          hideLoading();
          this.setState({
            mensaje: "Operador sin Clientes",
          });
        }
      }
    } else {
      hideLoading();
      this.setState({
        mensaje: "Usuario o contraseña incorrecta",
      });
    }
  }

  ValidoVersion() {
    // verifico si el imei tienen acceso
    DeviceInfo.getPhoneNumber().then((phoneNumber) => {
      if (phoneNumber === undefined || phoneNumber === "unknown") {
        const id = showToast(
          "Debes autorizar el permiso solicitado para que el dispositivo se conecte a la aplicación"
        );
      } else {
        const body = {
          imei: phoneNumber,
        };
        const controller = "ControlVersiones";
        postGenerico(controller, JSON.stringify(body)).then((data) => {
          const IsPermitido = data;

          if (IsPermitido == "False") {
            this.setState({
              isVisibleVersion: false,
            });
            Alert.alert(
              "¡Dispositivo no permitido!",
              "La aplicación SPDS no esta permitida en este dispositivo",
              [{ text: "OK", onPress: () => {} }],
              { cancelable: false }
            );
          }
        });
      }
    });

    getVersionCurrent().then((data) => {
      const versionTelefono = VersionNumber.appVersion;

      if (data === undefined) {
        this.ValidoVersion();
        return;
      }
      if (versionTelefono !== data) {
        this.setState({
          isVisibleVersion: false,
        });
        Alert.alert(
          "¡App Obsoleta!",
          "No cuentas con la versión actual, actualiza tu APP desde Google Play Store",
          [{ text: "OK", onPress: () => {}}],
          { cancelable: false }
        );
      }
    });
  }

  //verifico si tengo coneccion a internet o a datos del celular
  checarRed() {
    NetInfo.fetch().then((connectionInfo) => {
      if (connectionInfo.type != "none") {
        IsLogining();
      } else {
        Alert.alert(
          "¡Upsss...!",
          "Parece que no tienes conexión a internet",
          [{ text: "OK", onPress: () => {} }],
          { cancelable: false }
        );
      }
    });
  }
  //fin checarRed()
  ///metodos para llamar vistas
  VistaLog() {
    Actions.login();
  }

  home() {
    Actions.home();
  }

  llamaVistaUtilerias() {
    Actions.utilerias();
  }
  ///fin metodos para llamar vistas

  //metodos de los input
  onChangeUsuario(usuario) {
    this.setState({ usuario });
    this.setState({
      mensaje: "\n" + "",
    });
  }

  onChangePassword(contrasena) {
    this.setState({ contrasena });
  }
  //fin de metodos de input

  //metodo de login
  login(usuario, contrasena) {
    NetInfo.fetch().then((connectionInfo) => {
      if (connectionInfo.type != "none") {
        showLoading();
        getDatosLogin(usuario, contrasena).then((data) => {
          this.almacenaUsuario(data);
        });
      } else {
        Alert.alert(
          "¡Upsss...!",
          "Parece que no tienes conexión a internet",
          [{ text: "OK", onPress: () => {} }],
          { cancelable: false }
        );
      }
    });
  }
  //fin metodo Login

  componentDidMount() {
    SetUrlPro();
    const versionTelefono = VersionNumber.appVersion;
    this.setState({
      version: versionTelefono,
    });
  }
  render() {
    const input2 = (
      <Input2
        onChangeUsrServidor={this.onChangeUsrServidor}
        onChangePassServidor={this.onChangePassServidor}
        ingresarVistaConfiguracion={this.ingresarVistaConfiguracion}
        //  devolverPed={this.devolverPedido}
        //   title2={this.state.title2}
        isVisible2={this.state.isVisible2}
        onCloseModal2={this.handleModalHide2}
      />
    );

    const seting = <Icon2 name="settings" size={30} color="#09467F" />;
    const url = this.state.url;
    const usuario = this.state.usuario;
    const contrasena = this.state.contrasena;
    const datos = this.state.datos;

    return (
      <View style={styles.container}>
        <KeyboardAwareScrollView style={styles.scroll}>
          {input2}
          <View style={styles.avatarImage}>
            <Icon
              name="user-o"
              color="#09467F"
              size={25}
              style={styles.avatar}
            />
            <TextInput
              style={styles.input}
              value={this.state.usuario}
              onChangeText={(usuario) => this.onChangeUsuario(usuario)}
              underlineColorAndroid="transparent"
              placeholder="Usuario"
              returnKeyType="next"
              keyboardType="numeric"
              //onSubmitEditing={()=>this.passwordInput.focus()}
              //autoCapitalize="none"
              //autoCorrect={false}
              placeholderTextColor="rgba(10,10,10,0.5)"
            />
          </View>
          <View style={styles.avatarImage}>
            <Icon name="key" color="#09467F" size={25} style={styles.avatar} />
            <TextInput
              style={styles.input}
              value={this.state.contrasena}
              onChangeText={(contrasena) => this.onChangePassword(contrasena)}
              underlineColorAndroid="transparent"
              placeholder="Contraseña"
              secureTextEntry
              returnKeyType="go"
              //ref={(input)=>this.passwordInput=input}
              placeholderTextColor="rgba(10,10,10,0.5)"
            />
          </View>
          <Text style={styles.errorLabel}>{this.state.mensaje}</Text>
          {this.state.isVisibleVersion == true ? (
            <TouchableOpacity
              onPress={() => this.login(usuario, contrasena)}
              style={styles.buttonContainer}
            >
              <Text style={styles.buttonText}>Ingresar</Text>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity
              onPress={() => null}
              style={styles.buttonContainerDisable}
            >
              <Text style={styles.buttonTextDisable}>Ingresar</Text>
            </TouchableOpacity>
          )}
          <View style={{ flexDirection: "row", width: "90%" }}>
            <View style={{ width: "10%" }}>
              <TouchableOpacity onPress={() => this.handleModalShow2()}>
                {seting}
              </TouchableOpacity>
            </View>
            <View style={{ width: "100%", textAlign: "right" }}>
              <Text style={styles.versionLabel}>
                Versión {this.state.version}
              </Text>
            </View>
          </View>
        </KeyboardAwareScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  scroll: {
    // height: responsiveHeight(100),
    // backgroundColor: 'yellow'
  },

  versionLabel: {
    color: "#09467F",
    marginLeft: "60%",
    //top: '3%',
    fontSize: responsiveFontSize(2),
    height: "100%",
  },
  container: {
    width: "100%",
    height: responsiveHeight(45),
    paddingLeft: 25,
    paddingRight: 25,
    position: "absolute",
    top: "55%", // responsiveHeight(55),
    //backgroundColor: 'yellow'
  },
  input: {
    height: 40,
    width: "80%",
    backgroundColor: "rgba(255,255,255,0.8)",
    marginBottom: 20,
    color: "#000",
    paddingHorizontal: 15,
    paddingVertical: 10,
    borderRadius: 8,
  },
  buttonContainerDisable: {
    backgroundColor: "#cecece",
    paddingVertical: 10,
    marginBottom: 20,
    borderRadius: 8,
  },
  buttonTextDisable: {
    textAlign: "center",
    color: "#e5e5e5",
    fontWeight: "900",
    fontSize: responsiveFontSize(2),
  },
  buttonContainer: {
    backgroundColor: "#09467F",
    paddingVertical: 10,
    marginBottom: 20,
    borderRadius: 8,
  },
  buttonContainerAvisoPrivacidad: {
    backgroundColor: "rgba(255, 255, 255, .17)",
    paddingVertical: 10,
    marginBottom: 20,
    borderRadius: 8,
  },
  buttonText: {
    textAlign: "center",
    color: "#FFF",
    fontWeight: "900",
    fontSize: responsiveFontSize(2),
  },
  buttonTextAvisoPrivacidad: {
    textAlign: "center",
    color: "black",
    fontWeight: "500",
    fontSize: responsiveFontSize(2),
  },
  errorLabel: {
    color: "#FF0000",
    marginBottom: 15,
    textAlign: "center",
    fontWeight: "900",
    backgroundColor: "transparent",
  },
  avatar: {
    width: 30,
    height: 30,
    margin: 10,
    marginTop: -3,
  },
  avatarImage: {
    flexDirection: "row",
    alignItems: "center",
  },
});
