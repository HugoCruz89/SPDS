import React, { Component } from "react";
import { StyleSheet, View, Image, Dimensions } from "react-native";
import LoginForm from "./LoginForm";
const { width, heigth } = Dimensions.get("window");

export default class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      coneccion: "",
    };
  }

  render() {
    return (
      <View style={styles.container}>
        <Image
          source={require("../../images/fondo2.jpg")}
          style={styles.backgroundImage}
        ></Image>
        <View style={styles.logoContainer}>
          <Image
            style={styles.logo}
            source={require("../../images/logopilgrims.png")}
          />
        </View>
        <View style={styles.logoContainer2}>
          <Image
            style={styles.logo2}
            source={require("../../images/logo.png")}
          />
        </View>
        <LoginForm />
        {/*{this.state.coneccion != 'none' ? <LoginForm/>:null}*/}
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    height: heigth,
    width: width,
  },
  backgroundImage: {
    flex: 1,
    alignSelf: "stretch",
    width: width,
    justifyContent: "center",
    alignItems: "center",
    height: heigth,
    opacity: 0.3,
  },
  logo: {
    bottom: "10%",
    width: 200,
    height: 118,
  },
  logo2: {
    bottom: "10%",
    width: 170,
    height: 140,
  },

  logoContainer: {
    position: "absolute",
    alignItems: "center",
    width: "100%",
    height: "100%",
    top: "20%",
  },
  logoContainer2: {
    position: "absolute",
    alignItems: "center",
    width: "100%",
    height: "100%",
    top: "40%",
  },
  title: {
    backgroundColor: "transparent",
    color: "white",
    marginTop: 10,
    fontSize: 50,
  },
});
