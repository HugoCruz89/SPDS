import { isNumero, isTemp, isDecimal } from "../ValidacionRegex/Regex";
import { Alert } from "react-native";

function isFormValido(objeto) {
  const obj = JSON.parse(objeto);

  //   //validacion de numeros en input
  if (
    obj.horometro == "" ||
    obj.kmIncial == "" ||
    obj.terCalSalCD == "" ||
    obj.temperatura == "" ||
    obj.LtsCargaCombSalida == "" ||
    obj.LtsCargaTermoSalida == ""
  ) {
    Alert.alert(
      "Error de Captura!",
      "Es obligatorio ingresar todos los datos",
      [{ text: "OK", onPress: () => {} }],
      { cancelable: false }
    );
    return false;
  }

  if (
    isNumero(obj.horometro) &&
    isNumero(obj.kmIncial) &&
    isNumero(obj.terCalSalCD)
  ) {
    if (isTemp(obj.temperatura)) {
      if (
        isDecimal(obj.LtsCargaCombSalida) &&
        isDecimal(obj.LtsCargaCombSalida)
      ) {
        return true;
      } else {
        Alert.alert(
          "Error de Captura!",
          "El valor ingresado de litros es incorrecta",
          [{ text: "OK", onPress: () => {} }],
          { cancelable: false }
        );
        return false;
      }
    } else {
      Alert.alert(
        "Error de Captura!",
        "Temperatura Incorrecta",
        [{ text: "OK", onPress: () => {} }],
        { cancelable: false }
      );
      return false;
    }
  } else {
    Alert.alert(
      "Error de Captura!",
      "Verifica que la captura de datos solo corresponda a números, y no contenga espacios",
      [{ text: "OK", onPress: () =>{} }],
      { cancelable: false }
    );
    return false;
  }
}
export { isFormValido };
