
//Regex para folio
function regexFolio(folio, regex){
    console.warn('aqui',regex)
    const pattern = new RegExp(regex)   
    console.warn(pattern)
      return pattern.test(folio);
}
export {regexFolio}


//funcion para validar correo
function isMail(email){
    const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}
export {isMail}

//funcion para validar numero
function isNumero(numero){   
    const re = /^([0-9])*$/;
    return re.test(numero);
}
export {isNumero}

//funcion para campos obligatorios
function isObligatorio(cadena){
    const re = /^$/;
    return re.test(cadena);
}
export {isObligatorio}

//funcion para validar letras
function isLetra(cadena){
    const re = /^[A-Za-z]*$/;
    return re.test(cadena);
}
export {isLetra}

//Funcion para validar temperatura
function isTemp(cadena){
    const re =  /^[-]?\d+(\.\d+)*$/;
    return re.test(cadena);
}
export {isTemp}


function isDecimal(cadena){
    const re =  /^\d+(\.\d+)*$/;
    return re.test(cadena);
}
export {isDecimal}

